"""Timeline and comparison plots for agent-replay runs (RUNBOOK 6.6 events + 4.6 client JSONL).

Joins one boot's server.log (millisecond timestamps, HICACHE_EVT lines, Prefill/Decode batch lines)
with one client run's client.jsonl (per-turn send/first-token/end, tier split) on a common clock:
seconds since the client started (client `run.t_start` is epoch; server stamps are UTC wall clock).

  python3 timeline.py --manifest results/compare_<t>/manifest.txt        # every arm + a comparison figure
  python3 timeline.py --run results/<boot dir> [--client client_<...>]    # one arm
  --tier-rule private: classify by the private history (vs_baseline.tier_of, the rule of the READMEs since campaign 12)
  --steady-state [SECONDS]: also compare_steady.png / compare_steady.csv over the turns sent once every arm's cached data
  had outgrown device + host memory (the latest of the arms' first host evictions; the first device eviction on a server
  without a host tier), or compare_steady_<SECONDS>s.* over the turns sent from SECONDS on (since the client started).

Outputs next to the manifest (or in the run dir): timeline_<arm>.png, events_<arm>.csv, turns_<arm>.csv (its last
column, mid_start, marks the first request of a user who started mid-session), compare.png, compare.csv. A user's first
request (turn 0 or mid_start, vs_baseline.is_first) is not a returning turn.
Colors: blue = writes (d2h, h2s) / device hit, orange = restores (h2d, s2h) / host hit,
aqua = evictions / storage hit, gray = cold/recompute (default: less than half the prompt cached; private: over half of
the prompt beyond the shared system prompt uncached); the three hues are the validated first three slots of the
dataviz reference palette.
"""
import argparse
import bisect
import collections
import csv
import datetime as dt
import json
import os
import re
import sys

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.collections import LineCollection  # noqa: E402
from matplotlib.colors import to_rgba  # noqa: E402
from matplotlib.patches import Patch  # noqa: E402

from vs_baseline import is_first, is_returning, tier_of  # noqa: E402

BLUE, ORANGE, AQUA, GRAY, INK, MUTED = "#2a78d6", "#eb6834", "#1baf7a", "#9a9891", "#0b0b0b", "#52514e"
GREEN = "#2e7d32"  # three_tier_wc, distinct from the AQUA of three_tier_to
TIER_COLOR = {"cold": GRAY, "device": BLUE, "host": ORANGE, "storage": AQUA}
COLD_LABEL = {"prompt": "cold/recompute", "private": "recompute (over half of the private prompt uncached)"}
ARM_COLOR = {"hbm_lru": GRAY, "hbm_host": ORANGE, "three_tier": AQUA,
             "three_tier_to": AQUA, "three_tier_wc": GREEN,   # campaign 6: the two prefetch policies
             "three_tier_wc_norq": "#4a3aa7",   # campaign 11: wait_complete with the #39283 re-query disabled
             # the oracle (ORACLE_PLAN.md): next reference-palette slots, validated with GREEN and the violet above
             "three_tier_wc_ntpobs": "#eda100", "three_tier_wc_oracle": "#e87ba4",
             "three_tier_wc_ntpobs_norq": BLUE, "three_tier_wc_oracle_norq": "#e34948",
             # campaign 15: violet again, never in a figure with three_tier_wc_norq (campaign 11)
             "three_tier_to_oracle": "#4a3aa7",
             # campaign 16: Okabe-Ito sky, Tol wine, violet again (never with three_tier_to_oracle); with GREEN,
             # worst normal-vision dE 18.2 and worst CVD dE 11.4 (OKLab x100, Machado)
             "three_tier_wc_dl": "#56b4e9", "three_tier_wc_oracle_v2": "#882255", "three_tier_wc_oracle_v2_nu": "#4a3aa7"}
TS_RE = re.compile(r"^\[(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d(?:\.\d{3})?)\]\s*(.*)$")
KV_RE = re.compile(r"(\w+)=(-?[\w./-]+)")


def parse_ts(s: str) -> float:
    fmt = "%Y-%m-%d %H:%M:%S.%f" if "." in s else "%Y-%m-%d %H:%M:%S"
    return dt.datetime.strptime(s, fmt).replace(tzinfo=dt.timezone.utc).timestamp()


def host_path(p: str) -> str:
    """Manifest paths are container paths; map them onto the host checkout if needed."""
    if os.path.exists(p):
        return p
    alt = p.replace("/sgl-workspace/sglang", "/home/wanhr/sglang")
    return alt if os.path.exists(alt) else p


# ----------------------------------------------------------------------------- parsing
def parse_client(path: str, tier_rule: str = "prompt") -> dict:
    rows = [json.loads(l) for l in open(path)]
    run = next(r for r in rows if r["kind"] == "run")
    t_start = run["t_start"]
    turns = []
    for r in rows:
        if r["kind"] != "turn" or "t_send" not in r:
            continue
        cd = r.get("cached_details") or {}
        host, storage = int(cd.get("host") or 0), int(cd.get("storage") or 0)
        cached = int(r.get("cached_tokens") or 0)
        prompt = int(r.get("prompt_tokens") or 0)
        # private: over half of the prompt beyond the shared system prompt uncached is cold/recompute. prompt (older):
        # a turn that finds less than half its prompt lost its own prefix (only the shared system prompt hit)
        if tier_rule == "private":
            tier = tier_of(r).replace("recompute", "cold")
        elif cached < 0.5 * prompt:
            tier = "cold"
        else:
            tier = "storage" if storage > 0 else "host" if host > 0 else "device"
        turns.append(dict(conv=r["conv"], turn=r["turn"], t0=r["t_send"], ttft=r.get("ttft") or 0.0,
                          lat=r["latency"], tier=tier, prompt=r.get("prompt_tokens", 0), cached=cached,
                          uncached=r.get("prompt_tokens", 0) - cached, host=host, storage=storage,
                          gap=r.get("gap_slept", 0.0), rid=f"{run['args'].get('tag') or 'replay'}-c{r['conv']}-t{r['turn']}",
                          mid_start=bool(r.get("mid_start"))))   # a mid-session start's first request (is_first)
    summary = next((r for r in rows if r["kind"] == "summary"), None)
    return dict(t_start=t_start, turns=turns, summary=summary, args=run["args"], tier_rule=tier_rule)


def parse_server(path: str, t_start: float, sends: dict = None) -> dict:
    """Everything relative to t_start (seconds). Submit/done pairs are matched FIFO for d2h/h2d
    (the ack queues are FIFO), by op id for h2s, by rid for s2h. sends maps a rid to its client send time: storage
    events of a rid stamped before it was sent were staged by the oracle and go to s2h_staged, not to the turn."""
    batches, evd, evh, lbi = [], [], [], []
    d2h_sub, h2d_sub = collections.deque(), collections.deque()
    d2h, h2d = [], []
    h2s = collections.defaultdict(dict)
    s2h = collections.defaultdict(dict)
    s2h_staged = collections.defaultdict(dict)
    ntp = []
    posts = []
    sends = sends or {}
    planned = set()   # rids the oracle planned for: one never sent had all its reads staged
    def s2h_of(rid, t):
        staged = t < sends[rid] if rid in sends else rid in planned
        return s2h_staged[rid] if staged else s2h[rid]
    for line in open(path, errors="replace"):
        m = TS_RE.match(line)
        if not m:
            continue
        t = parse_ts(m.group(1)) - t_start
        msg = m.group(2)
        if msg.startswith("Prefill batch") or msg.startswith("Decode batch"):
            kv = {k.strip(): v for k, v in re.findall(r"#?([\w -]+?): ([0-9.]+)", msg)}
            usage = float(kv.get("token usage", 0))
            batches.append(dict(t=t, kind="prefill" if msg.startswith("Prefill") else "decode", usage=usage,
                                running=int(kv.get("running-req", 0)), queue=int(kv.get("queue-req", 0)),
                                new=int(kv.get("new-token", 0)), cached=int(kv.get("cached-token", 0))))
        elif "HICACHE_EVT" in msg:
            ev = msg.split("HICACHE_EVT ", 1)[1].split()[0]
            kv = dict(KV_RE.findall(msg))
            toks = int(kv.get("tokens", 0))
            if ev == "d2h_submit":
                d2h_sub.append((t, toks))
            elif ev == "d2h_done":
                ts, _ = d2h_sub.popleft() if d2h_sub else (t, toks)
                d2h.append(dict(t0=ts, t1=t, tokens=toks, ms=float(kv.get("ms", -1))))
            elif ev == "h2d_submit":
                h2d_sub.append((t, toks))
            elif ev == "h2d_done":
                ts, _ = h2d_sub.popleft() if h2d_sub else (t, toks)
                h2d.append(dict(t0=ts, t1=t, tokens=toks, ms=float(kv.get("ms", -1))))
            elif ev == "h2s_submit":
                h2s[kv["op"]].update(t_submit=t, tokens=toks)
            elif ev == "h2s_io":
                h2s[kv["op"]].update(t_io_end=t, io_ms=float(kv.get("ms", 0)), tokens_io=toks)
            elif ev == "h2s_done":
                h2s[kv["op"]].update(t_done=t, tokens_done=toks)
            elif ev == "prefetch_start":
                s2h_of(kv["rid"], t).update(t_start=t, tokens_req=toks)
            elif ev == "s2h_query":
                s2h_of(kv["rid"], t).update(t_query=t, storage_hit=int(kv.get("storage_hit", 0)))
            elif ev == "s2h_io":
                s2h_of(kv["rid"], t).update(t_io_end=t, io_ms=float(kv.get("ms", 0)), tokens_io=toks)
            elif ev == "ntp_plan":
                planned.add(kv.get("rid"))
            elif ev in ("ntp_due", "ntp_stage", "ntp_refetch", "ntp_admit"):
                ntp.append(dict(kind=ev, t=t, rid=kv.get("rid"), fields=kv))
            elif ev == "evict_device":
                evd.append(dict(t=t, tokens=toks, requested=int(kv.get("requested", 0))))
            elif ev == "evict_host":
                evh.append(dict(t=t, tokens=toks))
            elif ev == "load_back_init":
                lbi.append(dict(t=t, rid=kv.get("rid"), tokens=toks, host_hit=int(kv.get("host_hit", 0))))
        elif "HiCache prefetch" in msg:
            kv = dict(KV_RE.findall(msg))
            if "req" in kv:
                s2h_of(kv["req"], t).update(t_end=t, completed=int(kv.get("completed", 0)),
                                            loaded=int(kv.get("loaded", 0)), dropped="dropped" in msg)
        elif '"POST /v1/chat/completions' in msg:
            posts.append(t)
    return dict(batches=batches, d2h=d2h, h2d=h2d, h2s=dict(h2s), s2h=dict(s2h), evict_device=evd, evict_host=evh,
                load_back_init=lbi, posts=posts, s2h_staged=dict(s2h_staged), ntp=ntp)


# ----------------------------------------------------------------------------- figures
def style(ax, title=None, ylabel=None):
    ax.grid(True, axis="x", color="#e6e5e0", linewidth=0.8)
    ax.grid(False, axis="y")
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color("#c9c8c1")
    ax.tick_params(colors=MUTED, labelsize=8)
    if title:
        ax.set_title(title, loc="left", fontsize=10, color=INK, pad=6)
    if ylabel:
        ax.set_ylabel(ylabel, fontsize=8, color=MUTED)


def draw_timeline(arm: str, cl: dict, sv: dict, out_png: str) -> None:
    turns = cl["turns"]
    t_end = max([t["t0"] + t["lat"] for t in turns] + [b["t"] for b in sv["batches"]] + [1.0])
    convs = sorted({t["conv"] for t in turns})
    # the layout was drawn for 128 rows; more rows (users of a held-population run) get up to twice the lane panel
    lane = 4.2 * min(2.0, max(1.0, len(convs) / 128))
    fig, axes = plt.subplots(5, 1, figsize=(16, 14 + (lane - 4.2) * 14 / 10.4), sharex=True,
                             gridspec_kw=dict(height_ratios=[lane, 1.2, 1.2, 2.2, 1.6], hspace=0.28))
    fig.patch.set_facecolor("#fcfcfb")
    a_req, a_pool, a_queue, a_evt, a_cum = axes

    # A. request lanes: one row per conversation; prefill/queue segment thick, decode segment thin
    row = {c: i for i, c in enumerate(convs)}
    pitch = a_req.get_position().height * fig.get_figheight() * 72 / max(1, len(convs))   # points per row
    scale = min(1.0, pitch / 2.0)   # 2.0 pt: the 128-row panel, where the 4 pt / 1.2 pt lanes were chosen
    segs, colors, widths = [], [], []
    for t in turns:
        y, c = row[t["conv"]], TIER_COLOR[t["tier"]]
        segs += [[(t["t0"], y), (t["t0"] + t["ttft"], y)], [(t["t0"] + t["ttft"], y), (t["t0"] + t["lat"], y)]]
        colors += [to_rgba(c), to_rgba(c, 0.7)]
        widths += [4 * scale, 1.2 * scale]
    a_req.add_collection(LineCollection(segs, colors=colors, linewidths=widths, capstyle="butt"))
    a_req.autoscale_view()
    step = max(1, len(convs) // 32)  # at most ~32 labels: 128 conversations would otherwise print as a black bar
    a_req.set_yticks(range(0, len(convs), step))
    a_req.set_yticklabels([f"c{c}" for c in convs[::step]], fontsize=7)
    a_req.invert_yaxis()
    n_conv = int((cl.get("args") or {}).get("num_conversations") or len(convs))
    who = "conversation" if len(convs) <= n_conv else f"user ({len(convs)} users replay {n_conv} conversations)"
    style(a_req, f"{arm}: requests per {who} (thick = send to first token, thin = decode); color = where the prefix was found",
          "user" if len(convs) > n_conv else "conversation")
    a_req.legend(handles=[Patch(color=TIER_COLOR[k], label=(COLD_LABEL[cl["tier_rule"]] if k == "cold" else k))
                          for k in ("cold", "device", "host", "storage")],
                 loc="upper right", fontsize=8, frameon=False, ncol=4)

    # B. device pool usage (one measure per axis)
    bt = [b["t"] for b in sv["batches"]]
    a_pool.plot(bt, [b["usage"] for b in sv["batches"]], color=BLUE, linewidth=1.5)
    a_pool.set_ylim(0, 1.05)
    style(a_pool, "device KV pool usage (fraction of --max-total-tokens)", "usage")

    # C. queue depth and running requests
    a_queue.plot(bt, [b["queue"] for b in sv["batches"]], color=ORANGE, linewidth=1.5, label="queued (#queue-req)")
    a_queue.plot(bt, [b["running"] for b in sv["batches"]], color=BLUE, linewidth=1.5, label="running (#running-req)")
    style(a_queue, "scheduler queue and running requests", "requests")
    a_queue.set_ylim(0, 1.3 * max([b["queue"] for b in sv["batches"]] + [b["running"] for b in sv["batches"]] + [1]))
    a_queue.legend(loc="upper right", fontsize=8, frameon=False, ncol=2)

    # D. tier events: one lane per type; bars where a duration is known, ticks otherwise (size ~ tokens)
    lanes = ["d2h", "h2s", "s2h", "h2d", "evict_device", "evict_host"]
    oracle = bool(sv["ntp"] or sv["s2h_staged"])   # runs with --hicache-storage-next-turn-prefetch observe | on
    if oracle:
        lanes.append("oracle")
    ypos = {k: i for i, k in enumerate(lanes)}
    def bars(lane, spans, color):
        y = ypos[lane]
        if spans:
            a_evt.add_collection(LineCollection([[(t0, y), (max(t1, t0 + 0.25), y)] for t0, t1 in spans],
                                                colors=[to_rgba(color, 0.85)], linewidths=6, capstyle="butt"))
    def ticks(lane, ts, color, alpha=1.0):
        if ts:
            a_evt.plot(ts, [ypos[lane]] * len(ts), linestyle="none", marker="|", color=color, markersize=8, alpha=alpha)
    def copy_spans(evs):
        return [(e["t1"] - e["ms"] / 1000 if e["ms"] > 0 else e["t0"], e["t1"]) for e in evs]
    def io_spans(ops):
        return [(op["t_io_end"] - op["io_ms"] / 1000, op["t_io_end"]) for op in ops if "t_io_end" in op]
    bars("d2h", copy_spans(sv["d2h"]), BLUE)
    bars("h2s", io_spans(sv["h2s"].values()), BLUE)
    ticks("h2s", [op["t_submit"] for op in sv["h2s"].values() if "t_io_end" not in op and "t_submit" in op], BLUE)
    bars("s2h", io_spans(sv["s2h"].values()), ORANGE)
    ticks("s2h", [op["t_start"] for op in sv["s2h"].values() if "t_io_end" not in op and "t_start" in op], ORANGE, 0.6)
    bars("h2d", copy_spans(sv["h2d"]), ORANGE)
    for lane in ("evict_device", "evict_host"):
        if sv[lane]:
            a_evt.scatter([e["t"] for e in sv[lane]], [ypos[lane]] * len(sv[lane]),
                          s=[6 + e["tokens"] / 200 for e in sv[lane]], color=AQUA, alpha=0.7, linewidths=0)
    title = "HiCache tier events (bars = measured copy/IO time ending at completion; dots = evictions, area ~ tokens)"
    if oracle:
        # the oracle lane: staged reads (I/O before the turn was sent), trigger times, and re-issued prefetches
        bars("oracle", io_spans(sv["s2h_staged"].values()), ORANGE)
        ticks("oracle", [e["t"] for e in sv["ntp"] if e["kind"] == "ntp_due"], GRAY)
        ticks("oracle", [e["t"] for e in sv["ntp"] if e["kind"] == "ntp_stage"], ORANGE)
        refetched = [e["t"] for e in sv["ntp"] if e["kind"] == "ntp_refetch" and e["fields"].get("issued") == "1"]
        if refetched:
            a_evt.plot(refetched, [ypos["oracle"]] * len(refetched), linestyle="none", marker="x", color=BLUE, markersize=6)
        title += "; oracle: | trigger due (gray), staged read (orange), x re-issued prefetch"
    a_evt.set_yticks(range(len(lanes)))
    a_evt.set_yticklabels(lanes, fontsize=8)
    a_evt.set_ylim(-0.7, len(lanes) - 0.3)
    a_evt.invert_yaxis()
    style(a_evt, title)

    # E. cumulative tokens moved per event type
    def cum(xs, ys, label, color, ls="-"):
        if not xs:
            return
        pts = sorted(zip(xs, ys))
        run, out = 0, []
        for x, y in pts:
            run += y
            out.append((x, run))
        a_cum.plot([p[0] for p in out], [p[1] / 1000 for p in out], color=color, linewidth=1.5, linestyle=ls,
                   drawstyle="steps-post", label=f"{label} {run/1000:.0f}K")
    cum([e["t1"] for e in sv["d2h"]], [e["tokens"] for e in sv["d2h"]], "d2h", BLUE)
    h2s_done = [op for op in sv["h2s"].values() if "t_done" in op]
    cum([op["t_done"] for op in h2s_done], [op.get("tokens_done", 0) for op in h2s_done], "h2s", BLUE, "--")
    s2h_done = [op for op in sv["s2h"].values() if "t_end" in op]
    cum([op["t_end"] for op in s2h_done], [op.get("loaded", 0) for op in s2h_done], "s2h", ORANGE, "--")
    cum([e["t1"] for e in sv["h2d"]], [e["tokens"] for e in sv["h2d"]], "h2d", ORANGE)
    cum([e["t"] for e in sv["evict_device"]], [e["tokens"] for e in sv["evict_device"]], "evict_device", AQUA)
    cum([e["t"] for e in sv["evict_host"]], [e["tokens"] for e in sv["evict_host"]], "evict_host", AQUA, "--")
    style(a_cum, "cumulative tokens moved (K tokens; solid = device-side, dashed = storage/host-side)", "K tokens")
    if a_cum.get_legend_handles_labels()[0]:
        a_cum.legend(loc="upper left", fontsize=8, frameon=False, ncol=3)
    a_cum.set_xlabel("seconds since the client started", fontsize=8, color=MUTED)
    a_cum.set_xlim(0, t_end * 1.02)
    fig.savefig(out_png, dpi=130, bbox_inches="tight")
    plt.close(fig)


def arm_metrics(arm: str, cl: dict, sv: dict) -> dict:
    turns = cl["turns"]
    ret = [t for t in turns if is_returning(t)]
    first = [t for t in turns if is_first(t)]   # turn 0, or a mid-session start's first request
    tiers = collections.Counter(t["tier"] for t in ret)
    pct = lambda xs, p: sorted(xs)[min(len(xs) - 1, int(p * len(xs)))] if xs else float("nan")
    ttft_ret = [t["ttft"] for t in ret]
    return dict(arm=arm, turns=len(turns), conversations=len({t["conv"] for t in turns}),
                wall_s=round(max(t["t0"] + t["lat"] for t in turns), 1) if turns else 0,
                turn0_ttft_p50=round(pct([t["ttft"] for t in first], .5), 2),
                ret_ttft_mean=round(sum(ttft_ret) / len(ttft_ret), 3) if ttft_ret else float("nan"),
                ret_ttft_p50=round(pct(ttft_ret, .5), 3), ret_ttft_p90=round(pct(ttft_ret, .9), 3),
                ret_ttft_p99=round(pct(ttft_ret, .99), 3),
                ret_uncached_mean=round(sum(t["uncached"] for t in ret) / len(ret)) if ret else 0,
                ret_uncached_total=sum(t["uncached"] for t in ret),
                t95_done_s=round(pct([t["t0"] + t["lat"] for t in turns], .95), 1),
                uncached_total=sum(t["uncached"] for t in turns),
                hits_device=tiers["device"], hits_host=tiers["host"], hits_storage=tiers["storage"], cold_returns=tiers["cold"],
                d2h_tokens=sum(e["tokens"] for e in sv["d2h"]), h2d_tokens=sum(e["tokens"] for e in sv["h2d"]),
                h2s_tokens=sum(op.get("tokens_done", 0) for op in sv["h2s"].values()),
                s2h_tokens=sum(op.get("loaded", 0) for op in sv["s2h"].values()),
                evict_device_tokens=sum(e["tokens"] for e in sv["evict_device"]),
                evict_host_tokens=sum(e["tokens"] for e in sv["evict_host"]),
                peak_queue=max((b["queue"] for b in sv["batches"]), default=0))


def first_overflow(sv: dict):
    """Seconds since the client started at which the cached data first outgrew device + host memory: the first host
    eviction (the first device eviction on a server without a host tier, which writes nothing d2h); None if never."""
    return next((e["t"] for e in (sv["evict_host"] if sv["d2h"] else sv["evict_device"]) if e["t"] >= 0), None)


def steady_view(cl: dict, sv: dict, t_from: float) -> tuple:
    """The client and server records cut to the turns sent, and the events stamped, from t_from on."""
    turns = [t for t in cl["turns"] if t["t0"] >= t_from]
    rids = {t["rid"] for t in turns}
    since = lambda xs, key: [x for x in xs if x[key] >= t_from]
    return dict(cl, turns=turns), dict(
        sv, batches=since(sv["batches"], "t"), d2h=since(sv["d2h"], "t0"), h2d=since(sv["h2d"], "t0"),
        h2s={op_id: op for op_id, op in sv["h2s"].items() if op.get("t_submit", -1.0) >= t_from},
        s2h={rid: op for rid, op in sv["s2h"].items() if rid in rids},
        evict_device=since(sv["evict_device"], "t"), evict_host=since(sv["evict_host"], "t"),
        load_back_init=since(sv["load_back_init"], "t"))


def write_steady(results: list, out_dir: str, start: float = None) -> None:
    """compare_steady.png / .csv over the turns sent from the latest arm's first_overflow on, so every arm is compared
    over the same span and only once its cached data had outgrown device + host memory; compare_steady_<start>s.* when
    `start` is given."""
    firsts = {arm: first_overflow(sv) for arm, _, sv, _ in results}
    if start is None:
        never = [arm for arm, t in firsts.items() if t is None]
        if never:
            print(f"warning: the cached data of {', '.join(never)} never outgrew device + host memory; "
                  "left out of the steady-state comparison", file=sys.stderr)
        kept = [r for r in results if firsts[r[0]] is not None]
        if not kept:
            print("warning: no arm outgrew device + host memory; compare_steady not written", file=sys.stderr)
            return
        t_from = max(firsts[r[0]] for r in kept)
        why = "once every arm's cached data had outgrown device + host memory (its first host eviction)"
    else:
        kept, t_from, why = results, start, "the start set by --steady-state"
    steady = []
    for arm, cl, sv, _ in kept:
        cl_s, sv_s = steady_view(cl, sv, t_from)
        first = firsts[arm]
        m = dict(arm_metrics(arm, cl_s, sv_s), first_overflow_s=round(first, 1) if first is not None else "",
                 steady_from_s=round(t_from, 1), turns_skipped=len(cl["turns"]) - len(cl_s["turns"]))
        steady.append((arm, cl_s, sv_s, m))
        own = f"{first:.0f} s" if first is not None else "never"
        print(f"{arm} steady state (from {t_from:.0f} s; its own first overflow {own}): {m['turns']} turns kept, "
              f"{m['turns_skipped']} skipped; returning TTFT mean {m['ret_ttft_mean']} p50 {m['ret_ttft_p50']} "
              f"p90 {m['ret_ttft_p90']} s; hits device/host/storage/cold "
              f"{m['hits_device']}/{m['hits_host']}/{m['hits_storage']}/{m['cold_returns']}")
    name = "compare_steady" if start is None else f"compare_steady_{start:g}s"
    if len(steady) > 1:
        draw_compare(steady, os.path.join(out_dir, f"{name}.png"), steady_from=t_from, steady_why=why)
    with open(os.path.join(out_dir, f"{name}.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(steady[0][3].keys()))
        w.writeheader(); w.writerows([r[3] for r in steady])


def arm_colors(arms: list) -> dict:
    """ARM_COLOR per arm; an arm missing from it gets its own color from matplotlib's cycle and a warning."""
    missing = [a for a in arms if a not in ARM_COLOR]
    if missing:
        print(f"warning: no ARM_COLOR entry for {', '.join(missing)}; add one to timeline.py", file=sys.stderr)
    cycle = plt.rcParams["axes.prop_cycle"].by_key()["color"]
    return {a: ARM_COLOR[a] if a in ARM_COLOR else cycle[missing.index(a) % len(cycle)] for a in arms}


def draw_compare(results: list, out_png: str, steady_from: float = None, steady_why: str = "") -> None:
    """steady_from: the turns were cut to those sent from this time on (seconds since the client started), for steady_why."""
    colors = arm_colors([r[0] for r in results])
    fig, axes = plt.subplots(2, 2, figsize=(16, 9))
    fig.patch.set_facecolor("#fcfcfb")
    a_done, a_cdf, a_cdf0, a_tier = axes.flatten()
    for arm, cl, sv, m in results:
        ends = sorted(t["t0"] + t["lat"] for t in cl["turns"])
        a_done.plot(ends, range(1, len(ends) + 1), color=colors[arm], linewidth=1.8, label=arm, drawstyle="steps-post")
    if steady_from is not None:
        a_done.axvline(steady_from, color=MUTED, linestyle="--", linewidth=1)
    style(a_done, "turns completed over time (all conversations)" if steady_from is None
          else f"turns completed over time (turns sent from {steady_from:.0f} s on, dashed)", "turns done")
    a_done.set_xlabel("seconds since the client started", fontsize=8, color=MUTED)
    a_done.legend(fontsize=8, frameon=False, loc="lower right")
    # log x when the arms span more than ~2 decades (a collapsed arm's tail would squash the healthy ones against 0)
    sel_ret, sel_first = is_returning, is_first
    def spans_decades(sel):
        per_arm = [sorted(t["ttft"] for t in cl["turns"] if sel(t)) for _, cl, _, _ in results]
        per_arm = [xs for xs in per_arm if xs]
        if not per_arm:
            return False
        lo = min(xs[len(xs) // 2] for xs in per_arm)
        hi = max(xs[min(len(xs) - 1, int(0.99 * len(xs)))] for xs in per_arm)
        return lo > 0 and hi / lo > 50
    for arm, cl, sv, m in results:
        color = colors[arm]
        for ax, sel, in ((a_cdf, sel_ret), (a_cdf0, sel_first)):
            xs = sorted(max(0.01, t["ttft"]) for t in cl["turns"] if sel(t))
            if xs:
                ax.plot(xs, [(i + 1) / len(xs) for i in range(len(xs))], color=color, linewidth=1.8, label=arm,
                        drawstyle="steps-post")
    for ax, sel in ((a_cdf, sel_ret), (a_cdf0, sel_first)):
        log = spans_decades(sel)
        # if log:
        #     ax.set_xscale("log")
        ax.set_xlabel("seconds (log)" if log else "seconds", fontsize=8, color=MUTED)
        ax.legend(fontsize=8, frameon=False, loc="lower right")
    style(a_cdf, "TTFT of returning turns (ECDF)", "fraction of turns")
    # the start: a closed-loop cohort (arrival_rate 0: all C sessions start at once) or sessions arriving at a rate
    args0 = results[0][1].get("args") or {}
    conc, rate = args0.get("concurrency"), float(args0.get("arrival_rate") or 0)
    live = (f"a cap from {conc} set by the server backlog" if args0.get("cap_mode") == "backlog"
            else f"up to {conc} live sessions")
    start = (f"{live}, arriving at {rate:g}/s" if rate > 0
             else f"cold prefill under the {conc}-way start" if conc else "cold prefill")
    style(a_cdf0, f"TTFT of first turns (ECDF; {start})", "fraction of turns")
    # tier share of returning turns, one bar per arm, 2px gaps between segments
    for i, (arm, cl, sv, m) in enumerate(results):
        n = max(1, m["hits_device"] + m["hits_host"] + m["hits_storage"] + m["cold_returns"])
        left = 0
        for key, tier in (("hits_device", "device"), ("hits_host", "host"), ("hits_storage", "storage"), ("cold_returns", "cold")):
            w = m[key] / n
            if w > 0:
                a_tier.barh(i, w, left=left, color=TIER_COLOR[tier], height=0.55, edgecolor="#fcfcfb", linewidth=2)
                if w > 0.06:
                    a_tier.text(left + w / 2, i, f"{100*w:.0f}%", ha="center", va="center", fontsize=7, color="#fcfcfb")
            left += w
        a_tier.text(1.01, i, f"uncached/turn {m['ret_uncached_mean']}", fontsize=7, color=MUTED, va="center")
    a_tier.set_yticks(range(len(results)))
    a_tier.set_yticklabels([r[0] for r in results], fontsize=8)
    a_tier.set_xlim(0, 1.0)
    a_tier.invert_yaxis()
    style(a_tier, "where returning turns found their prefix", None)
    a_tier.legend(handles=[Patch(color=TIER_COLOR[k], label=(COLD_LABEL[results[0][1]["tier_rule"]] if k == "cold" else k))
                           for k in ("device", "host", "storage", "cold")],
                  fontsize=8, frameon=False, loc="upper center", bbox_to_anchor=(0.5, -0.04), ncol=4)  # below the bars: any arm count
    if steady_from is not None:
        fig.suptitle(f"Steady state only: turns sent from {steady_from:.0f} s on, {steady_why}", x=0.01, ha="left",
                     fontsize=10, color=INK)
    fig.tight_layout()
    fig.savefig(out_png, dpi=130, bbox_inches="tight")
    plt.close(fig)


def write_csvs(arm: str, cl: dict, sv: dict, out_dir: str) -> None:
    with open(os.path.join(out_dir, f"turns_{arm}.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(cl["turns"][0].keys()) if cl["turns"] else ["conv"])
        w.writeheader(); w.writerows(cl["turns"])
    rows = []
    for e in sv["d2h"]:
        rows.append(dict(kind="d2h", t0=e["t0"], t1=e["t1"], tokens=e["tokens"], ms=e["ms"], key=""))
    for e in sv["h2d"]:
        rows.append(dict(kind="h2d", t0=e["t0"], t1=e["t1"], tokens=e["tokens"], ms=e["ms"], key=""))
    for op_id, op in sv["h2s"].items():
        rows.append(dict(kind="h2s", t0=op.get("t_submit"), t1=op.get("t_done"), tokens=op.get("tokens_done", op.get("tokens")),
                         ms=op.get("io_ms"), key=op_id))
    for rid, op in sv["s2h"].items():
        rows.append(dict(kind="s2h", t0=op.get("t_start"), t1=op.get("t_end"), tokens=op.get("loaded"), ms=op.get("io_ms"), key=rid))
    for e in sv["evict_device"]:
        rows.append(dict(kind="evict_device", t0=e["t"], t1=e["t"], tokens=e["tokens"], ms="", key=""))
    for e in sv["evict_host"]:
        rows.append(dict(kind="evict_host", t0=e["t"], t1=e["t"], tokens=e["tokens"], ms="", key=""))
    for e in sv["load_back_init"]:
        rows.append(dict(kind="load_back_init", t0=e["t"], t1=e["t"], tokens=e["tokens"], ms="", key=e["rid"]))
    for rid, op in sv["s2h_staged"].items():
        rows.append(dict(kind="s2h_staged", t0=op.get("t_start"), t1=op.get("t_end"), tokens=op.get("loaded"),
                         ms=op.get("io_ms"), key=rid))
    for e in sv["ntp"]:
        rows.append(dict(kind=e["kind"], t0=e["t"], t1=e["t"], tokens=e["fields"].get("tokens", ""), ms="", key=e["rid"]))
    rows.sort(key=lambda r: (r["t0"] if r["t0"] is not None else 1e18))
    with open(os.path.join(out_dir, f"events_{arm}.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["kind", "t0", "t1", "tokens", "ms", "key"])
        w.writeheader(); w.writerows(rows)


def steady_start(v: str):
    """--steady-state value: "auto" or seconds since the client started."""
    try:
        return v if v == "auto" else float(v)
    except ValueError:
        raise argparse.ArgumentTypeError(f"expected seconds since the client started, got {v!r}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", help="compare_<t>/manifest.txt: lines '<arm> <run dir name> <client dir name>'")
    ap.add_argument("--run", help="one server run dir")
    ap.add_argument("--client", help="client dir name inside --run (default: the last client_* dir)")
    ap.add_argument("--arm", default=None, help="label for --run (default: from run.txt)")
    ap.add_argument("--out", default=None, help="output dir (default: next to the manifest, or the run dir)")
    ap.add_argument("--tier-rule", choices=("prompt", "private"), default="prompt",
                    help="recompute when under half the prompt is cached (prompt), or when over half of the prompt beyond "
                         "the shared system prompt is uncached (private)")
    ap.add_argument("--steady-state", nargs="?", const="auto", default=None, metavar="SECONDS",
                    type=steady_start,
                    help="also write compare_steady.png / compare_steady.csv over the turns sent once every arm's cached "
                         "data had outgrown device + host memory (the latest first host eviction), or "
                         "compare_steady_<SECONDS>s.png / .csv over the turns sent from SECONDS on (since the client started)")
    args = ap.parse_args()

    jobs = []
    if args.manifest:
        mpath = host_path(args.manifest)
        root = os.path.dirname(os.path.dirname(os.path.abspath(mpath)))
        for line in open(mpath):
            parts = line.split()
            if len(parts) >= 3:
                jobs.append((parts[0], os.path.join(root, parts[1]), os.path.join(root, parts[1], parts[2])))
        out_dir = args.out or os.path.dirname(os.path.abspath(mpath))
    elif args.run:
        run = host_path(args.run)
        client = os.path.join(run, args.client) if args.client else sorted(
            os.path.join(run, d) for d in os.listdir(run) if d.startswith("client_"))[-1]
        arm = args.arm
        if arm is None:
            arm = next((l.split("=", 1)[1].strip() for l in open(os.path.join(run, "run.txt")) if l.startswith("arm=")), "run")
        jobs.append((arm, run, client))
        out_dir = args.out or run
    else:
        ap.error("--manifest or --run is required")
    os.makedirs(out_dir, exist_ok=True)

    results = []
    for arm, run, client in jobs:
        cl = parse_client(os.path.join(client, "client.jsonl"), args.tier_rule)
        sv = parse_server(os.path.join(run, "server.log"), cl["t_start"], {t["rid"]: t["t0"] for t in cl["turns"]})
        m = arm_metrics(arm, cl, sv)
        results.append((arm, cl, sv, m))
        draw_timeline(arm, cl, sv, os.path.join(out_dir, f"timeline_{arm}.png"))
        write_csvs(arm, cl, sv, out_dir)
        print(f"{arm}: {m['turns']} turns / {m['conversations']} conv, wall {m['wall_s']} s; returning TTFT mean {m['ret_ttft_mean']} "
              f"p50 {m['ret_ttft_p50']} p90 {m['ret_ttft_p90']} s; hits device/host/storage/cold "
              f"{m['hits_device']}/{m['hits_host']}/{m['hits_storage']}/{m['cold_returns']}; uncached/turn {m['ret_uncached_mean']}; "
              f"d2h {m['d2h_tokens']} h2d {m['h2d_tokens']} h2s {m['h2s_tokens']} s2h {m['s2h_tokens']} "
              f"evicted dev/host {m['evict_device_tokens']}/{m['evict_host_tokens']} tokens; peak queue {m['peak_queue']}")
    if len(results) > 1:
        draw_compare(results, os.path.join(out_dir, "compare.png"))
    with open(os.path.join(out_dir, "compare.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(results[0][3].keys()))
        w.writeheader(); w.writerows([r[3] for r in results])
    if args.steady_state is not None:
        write_steady(results, out_dir, start=None if args.steady_state == "auto" else args.steady_state)
    print(f"wrote {out_dir}: " + ", ".join(sorted(x for x in os.listdir(out_dir) if x.endswith((".png", ".csv")))))
    return 0


if __name__ == "__main__":
    sys.exit(main())
