"""Campaign 32: history recomputed (ideal_cached minus cached at admission, returning requests) in a window of
admission time, split by what happened to the request, first match wins:
  refused  - a read for it was refused host room at dispatch (srs_dispatch launched=0);
  capped   - the arrival gate answered "capped" (its third lookup was used up);
  expired  - its plan timed out before it came (ntp_expire reason=timeout; under next_use the session was ended);
  staged   - a read was staged for it before arrival (ntp_stage);
  no read  - none of these and no read moved pages for it;
  read     - a read moved pages but some history was still recomputed.
Also the SSD tokens read by the same groups. nice -n 15 python3 -I -B <this> FROM_S TO_S arm ..."""
import collections
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c32common import cached, load_client, load_scan  # noqa: E402

lo, hi = float(sys.argv[1]), float(sys.argv[2])
ORDER = ("refused", "capped", "expired", "staged", "no read", "read")
for lab in sys.argv[3:]:
    ev = load_scan(lab)["rid_events"]
    reqs, _ = load_client(lab)
    again, ssd, n, n_again = collections.Counter(), collections.Counter(), collections.Counter(), collections.Counter()
    for rid, es in ev.items():
        r = reqs.get(rid)
        if r is None or r["k"] == 0 or not r["ideal_cached"]:
            continue
        t_adm = next((t for t, e, kv in es if e == "rts"), None)
        if t_adm is None or not (lo <= t_adm < hi):
            continue
        events = {e for t, e, kv in es}
        if any(e == "srs_dispatch" and kv.get("launched") == "0" for t, e, kv in es):
            g = "refused"
        elif any(e == "ntp_gate" and kv.get("decision") == "capped" for t, e, kv in es):
            g = "capped"
        elif any(e == "ntp_expire" and kv.get("reason") == "timeout" for t, e, kv in es):
            g = "expired"
        elif "ntp_stage" in events:
            g = "staged"
        elif not any(e == "prefetch_success" and int(kv["loaded"]) > 0 for t, e, kv in es):
            g = "no read"
        else:
            g = "read"
        c = cached(r)
        a = max(0, r["ideal_cached"] - sum(c.values()))
        again[g] += a
        ssd[g] += c["storage"]
        n[g] += 1
        n_again[g] += a > 0
    tot = sum(again.values())
    print(f"===== {lab}: returning requests admitted in [{lo:.0f}, {hi:.0f}) s: {sum(n.values())}; history recomputed {tot / 1e6:.2f} M tokens; "
          f"read from SSD {sum(ssd.values()) / 1e6:.2f} M")
    for g in ORDER:
        if n[g]:
            print(f"  {g:8s}: {n[g]:5d} requests, {n_again[g]:4d} recomputed some; recomputed {again[g] / 1e6:6.2f} M ({100 * again[g] / max(1, tot):5.1f} %); "
                  f"SSD {ssd[g] / 1e6:6.2f} M")
