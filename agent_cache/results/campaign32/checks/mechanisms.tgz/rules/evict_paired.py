"""Campaign 32, rule 3: on the same returning requests, how much history each arm still held in GPU or host memory at
admission (so needed no SSD read and no recompute), by the true wait before the request.
  nice -n 15 python3 -I -B <this> FROM_S TO_S arm1 arm2 ...
Requests: returning (k > 0) with ideal_cached > 0, sent in [FROM_S, TO_S) of the first arm's clock and present in every
arm. Shares are of ideal_cached (the history an unbounded cache would hold): resident = device + host at admission;
SSD = read back; again = recomputed. "missed" = requests with under 95 % resident, i.e. their history (or most of it)
had left host memory before they were admitted. Also the queue wait (server ReqTimeStats queue_duration) of each arm."""
import collections
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c32common import cached, load_client, load_scan, mean, pair_key  # noqa: E402

lo, hi = float(sys.argv[1]), float(sys.argv[2])
labels = sys.argv[3:]
arms = {}
for lab in labels:
    reqs, _ = load_client(lab)
    ev = load_scan(lab)["rid_events"]
    qwait = {}
    for rid, es in ev.items():
        for t, e, kv in es:
            if e == "rts":
                qwait[rid] = float(kv["queue_ms"]) / 1e3
    arms[lab] = ({pair_key(r): r for r in reqs.values()}, qwait)
base = arms[labels[0]][0]
keys = [k for k, r in base.items() if lo <= r["t_send"] < hi and r["k"] > 0 and (r["ideal_cached"] or 0) > 0
        and all(k in arms[lab][0] for lab in labels)]
BINS = ((0, 1), (1, 10), (10, 60), (60, 300), (300, 1e9))


def bin_of(w):
    for a, b in BINS:
        if a <= w < b:
            return (a, b)


print(f"returning requests sent in [{lo:.0f}, {hi:.0f}) s of {labels[0]}'s clock, present in all of {labels}: {len(keys)}")
print(f"{'true wait':>10s} {'reqs':>5s} | " + " | ".join(f"{lab:^44s}" for lab in labels))
print(f"{'':>10s} {'':>5s} | " + " | ".join(f"{'resident  SSD  again missed% queue_s TTFT':^44s}" for lab in labels))
groups = collections.defaultdict(list)
for k in keys:
    groups[bin_of(base[k]["wait_s"] or 0.0)].append(k)
groups[("all", "")] = keys
for g in [*BINS, ("all", "")]:
    ks = groups.get(g, [])
    if not ks:
        continue
    cells = []
    for lab in labels:
        recs, qwait = arms[lab]
        ideal = sum(recs[k]["ideal_cached"] for k in ks)
        res = sum(cached(recs[k])["device"] + cached(recs[k])["host"] for k in ks)
        ssd = sum(cached(recs[k])["storage"] for k in ks)
        missed = sum((cached(recs[k])["device"] + cached(recs[k])["host"]) < 0.95 * recs[k]["ideal_cached"] for k in ks)
        qw = mean(qwait.get(recs[k]["rid"], float("nan")) for k in ks if recs[k]["rid"] in qwait)
        cells.append(f"{res / ideal:8.3f} {ssd / ideal:5.3f} {max(0, ideal - res - ssd) / ideal:5.3f} {100 * missed / len(ks):6.1f} "
                     f"{qw:7.1f} {mean(recs[k]['ttft'] for k in ks):5.1f}")
    name = f"{g[0]}-{g[1] if g[1] != 1e9 else ''} s" if g[0] != "all" else "all"
    print(f"{name:>10s} {len(ks):5d} | " + " | ".join(cells))
