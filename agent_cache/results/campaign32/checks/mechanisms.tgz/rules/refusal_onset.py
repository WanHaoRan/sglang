"""Campaign 32: first minute with a read refused host room at dispatch (srs_dispatch launched=0) per arm, and the
refusals and recomputed history (returning requests admitted, ideal_cached minus cached) before minute 76.
  nice -n 15 python3 -I -B <this> arm ..."""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c32common import cached, load_client, load_scan  # noqa: E402
for lab in sys.argv[1:]:
    ev = load_scan(lab)["rid_events"]
    reqs, _ = load_client(lab)
    ref = sorted(t for es in ev.values() for t, e, kv in es if e == "srs_dispatch" and kv.get("launched") == "0")
    before = [t for t in ref if t < 76 * 60]
    again = 0
    for rid, es in ev.items():
        r = reqs.get(rid)
        if r is None or r["k"] == 0:
            continue
        t_adm = next((t for t, e, kv in es if e == "rts"), None)
        if t_adm is not None and 1800 <= t_adm < 76 * 60:
            again += max(0, (r["ideal_cached"] or 0) - sum(cached(r).values()))
    print(f"{lab:10s}: first refusal at minute {ref[0] / 60:.1f}; refusals before minute 76: {len(before)} "
          f"(in {len(set(int(t // 60) for t in before))} distinct minutes); history recomputed by returning requests finishing in minutes 30-76: {again / 1e6:.2f} M tokens")
