"""Campaign 32: host-pool pins of landed storage reads and reads refused host room, per arm and ten minutes.
  nice -n 15 python3 -I -B <this> ec_full jit_p50 jit_exact ...
Pins: srs_pin / srs_unpin pairs per rid (pinned until the request is admitted, replaced, aborted or 600 s old);
a pin's token-seconds are split at the request's arrival (ntp_arrive, else the client's send time): before it, a
read staged for a turn not here yet; after it, a read for a queued turn. Pinned total: the engine's own running
total (the pinned= field), carried forward second by second.
Refused: srs_dispatch with launched=0 (the read got no host pages at dispatch and was revoked whole: room refused,
or the operation had been terminated), tokens = pages x 64; cut: a launched read whose prefetch success completed
fewer tokens than it was dispatched with. ec_full/ec_exact log their own refusals in ec_price (refused=), compared."""
import collections
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c32common import load_client, load_scan  # noqa: E402

PAGE = 64
W = 600.0
for label in sys.argv[1:]:
    scan = load_scan(label)
    reqs, _ = load_client(label)
    ev = scan["rid_events"]
    end_t = max(int(k) for k in scan["per_sec"]) + 1
    # ----- pins -----
    pin_ts = collections.defaultdict(lambda: [0.0, 0.0])  # window -> [token-s before arrival, after]
    pins_n = collections.Counter()
    reasons = collections.Counter()
    staged_pin_reasons = collections.Counter()
    staged_hold = []
    for rid, es in ev.items():
        arrive = next((t for t, e, kv in es if e == "ntp_arrive"), None)
        if arrive is None and rid in reqs:
            arrive = reqs[rid]["t_send"]
        open_pin = None
        for t, e, kv in es:
            if e == "srs_pin":
                open_pin = (t, int(kv["tokens"]))
            elif e == "srs_unpin" and open_pin is not None:
                t1, tok = open_pin
                open_pin = None
                spans = []
                if arrive is not None and t1 < arrive:
                    spans.append((t1, min(t, arrive), 0))
                    if t > arrive:
                        spans.append((arrive, t, 1))
                    pins_n["before arrival"] += 1
                    staged_pin_reasons[kv["reason"]] += 1
                    staged_hold.append(min(t, arrive) - t1)
                else:
                    spans.append((t1, t, 1))
                    pins_n["queued"] += 1
                reasons[kv["reason"]] += 1
                for a, b, which in spans:
                    x = a
                    while x < b:
                        w = int(x // W)
                        y = min(b, (w + 1) * W)
                        pin_ts[w][which] += tok * (y - x)
                        x = y
    # ----- the engine's pinned total, carried forward -----
    pinned_mean = collections.defaultdict(list)
    cur = 0
    per_sec = scan["per_sec"]
    for s in range(0, end_t):
        cell = per_sec.get(str(s))
        if cell is not None and cell[4] > 0:
            cur = cell[3]
        pinned_mean[int(s // W)].append(cur)
    # ----- refusals -----
    refused = collections.defaultdict(lambda: [0, 0])
    cut = collections.defaultdict(lambda: [0, 0])
    for rid, es in ev.items():
        pending = None
        for t, e, kv in es:
            if e == "srs_dispatch":
                pages = int(kv["pages"])
                if kv.get("launched") == "0":
                    refused[int(t // W)][0] += 1
                    refused[int(t // W)][1] += pages * PAGE
                    pending = None
                else:
                    pending = (t, pages * PAGE)
            elif e == "prefetch_success" and pending is not None:
                short = pending[1] - int(kv["completed"])
                if short > 0:
                    cut[int(t // W)][0] += 1
                    cut[int(t // W)][1] += short
                pending = None
    own = collections.defaultdict(int)
    for t, kv in scan.get("price", []):
        own[int(t // W)] += int(kv["refused"])
    print(f"===== {label}: pins {dict(pins_n)}; unpin reasons {dict(reasons)}; pins that began before arrival, by reason "
          f"{dict(staged_pin_reasons)}; held before arrival: mean {sum(staged_hold) / max(1, len(staged_hold)):.1f} s")
    print(" minutes | pinned total K (mean) | pin K tokens held: before arrival, queued | refused at dispatch: reads, K tokens | "
          "cut short: reads, K tokens | own ec_price refused K")
    tot = [0.0, 0.0, 0, 0, 0, 0]
    for w in range(0, int(end_t // W) + 1):
        pm = pinned_mean.get(w, [0])
        b, a = pin_ts[w]
        print(f" {10 * w:3d}-{10 * w + 10:3d} | {sum(pm) / len(pm) / 1e3:21.0f} | {b / W / 1e3:21.0f} {a / W / 1e3:7.0f} | "
              f"{refused[w][0]:20d} {refused[w][1] / 1e3:9.0f} | {cut[w][0]:16d} {cut[w][1] / 1e3:8.0f} | {own[w] / 1e3:10.0f}")
        if 3 <= w < 11:
            tot[0] += b
            tot[1] += a
            tot[2] += refused[w][0]
            tot[3] += refused[w][1]
            tot[4] += cut[w][1]
            tot[5] += own[w]
    print(f" minutes 30-110: pins held on average {tot[0] / 4800 / 1e3:.0f} K tokens before arrival and {tot[1] / 4800 / 1e3:.0f} K for queued "
          f"turns; refused at dispatch {tot[2]} reads, {tot[3] / 1e6:.2f} M tokens; cut short {tot[4] / 1e6:.2f} M tokens; own refused {tot[5] / 1e6:.2f} M")
