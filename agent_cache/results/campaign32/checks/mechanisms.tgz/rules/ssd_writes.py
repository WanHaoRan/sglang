"""Campaign 32: the SSD write-through backlog per minute of the client clock: tokens submitted for backup to the SSD
(h2s_submit), tokens written (h2s_done), the backlog submitted-but-not-done at the minute's end, and the write I/O
time (h2s_io ms); plus reads refused host room at dispatch (srs_dispatch launched=0). One pass over server.log.
  nice -n 15 python3 -I -B <this> FROM_MIN TO_MIN arm ..."""
import calendar
import collections
import json
import re
import sys
AC = "/home/wanhr/sglang/agent_cache"
lo, hi = int(sys.argv[1]), int(sys.argv[2])
man = {}
for line in open(f"{AC}/results/campaign32/manifest.txt"):
    if line.strip():
        a, r, p = line.split()[:3]
        man[a] = (r, p)
STAMP = re.compile(r"^\[(\d{4})-(\d\d)-(\d\d) (\d\d):(\d\d):(\d\d)\.(\d{3})\]")
for lab in sys.argv[3:]:
    run, prog = man[lab]
    with open(f"{AC}/results/{run}/{prog}/client.jsonl") as f:
        t0 = json.loads(f.readline())["t_start"]
    sub, done, io, ref = collections.Counter(), collections.Counter(), collections.Counter(), collections.Counter()
    pending, backlog_end = {}, {}
    cur_min = None
    with open(f"{AC}/results/{run}/server.log", errors="replace") as f:
        for line in f:
            if "HICACHE_EVT h2s_" not in line and "srs_dispatch" not in line:
                continue
            m = STAMP.match(line)
            if not m:
                continue
            t = calendar.timegm(tuple(int(m[i]) for i in range(1, 7)) + (0, 0, 0)) + int(m[7]) / 1e3 - t0
            w = int(t // 60)
            if cur_min is not None and w != cur_min:
                for x in range(cur_min, w):
                    backlog_end[x] = sum(pending.values())
            cur_min = w
            if " h2s_submit " in line:
                op, tok = re.search(r"op=(\d+) node=\d+ tokens=(\d+)", line).groups()
                pending[op] = int(tok)
                sub[w] += int(tok)
            elif " h2s_done " in line:
                op, tok = re.search(r"op=(\d+) tokens=(\d+)", line).groups()
                pending.pop(op, None)
                done[w] += int(tok)
            elif " h2s_io " in line:
                io[w] += float(re.search(r"ms=(\d+)", line)[1])
            elif "launched=0" in line:
                ref[w] += 1
    print(f"===== {lab}: minute | SSD writes submitted K tok, done K tok, backlog at end K tok, write I/O s | refused reads")
    for w in range(lo, hi):
        print(f"  {w:3d} | {sub[w] / 1e3:7.0f} {done[w] / 1e3:7.0f} {backlog_end.get(w, 0) / 1e3:8.0f} {io[w] / 1e3:6.1f} | {ref[w]:3d}")
