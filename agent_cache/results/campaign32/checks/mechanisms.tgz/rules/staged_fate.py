"""Campaign 32, rule 1: the reads an arm staged before their request arrived (ntp_stage), what became of them, and
what the rules arm did for the same turns. nice -n 15 python3 -I -B <this> jit_p50 ec_full [other arms to compare]
For each staged rid of the first arm: did the read move pages before the request arrived ("prefetch success" with
loaded > 0 before ntp_arrive), did it get a pin, and how the pin ended (admit: the turn took it; abort: the plan
expired or was dropped first; replaced: a later read of the same rid); the I/O time of those reads (s2h_io ms), the
pin's token-seconds before the arrival, whether the turn came at all (a client record), and when relative to the
plan's expiry. For the same turns (play, stream, k) in the other arms: the expected-cost decisions logged (ec_start),
the first arrival-gate decision, the history delivered at admission (device+host+storage over ideal_cached), from
SSD, recomputed, and TTFT. Arrival is ntp_arrive, else the client's send time."""
import collections
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c32common import CUT, cached, load_client, load_scan, mean, pair_key, q  # noqa: E402

first = sys.argv[1]
others = sys.argv[2:]


def arm_tables(label):
    scan = load_scan(label)
    reqs, _ = load_client(label)
    by_key = {pair_key(r): r for r in reqs.values()}
    return scan["rid_events"], reqs, by_key


def arrival_of(es, rec):
    t = next((t for t, e, kv in es if e == "ntp_arrive"), None)
    if t is None and rec is not None:
        t = rec["t_send"]
    return t


def delivered(rec):
    c = cached(rec)
    ideal = rec.get("ideal_cached") or 0
    if ideal <= 0:
        return None
    return {"all": sum(c.values()) / ideal, "ssd": c["storage"] / ideal, "again": max(0, ideal - sum(c.values())) / ideal,
            "resident": (c["device"] + c["host"]) / ideal}


ev, reqs, by_key = arm_tables(first)
oth = {lab: arm_tables(lab) for lab in others}
rows = []
for rid, es in ev.items():
    stages = [t for t, e, kv in es if e == "ntp_stage"]
    if not stages:
        continue
    rec = reqs.get(rid)
    arr = arrival_of(es, rec)
    t_stage = stages[0]
    expire = next(((t, kv) for t, e, kv in es if e == "ntp_expire"), None)
    plan = next((kv for t, e, kv in es if e == "ntp_plan"), None)
    before = arr if arr is not None else float("inf")
    loaded = sum(int(kv["loaded"]) for t, e, kv in es if e == "prefetch_success" and t < before)
    io_ms = sum(float(kv["ms"]) for t, e, kv in es if e == "s2h_io" and t < before)
    stage_tokens = sum(int(kv["tokens"]) for t, e, kv in es if e == "ntp_stage")
    pin = None
    pin_ts = 0.0
    for t, e, kv in es:
        if e == "srs_pin" and t < before and pin is None:
            pin = [t, int(kv["tokens"]), None, None]
        elif e == "srs_unpin" and pin is not None and pin[2] is None:
            pin[2], pin[3] = t, kv["reason"]
    if pin is not None:
        end = pin[2] if pin[2] is not None else before
        pin_ts = pin[1] * max(0.0, min(end, before) - pin[0])
    rows.append({"rid": rid, "rec": rec, "arr": arr, "t_stage": t_stage, "expire": expire, "plan": plan,
                 "loaded": loaded, "io_ms": io_ms, "stage_tokens": stage_tokens, "pin": pin, "pin_ts": pin_ts})

print(f"===== {first}: {len(rows)} requests with a read staged before arrival (ntp_stage)")
came = [r for r in rows if r["rec"] is not None]
print(f"  turn recorded by the client: {len(came)}; sent before {CUT:.0f} s: {sum(r['rec']['t_send'] < CUT for r in came)}")
moved = [r for r in rows if r["loaded"] > 0]
print(f"  read moved pages before arrival: {len(moved)} ({sum(r['loaded'] for r in moved) / 1e6:.2f} M tokens, "
      f"{sum(r['io_ms'] for r in rows) / 1e3:.0f} s of read-thread I/O before arrival); staged tokens asked {sum(r['stage_tokens'] for r in rows) / 1e6:.2f} M")
pins = [r for r in rows if r["pin"] is not None]
reasons = collections.Counter(r["pin"][3] for r in pins)
print(f"  pinned before arrival: {len(pins)}; pin ended by {dict(reasons)}; pin token-seconds before arrival {sum(r['pin_ts'] for r in pins) / 1e6:.0f} M "
      f"(= {sum(r['pin_ts'] for r in pins) / 4800 / 1e3:.0f} K tokens held on average over 80 minutes)")
for reason in ("admit", "abort", "replaced"):
    rs = [r for r in pins if r["pin"][3] == reason]
    if rs:
        held = [min(r["pin"][2] or r["arr"] or 0, r["arr"] or 1e18) - r["pin"][0] for r in rs]
        print(f"    {reason:8s}: {len(rs):4d} pins, {sum(r['pin'][1] for r in rs) / 1e6:.2f} M tokens, held before arrival median {q(held, .5):.1f} s, "
              f"mean {mean(held):.1f} s; turn came later: {sum(r['rec'] is not None for r in rs)}")
exp = [r for r in rows if r["expire"] is not None]
print(f"  plans expired (ntp_expire) among them: {len(exp)} (staged=1: {sum(r['expire'][1].get('staged') == '1' for r in exp)}); "
      f"of those the turn came after the expiry: {sum(r['rec'] is not None and r['arr'] is not None and r['arr'] > r['expire'][0] for r in exp)}")
lead = [r["arr"] - r["t_stage"] for r in came if r["arr"] is not None]
print(f"  stage to arrival, s: median {q(lead, .5):.1f}, p10 {q(lead, .1):.1f}, p90 {q(lead, .9):.1f}; "
      f"hinted gap (plan gap_ms) median {q([int(r['plan']['gap_ms']) / 1e3 for r in rows if r['plan']], .5):.1f} s")

# ----- outcome of the same turns -----
keys = [pair_key(r["rec"]) for r in came if r["rec"]["t_send"] < CUT]
print(f"\n  the same turns (sent before {CUT:.0f} s in {first}), in each arm: requests | TTFT mean | history delivered mean, "
      f"resident in GPU+host at admission, from SSD, recomputed (shares of ideal_cached)")
for lab, (oev, oreqs, okey) in [(first, (ev, reqs, by_key))] + list(oth.items()):
    recs = [okey[k] for k in keys if k in okey and okey[k]["t_send"] < CUT]
    ds = [d for d in (delivered(r) for r in recs) if d is not None]
    print(f"    {lab:10s} | {len(recs):5d} | {mean(r['ttft'] for r in recs):6.2f} s | {mean(d['all'] for d in ds):.3f} "
          f"{mean(d['resident'] for d in ds):.3f} {mean(d['ssd'] for d in ds):.3f} {mean(d['again'] for d in ds):.3f}")
    if lab != first:
        dec = collections.Counter()
        gate = collections.Counter()
        for r in recs:
            es = oev.get(r["rid"], [])
            ds_ = [kv["decision"] for t, e, kv in es if e == "ec_start"]
            dec[" > ".join(ds_) if ds_ else "no decision logged"] += 1
            g = next((kv["decision"] for t, e, kv in es if e == "ntp_gate"), "no gate event")
            gate[g] += 1
        print(f"      {lab} decisions for them: {dict(dec.most_common(6))}")
        print(f"      {lab} first gate decision: {dict(gate)}")
