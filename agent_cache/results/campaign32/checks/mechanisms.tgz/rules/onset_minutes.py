"""Campaign 32: per minute of the client clock around a storm's onset, for several arms: reads refused host room at
dispatch (srs_dispatch launched=0; reads, K tokens), reads that moved pages (prefetch success loaded>0; K tokens),
host evictions (evict_host, K tokens), the engine's pinned total (K, last value in the minute), parked reads
waiting for dispatch at the minute's end (srs_park without srs_dispatch yet), requests admitted that minute with history
recomputed (ReqTimeStats input - cached over the client's ideal_cached, K tokens), and arrival-gate "capped" answers.
  nice -n 15 python3 -I -B <this> FROM_MIN TO_MIN arm1 arm2 ..."""
import collections
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c32common import cached, load_client, load_scan  # noqa: E402

lo, hi = int(sys.argv[1]), int(sys.argv[2])
labels = sys.argv[3:]
rows = {}
for lab in labels:
    scan = load_scan(lab)
    reqs, _ = load_client(lab)
    ev = scan["rid_events"]
    m = collections.defaultdict(lambda: collections.Counter())
    parks = []
    for rid, es in ev.items():
        park_t = None
        for t, e, kv in es:
            w = int(t // 60)
            if e == "srs_dispatch":
                if kv.get("launched") == "0":
                    m[w]["refused"] += 1
                    m[w]["refused_tok"] += int(kv["pages"]) * 64
                if park_t is not None:
                    parks.append((park_t, t))
                    park_t = None
            elif e == "srs_park":
                park_t = t
            elif e == "prefetch_success" and int(kv["loaded"]) > 0:
                m[w]["read_tok"] += int(kv["loaded"])
            elif e == "ntp_gate" and kv.get("decision") == "capped":
                m[w]["capped"] += 1
            elif e == "rts":
                r = reqs.get(rid)
                if r is not None and r["k"] > 0:
                    got = sum(cached(r).values())
                    m[w]["again_tok"] += max(0, (r["ideal_cached"] or 0) - got)
        if park_t is not None:
            parks.append((park_t, 1e9))
    for s, cell in scan["per_sec"].items():
        w = int(s) // 60
        m[w]["evict_host"] += cell[0]
        if cell[4] > 0:
            m[w]["pinned"] = cell[3]
    for w in range(lo, hi):
        end = (w + 1) * 60
        m[w]["parked"] = sum(1 for a, b in parks if a <= end < b)
    rows[lab] = m
hdr = "refused Ktok | read Ktok | evictH K | pinned K | parked | again K | capped"
print("min | " + " | ".join(f"{lab:^62s}" for lab in labels))
print("    | " + " | ".join(f"{hdr:^62s}" for lab in labels))
for w in range(lo, hi):
    cells = []
    for lab in labels:
        c = rows[lab][w]
        cells.append(f"{c['refused']:3d} {c['refused_tok'] / 1e3:6.0f} | {c['read_tok'] / 1e3:6.0f} | {c['evict_host'] / 1e3:6.0f} | {c['pinned'] / 1e3:5.0f} | "
                     f"{c['parked']:4d} | {c['again_tok'] / 1e3:6.0f} | {c['capped']:3d}")
    print(f"{w:3d} | " + " | ".join(cells))
