"""Campaign 32, the rules arms: the price lines (ec_price: price, staged token average, harm), the counts of staged
reads, releases and bumps, and what followed each expected-cost "wait" decision (ec_start): the next decision for the
same plan, or the turn's arrival (ntp_arrive) with no decision in between; the planned start (start_ms) against the time
the turn actually took to arrive. nice -n 15 python3 -I -B <this> ec_full ec_exact"""
import collections
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c32common import load_scan, q  # noqa: E402
for lab in sys.argv[1:]:
    scan = load_scan(lab)
    ev = scan["rid_events"]
    pr = scan["price"]
    prices = {kv["price"] for t, kv in pr}
    print(f"===== {lab}: {len(pr)} ec_price lines; distinct prices {sorted(prices)}; max staged {max(int(kv['staged']) for t, kv in pr)}; "
          f"max harm_ms {max(int(kv['harm_ms']) for t, kv in pr)}; lines with refused>0: {sum(int(kv['refused']) > 0 for t, kv in pr)}")
    cnt = collections.Counter(e for es in ev.values() for t, e, kv in es if e in ("ntp_stage", "ec_release", "ec_bump", "ec_start"))
    print(f"  events: {dict(cnt)}")
    nxt = collections.Counter()
    planned, actual = [], []
    plans_with_wait = 0
    for rid, es in ev.items():
        seq = [(t, e, kv) for t, e, kv in es if e in ("ec_start", "ntp_arrive", "ntp_expire")]
        had = False
        for i, (t, e, kv) in enumerate(seq):
            if e == "ec_start" and kv["decision"] == "wait":
                had = True
                follow = seq[i + 1] if i + 1 < len(seq) else None
                if follow is None:
                    nxt["nothing after (turn never came, plan dropped)"] += 1
                elif follow[1] == "ec_start":
                    nxt["then " + follow[2]["decision"]] += 1
                else:
                    nxt["then the turn " + ("arrived" if follow[1] == "ntp_arrive" else "plan expired")] += 1
                    if follow[1] == "ntp_arrive" and kv["start_ms"] != "na":
                        planned.append(int(kv["start_ms"]) / 1e3)
                        actual.append(follow[0] - t)
        plans_with_wait += had
    print(f"  plans with a 'wait' decision: {plans_with_wait}; what followed each 'wait': {dict(nxt)}")
    if planned:
        print(f"  'wait' followed by the arrival: planned start in s p50 {q(planned, .5):.1f} (p10 {q(planned, .1):.1f}, p90 {q(planned, .9):.1f}); "
              f"the turn arrived after s p50 {q(actual, .5):.1f} (p10 {q(actual, .1):.1f}, p90 {q(actual, .9):.1f}); "
              f"arrived before the planned start: {sum(a < p for p, a in zip(planned, actual))} of {len(planned)}")
