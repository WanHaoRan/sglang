"""Campaign 32: the SSD device (iostat_vdc.log, 10 s samples, host clock UTC) against each arm's client clock, with the
engine's SSD write thread time (h2s_io ms) and reads refused host room (srs_dispatch launched=0), in windows.
  nice -n 15 python3 -I -B <this> WINDOW_MIN FROM_MIN TO_MIN arm ...
Per window: device read and write MB/s, %util, r_await and w_await (ms), the engine's write I/O seconds per minute
(60 = the one write thread always busy), write throughput (K tokens per second of write I/O), and refused reads."""
import calendar
import collections
import datetime as dt
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c32common import AC, manifest  # noqa: E402

win, lo, hi = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
samples = []
with open(f"{AC}/results/campaign32/iostat_vdc.log") as f:
    t = None
    for line in f:
        m = re.match(r"^(\d\d)/(\d\d)/(\d{4}) (\d\d):(\d\d):(\d\d) (AM|PM)", line)
        if m:
            mo, d, y, h, mi, s, ap = m.groups()
            h = int(h) % 12 + (12 if ap == "PM" else 0)
            t = calendar.timegm((int(y), int(mo), int(d), h, int(mi), int(s), 0, 0, 0))
            continue
        if line.startswith("vdc") and t is not None:
            v = line.split()
            # r/s rkB/s rrqm/s %rrqm r_await rareq-sz w/s wkB/s wrqm/s %wrqm w_await ... %util
            samples.append((t, float(v[2]), float(v[8]), float(v[5]), float(v[11]), float(v[-1])))
STAMP = re.compile(r"^\[(\d{4})-(\d\d)-(\d\d) (\d\d):(\d\d):(\d\d)\.(\d{3})\]")
man = manifest()
for lab in sys.argv[4:]:
    run, prog = man[lab]
    with open(f"{AC}/results/{run}/{prog}/client.jsonl") as f:
        t0 = json.loads(f.readline())["t_start"]
    io_ms, wtok, ref = collections.Counter(), collections.Counter(), collections.Counter()
    with open(f"{AC}/results/{run}/server.log", errors="replace") as f:
        for line in f:
            if " h2s_io " not in line and "launched=0" not in line:
                continue
            m = STAMP.match(line)
            tt = calendar.timegm(tuple(int(m[i]) for i in range(1, 7)) + (0, 0, 0)) + int(m[7]) / 1e3 - t0
            w = int(tt // 60 // win)
            if " h2s_io " in line:
                mm = re.search(r"tokens=(\d+) ms=(\d+)", line)
                wtok[w] += int(mm[1])
                io_ms[w] += float(mm[2])
            else:
                ref[w] += 1
    dev = collections.defaultdict(list)
    for s in samples:
        w = int((s[0] - t0) // 60 // win)
        if lo // win <= w < hi // win:
            dev[w].append(s)
    print(f"===== {lab}: minutes | SSD read MB/s, write MB/s, %util, r_await ms, w_await ms | engine write I/O s/min, "
          f"write K tok per I/O s | refused reads")
    for w in range(lo // win, hi // win):
        d = dev.get(w, [])
        n = max(1, len(d))
        r_mb = sum(x[1] for x in d) / n / 1024
        w_mb = sum(x[2] for x in d) / n / 1024
        util = sum(x[5] for x in d) / n
        ra = sum(x[3] for x in d) / n
        wa = sum(x[4] for x in d) / n
        print(f"  {win * w:3d}-{win * w + win:3d} | {r_mb:7.0f} {w_mb:6.0f} {util:6.1f} {ra:7.1f} {wa:7.1f} | {io_ms[w] / 1e3 / win:6.1f} "
              f"{wtok[w] / max(1e-9, io_ms[w]):8.1f} | {ref[w]:4d}")
