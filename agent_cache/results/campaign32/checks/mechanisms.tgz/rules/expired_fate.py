"""Campaign 32: the plans an arm dropped before their turn came (ntp_expire reason=timeout), and the turns that came
after it. nice -n 15 python3 -I -B <this> jit_p50 ec_full jit_exact
Under the just-in-time engine with next_use eviction a timed-out plan also ends its session in the eviction registry
(nue_register next_use_ms=ended for the same rid at the expiry: TIER_ENDED, evicted first). For the turns that came
later and were sent before 6,600 s: hinted gap, true wait, how long after the expiry they came, and in each arm the
history at admission (shares of ideal_cached: resident in GPU or host, from SSD, recomputed) and TTFT. The rules arm
keeps its plans until the turn comes or 1,800 s pass, so it has none of these."""
import collections
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c32common import CUT, cached, load_client, load_scan, mean, pair_key, q  # noqa: E402


def tables(label):
    scan = load_scan(label)
    reqs, _ = load_client(label)
    return scan["rid_events"], reqs, {pair_key(r): r for r in reqs.values()}


def shares(recs):
    ideal = sum(r["ideal_cached"] or 0 for r in recs)
    c = collections.Counter()
    for r in recs:
        for k, v in cached(r).items():
            c[k] += v
    if not ideal:
        return "n/a"
    got = c["device"] + c["host"] + c["storage"]
    return f"resident {(c['device'] + c['host']) / ideal:.3f}, SSD {c['storage'] / ideal:.3f}, recomputed {max(0, ideal - got) / ideal:.3f}"


first, others = sys.argv[1], sys.argv[2:]
ev, reqs, by_key = tables(first)
oth = {lab: tables(lab) for lab in others}
expired = []
ended_after = 0
for rid, es in ev.items():
    exp = [(t, kv) for t, e, kv in es if e == "ntp_expire" and kv.get("reason") == "timeout"]
    if not exp:
        continue
    t_exp = exp[0][0]
    if any(e == "nue_register" and kv.get("next_use_ms") == "ended" and abs(t - t_exp) < 0.01 for t, e, kv in es):
        ended_after += 1
    plan = next((kv for t, e, kv in es if e == "ntp_plan"), None)
    staged = exp[0][1].get("staged") == "1"
    expired.append((rid, t_exp, plan, staged))
print(f"===== {first}: {len(expired)} plans timed out before their turn came; {ended_after} of them registered the session as ended at that moment")
came = [(rid, t, p, s) for rid, t, p, s in expired if rid in reqs]
print(f"  the turn came later: {len(came)} (sent before {CUT:.0f} s: {sum(reqs[rid]['t_send'] < CUT for rid, *_ in came)}); staged read before: "
      f"{sum(s for *_, s in came)}")
late = [reqs[rid]["t_send"] - t for rid, t, p, s in came]
gaps = [int(p["gap_ms"]) / 1e3 for rid, t, p, s in came if p]
waits = [reqs[rid]["wait_s"] for rid, *_ in came]
print(f"  hinted gap median {q(gaps, .5):.1f} s (p90 {q(gaps, .9):.1f}); true wait median {q(waits, .5):.1f} s (p10 {q(waits, .1):.1f}, p90 {q(waits, .9):.1f}); "
      f"sent after the expiry by median {q(late, .5):.1f} s (p90 {q(late, .9):.1f})")
keys = [pair_key(reqs[rid]) for rid, *_ in came if reqs[rid]["t_send"] < CUT]
print(f"  the same {len(keys)} turns in each arm: requests | TTFT mean | history at admission")
for lab, (oev, oreqs, okey) in [(first, (ev, reqs, by_key))] + list(oth.items()):
    recs = [okey[k] for k in keys if k in okey and okey[k]["t_send"] < CUT]
    print(f"    {lab:10s} | {len(recs):5d} | {mean(r['ttft'] for r in recs):6.2f} s | {shares(recs)}")
# ----- by send window -----
print("  by the first arm's send time (minutes): turns after an expiry | their share of the arm's returning requests sent then")
win = collections.Counter(int(reqs[rid]["t_send"] // 600) for rid, *_ in came if reqs[rid]["t_send"] < CUT)
allret = collections.Counter(int(r["t_send"] // 600) for r in reqs.values() if r["t_send"] < CUT and r["k"] > 0)
for w in sorted(allret):
    print(f"    {10 * w:3d}-{10 * w + 10:3d} | {win[w]:4d} | {100 * win[w] / allret[w]:5.1f} %")
