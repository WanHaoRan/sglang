"""Campaign 32, ec_full: the expected-cost 'wait' decisions (ec_start): planned start, the read and queue-wait estimates,
the stall a read at arrival would cost (read - wait) and the rent of pinning the read at the fixed price (5e-5 x tokens,
a lower bound: the engine charges the tokens of the key not in device memory). nice -n 15 python3 -I -B <this> ec_full"""
import json
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c32common import HERE, q  # noqa: E402
lab = sys.argv[1]
d = json.load(open(f"{HERE}/scan_{lab}.json"))
st, rd, wt, tok, plans, withdec = [], [], [], [], 0, 0
for es in d["rid_events"].values():
    plans += any(e == "ntp_plan" for t, e, kv in es)
    decs = [kv for t, e, kv in es if e == "ec_start"]
    withdec += bool(decs)
    for kv in decs:
        if kv["decision"] == "wait":
            st.append(int(kv["start_ms"]) / 1e3)
            rd.append(int(kv["read_ms"]) / 1e3)
            wt.append(int(kv["wait_ms"]) / 1e3)
            tok.append(int(kv["tokens"]))
print(f"{lab}: plans {plans}, with an expected-cost decision {withdec}; 'wait' decisions {len(st)}: planned start s p10 {q(st, .1):.0f}, "
      f"p50 {q(st, .5):.0f}, p90 {q(st, .9):.0f}; read estimate p50 {q(rd, .5):.2f} s, queue wait estimate p50 {q(wt, .5):.2f} s, "
      f"stall at arrival p50 {q([max(0, a - b) for a, b in zip(rd, wt)], .5):.2f} s; tokens p50 {q(tok, .5):.0f}, rent at 5e-5 >= {5e-5 * q(tok, .5):.2f} s per s")
