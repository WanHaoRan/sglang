"""Campaign 32: where a paired TTFT difference comes from, by the reference arm's send time.
  nice -n 15 python3 -I -B <this> A B [A B ...]
Pairs as compare_arms.py does: requests sent before 6,600 s in both arms, matched by (play, stream, k). Each row is a
bin of A's send time (5 minutes): pairs, mean TTFT of A and B, mean B - A, and the bin's share of the overall mean
(its sum of B - A over all pairs), so the rows add up to compare_arms.out's B - A."""
import collections
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c32common import CUT, load_client, pair_key  # noqa: E402

cache = {}


def arm(label):
    if label not in cache:
        reqs, _ = load_client(label)
        cache[label] = {pair_key(r): r for r in reqs.values() if r["t_send"] < CUT}
    return cache[label]


args = sys.argv[1:]
for a_label, b_label in zip(args[::2], args[1::2]):
    a, b = arm(a_label), arm(b_label)
    keys = a.keys() & b.keys()
    bins = collections.defaultdict(lambda: [0, 0.0, 0.0])
    for k in keys:
        w = int(a[k]["t_send"] // 300)
        c = bins[w]
        c[0] += 1
        c[1] += a[k]["ttft"]
        c[2] += b[k]["ttft"]
    n = len(keys)
    total = sum(c[2] - c[1] for c in bins.values()) / n
    print(f"===== {a_label} -> {b_label}: {n} pairs, B - A {total:+.2f} s")
    print(" minutes (A send) | pairs | A mean  B mean |  B - A | share of the overall B - A, s | running sum")
    run = 0.0
    for w in sorted(bins):
        c = bins[w]
        part = (c[2] - c[1]) / n
        run += part
        print(f"   {5 * w:3d}-{5 * w + 5:3d}       | {c[0]:5d} | {c[1] / c[0]:6.2f} {c[2] / c[0]:6.2f} | {(c[2] - c[1]) / c[0]:+6.2f} | {part:+29.2f} | {run:+.2f}")
