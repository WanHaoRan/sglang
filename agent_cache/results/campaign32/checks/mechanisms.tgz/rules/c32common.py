"""Shared loaders for the campaign 32 rule analyses in this folder (stdlib only)."""
import json
import os

AC = "/home/wanhr/sglang/agent_cache"
HERE = os.path.dirname(os.path.abspath(__file__))
CUT = 6600.0


def manifest():
    out = {}
    with open(f"{AC}/results/campaign32/manifest.txt") as f:
        for line in f:
            if line.strip():
                label, run, programs = line.split()[:3]
                out[label] = (run, programs)
    return out


def load_scan(label):
    with open(f"{HERE}/scan_{label}.json") as f:
        return json.load(f)


def load_client(label):
    """rid -> request record (profile phase, with a TTFT), and the run record."""
    run, programs = manifest()[label]
    reqs, head = {}, None
    with open(f"{AC}/results/{run}/{programs}/client.jsonl") as f:
        for line in f:
            r = json.loads(line)
            if r["kind"] == "run":
                head = r
            elif r["kind"] == "req" and r.get("phase") == "profile" and r.get("ttft") is not None and not r.get("error"):
                reqs[r["rid"]] = r
    return reqs, head


def cached(r):
    d = r.get("cached_details") or {}
    if not d:
        return {"device": int(r.get("cached_tokens") or 0), "host": 0, "storage": 0}
    return {k: int(d.get(k) or 0) for k in ("device", "host", "storage")}


def pair_key(r):
    return (r["play"], r["stream"], r["k"])


def q(values, p):
    v = sorted(values)
    return v[min(len(v) - 1, int(p * (len(v) - 1) + 0.5))] if v else float("nan")


def mean(values):
    values = list(values)
    return sum(values) / len(values) if values else float("nan")
