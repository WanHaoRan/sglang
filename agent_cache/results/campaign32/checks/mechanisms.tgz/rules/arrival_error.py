"""Campaign 32: how exact the hints were: arrival at the scheduler minus the predicted arrival (ntp_arrive arr_err_ms),
arrivals before 6,600 s. nice -n 15 python3 -I -B <this> arm ..."""
import json
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c32common import HERE, q  # noqa: E402
for lab in sys.argv[1:]:
    d = json.load(open(f"{HERE}/scan_{lab}.json"))
    errs = [int(kv["arr_err_ms"]) / 1e3 for es in d["rid_events"].values() for t, e, kv in es
            if e == "ntp_arrive" and kv["arr_err_ms"] != "na" and t < 6600]
    print(f"{lab:10s} arrivals {len(errs)}; arrival minus predicted, s: p10 {q(errs, .1):.2f} p50 {q(errs, .5):.2f} p90 {q(errs, .9):.2f} "
          f"p99 {q(errs, .99):.2f}; later than +5 s: {sum(x > 5 for x in errs)}, +60 s: {sum(x > 60 for x in errs)}")
