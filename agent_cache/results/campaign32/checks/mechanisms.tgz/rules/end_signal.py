"""Campaign 32: the end-of-session signal as the engine saw it. Per arm: eviction registrations of a session as ended
(nue_register next_use_ms=ended), split into those at a turn's commit (the turn carried no usable hint: an exact arm's
last turn, a table hint marked ended, or a table with no entry for the reply) and the rest (a plan timed out, an
abort); and how many of the sessions ended at a commit sent another request on the same stream later (a false end).
By the commit's minute (10-minute bins) up to 6,600 s. nice -n 15 python3 -I -B <this> arm ..."""
import collections
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c32common import load_client, load_scan  # noqa: E402
for lab in sys.argv[1:]:
    ev = load_scan(lab)["rid_events"]
    reqs, _ = load_client(lab)
    by_stream = collections.defaultdict(list)
    for r in reqs.values():
        by_stream[(r["play"], r["stream"])].append(r)
    later = {}
    for k, rs in by_stream.items():
        rs.sort(key=lambda r: r["k"])
        for a, b in zip(rs, rs[1:]):
            later[a["rid"]] = b
    at_commit, other, false_end = collections.Counter(), collections.Counter(), collections.Counter()
    for rid, es in ev.items():
        rts_t = next((t for t, e, kv in es if e == "rts"), None)
        for t, e, kv in es:
            if e != "nue_register" or kv.get("next_use_ms") != "ended" or t >= 6600:
                continue
            w = int(t // 600)
            if rts_t is not None and abs(t - rts_t) < 0.05:
                at_commit[w] += 1
                if rid in later:
                    false_end[w] += 1
            else:
                other[w] += 1
    print(f"===== {lab}: sessions registered ended before 6,600 s: at a commit {sum(at_commit.values())} "
          f"(of which the stream sent again later: {sum(false_end.values())}), otherwise {sum(other.values())}")
    print("   minutes: " + " ".join(f"{10 * w}-{10 * w + 10}:{at_commit[w]}/{false_end[w]}/{other[w]}" for w in range(11)))
