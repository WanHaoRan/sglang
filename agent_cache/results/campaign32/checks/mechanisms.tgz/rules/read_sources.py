"""Campaign 32: tokens read back from the SSD ("HiCache prefetch success ... loaded=", by landing time) in a window of
the client clock, split by what the read was for, first match wins:
  staged    - landed before its request arrived (a read staged on the hint);
  expired   - for a turn whose plan had timed out before it came (session ended in the eviction registry);
  wasted    - (part of staged) the staged read's pin was given back at an abort (plan expiry) before the turn came;
  queued    - for an arrived request, by any other trigger.
Also the read-thread I/O seconds (s2h_io ms) of the same groups. nice -n 15 python3 -I -B <this> FROM_S TO_S arm ..."""
import collections
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c32common import load_client, load_scan  # noqa: E402

lo, hi = float(sys.argv[1]), float(sys.argv[2])
for lab in sys.argv[3:]:
    ev = load_scan(lab)["rid_events"]
    reqs, _ = load_client(lab)
    tok, io = collections.Counter(), collections.Counter()
    for rid, es in ev.items():
        arr = next((t for t, e, kv in es if e == "ntp_arrive"), None)
        if arr is None and rid in reqs:
            arr = reqs[rid]["t_send"]
        expired = any(e == "ntp_expire" and kv.get("reason") == "timeout" for t, e, kv in es)
        aborted_pin = any(e == "srs_unpin" and kv.get("reason") == "abort" for t, e, kv in es)
        for t, e, kv in es:
            if not (lo <= t < hi):
                continue
            if e == "prefetch_success":
                n = int(kv["loaded"])
                key = "io_tok"
            elif e == "s2h_io":
                n = float(kv["ms"]) / 1e3
                key = "io_s"
            else:
                continue
            if arr is None or t < arr:
                g = "staged, pin given back at expiry" if aborted_pin else "staged, used or replaced"
            elif expired:
                g = "turn after its plan expired"
            else:
                g = "arrived turn"
            (tok if key == "io_tok" else io)[g] += n
    total_t, total_s = sum(tok.values()), sum(io.values())
    print(f"===== {lab}: SSD reads landing in [{lo:.0f}, {hi:.0f}) s: {total_t / 1e6:.2f} M tokens, {total_s:.0f} s of read-thread I/O")
    for g in ("staged, used or replaced", "staged, pin given back at expiry", "turn after its plan expired", "arrived turn"):
        if tok[g] or io[g]:
            print(f"  {g:34s}: {tok[g] / 1e6:6.2f} M tokens ({100 * tok[g] / max(1, total_t):5.1f} %), {io[g]:6.0f} s of I/O ({100 * io[g] / max(1e-9, total_s):5.1f} %)")
