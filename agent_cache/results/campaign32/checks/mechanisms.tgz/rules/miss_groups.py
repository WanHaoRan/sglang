"""Campaign 32: the same returning requests in two or more arms, grouped by what the first arm did for them before
they came: its plan timed out (ntp_expire reason=timeout), it staged a read (ntp_stage), or neither ("regular"). Per
group and arm: requests, history resident in GPU+host at admission, from SSD, recomputed (shares of ideal_cached),
"missed" (under 95 % resident), SSD tokens, TTFT.
  nice -n 15 python3 -I -B <this> FROM_S TO_S first other ..."""
import collections
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c32common import cached, load_client, load_scan, mean, pair_key  # noqa: E402

lo, hi = float(sys.argv[1]), float(sys.argv[2])
labels = sys.argv[3:]
recs = {}
for lab in labels:
    reqs, _ = load_client(lab)
    recs[lab] = {pair_key(r): r for r in reqs.values()}
ev = load_scan(labels[0])["rid_events"]
groups = collections.defaultdict(list)
for k, r in recs[labels[0]].items():
    if not (lo <= r["t_send"] < hi) or r["k"] == 0 or not r["ideal_cached"]:
        continue
    if not all(k in recs[lab] for lab in labels):
        continue
    es = ev.get(r["rid"], [])
    if any(e == "ntp_expire" and kv.get("reason") == "timeout" for t, e, kv in es):
        g = "plan timed out"
    elif any(e == "ntp_stage" for t, e, kv in es):
        g = "read staged"
    else:
        g = "regular"
    groups[g].append(k)
print(f"returning requests sent in [{lo:.0f}, {hi:.0f}) s of {labels[0]}'s clock, in all of {labels}, grouped by {labels[0]}'s plan")
for g in ("plan timed out", "read staged", "regular"):
    ks = groups[g]
    print(f"  {g}: {len(ks)} requests")
    for lab in labels:
        rs = [recs[lab][k] for k in ks]
        ideal = sum(r["ideal_cached"] for r in rs)
        c = collections.Counter()
        for r in rs:
            c.update(cached(r))
        res = c["device"] + c["host"]
        missed = sum(cached(r)["device"] + cached(r)["host"] < 0.95 * r["ideal_cached"] for r in rs)
        print(f"    {lab:10s}: resident {res / ideal:.3f}, SSD {c['storage'] / ideal:.3f}, recomputed {max(0, ideal - res - c['storage']) / ideal:.3f}, "
              f"missed {100 * missed / max(1, len(rs)):5.1f} %, SSD {c['storage'] / 1e6:5.2f} M tokens, TTFT {mean(r['ttft'] for r in rs):6.2f} s")
