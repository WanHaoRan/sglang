"""Campaign 32, one arm: one pass over server.log, kept as JSON for the analyses in this folder. Stdlib only.
From agent_cache/:
  nice -n 15 python3 -I -B <this> results/<run> <programs dir> <label> <out.json>
Keeps, per request id, the engine events that concern one request (ntp_*, ec_*, srs_*, s2h_*, prefetch_start,
load_back_init, nue_register, "HiCache prefetch success/dropped", ReqTimeStats), each as [t, event, fields], t in s
since the client's t_start; and per second of the run the host and device evictions (tokens), the SSD writes
submitted (tokens) and the pinned-read total after the last srs_pin/srs_unpin; and the NIXL cleaner passes."""
import calendar
import json
import re
import sys

run, programs, label, out = sys.argv[1:5]
with open(f"{run}/{programs}/client.jsonl") as f:
    t0 = json.loads(f.readline())["t_start"]

STAMP = re.compile(r"^\[(\d{4})-(\d\d)-(\d\d) (\d\d):(\d\d):(\d\d)\.(\d{3})\]")
EVT = re.compile(r"HICACHE_EVT (\w+) (.*)")
PREF = re.compile(r"HiCache prefetch (success|dropped) req=(\S+) completed=(\d+) matched=(\d+) loaded=(\d+) occupied=(\d+)")
RTS = re.compile(r"ReqTimeStats\(rid=([^,]+), input_len=(\d+), cached_input_len=(\d+), output_len=(\d+).*?queue_duration=([\d.]+)ms, forward_duration=([\d.]+)ms")
PER_RID = {"ntp_plan", "ntp_pick", "ntp_stage", "ntp_due", "ntp_expire", "ntp_arrive", "ntp_admit", "ntp_gate",
           "ntp_refetch", "ntp_reevict", "ntp_hold", "ec_start", "ec_release", "ec_bump", "srs_park", "srs_dispatch",
           "srs_pin", "srs_pin_skipped", "srs_unpin", "s2h_query", "s2h_io", "prefetch_start", "load_back_init",
           "nue_register"}
_sec = {}


def stamp(line):
    m = STAMP.match(line)
    if not m:
        return None
    key = m.group(0)[:20]
    base = _sec.get(key)
    if base is None:
        y, mo, d, h, mi, s = (int(m[i]) for i in range(1, 7))
        base = _sec[key] = calendar.timegm((y, mo, d, h, mi, s, 0, 0, 0))
    return base + int(m[7]) / 1000.0 - t0


rid_events, per_sec, cleanups, price = {}, {}, [], []
pinned_now = 0


def sec_cell(t):
    s = int(t)
    cell = per_sec.get(s)
    if cell is None:
        cell = per_sec[s] = [0, 0, 0, 0, 0]  # evict_host, evict_device, h2s tokens, pinned at end, pin updates
    return cell


with open(f"{run}/server.log", errors="replace") as f:
    for line in f:
        if "HICACHE_EVT" in line:
            m = EVT.search(line)
            if not m:
                continue
            t = stamp(line)
            if t is None:
                continue
            ev, rest = m[1], m[2]
            kv = dict(x.split("=", 1) for x in rest.split() if "=" in x)
            if ev == "evict_host":
                sec_cell(t)[0] += int(kv["tokens"])
            elif ev == "evict_device":
                sec_cell(t)[1] += int(kv["tokens"])
            elif ev == "h2s_submit":
                sec_cell(t)[2] += int(kv["tokens"])
            elif ev == "ec_price":
                price.append([round(t, 3), kv])
            if ev in ("srs_pin", "srs_unpin"):
                pinned_now = int(kv["pinned"])
                c = sec_cell(t)
                c[3] = pinned_now
                c[4] += 1
            if ev in PER_RID and "rid" in kv:
                rid = kv.pop("rid")
                rid_events.setdefault(rid, []).append([round(t, 3), ev, kv])
        elif "HiCache prefetch" in line:
            m = PREF.search(line)
            if m:
                t = stamp(line)
                rid_events.setdefault(m[2], []).append(
                    [round(t, 3), "prefetch_" + m[1], {"completed": m[3], "matched": m[4], "loaded": m[5], "occupied": m[6]}])
        elif "ReqTimeStats(" in line:
            m = RTS.search(line)
            if m:
                t = stamp(line)
                rid_events.setdefault(m[1], []).append(
                    [round(t, 3), "rts", {"input": m[2], "cached": m[3], "output": m[4], "queue_ms": m[5], "forward_ms": m[6]}])
        elif "NIXL L3 cleanup" in line:
            t = stamp(line)
            cleanups.append([round(t, 3), line.strip()[26:200]])

with open(out, "w") as f:
    json.dump({"label": label, "run": run, "t0": t0, "cleanups": cleanups, "price": price,
               "per_sec": {str(k): v for k, v in sorted(per_sec.items())}, "rid_events": rid_events}, f)
print(f"{label}: {len(rid_events)} rids, {sum(len(v) for v in rid_events.values())} events, {len(per_sec)} seconds, "
      f"{len(cleanups)} cleaner passes, {len(price)} price lines -> {out}")
