"""Campaign 32: the engine's pinned-read total (srs_dispatch pinned_tokens=) at each dispatch of a storage read, for
reads refused host room (launched=0) and reads launched, in a window of the client clock; also the read-thread
backlog at dispatch (inflight_pages). nice -n 15 python3 -I -B <this> FROM_S TO_S arm ..."""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c32common import load_scan, q  # noqa: E402
lo, hi = float(sys.argv[1]), float(sys.argv[2])
for lab in sys.argv[3:]:
    ev = load_scan(lab)["rid_events"]
    out = {"0": [], "1": []}
    infl = {"0": [], "1": []}
    for es in ev.values():
        for t, e, kv in es:
            if e == "srs_dispatch" and lo <= t < hi:
                out[kv["launched"]].append(int(kv["pinned_tokens"]))
                infl[kv["launched"]].append(int(kv["inflight_pages"]))
    for k, name in (("0", "refused"), ("1", "launched")):
        v = out[k]
        if v:
            print(f"{lab:10s} [{lo:.0f}, {hi:.0f}) {name:8s}: {len(v):5d} dispatches; pinned K at dispatch: p10 {q(v, .1) / 1e3:5.0f}, "
                  f"p50 {q(v, .5) / 1e3:5.0f}, p90 {q(v, .9) / 1e3:5.0f}; share over 200 K: {100 * sum(x > 200e3 for x in v) / len(v):5.1f} %; "
                  f"read backlog pages p50 {q(infl[k], .5):.0f}")
