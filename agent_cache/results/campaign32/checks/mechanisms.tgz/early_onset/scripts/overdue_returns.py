"""next_use with table hints: returning requests whose session the engine had ranked as not coming before they arrived.
  expired   the request's plan expired before it arrived (ntp_expire reason=timeout): the prefetcher registers the
            session as ended (next_turn_prefetch.py _expire -> _end_session; tier ENDED, evicted first)
  overdue   no expiry, but it arrived over 60 s after the next use registered at the previous commit (tier OVERDUE)
  on time   neither
For each group: requests, how many had to read history from SSD (s2h_io) or computed some again, SSD tokens read,
history computed again, and the true wait before them (client wait_s). Requests sent in [from, to) minutes
(default 0 to 110). Usage: python3 -I -B overdue_returns.py <extract.json> [from_min to_min]"""
import collections
import json
import sys

d = json.load(open(sys.argv[1]))
lo, hi = (float(sys.argv[2]) * 60, float(sys.argv[3]) * 60) if len(sys.argv) > 3 else (0.0, 6600.0)
cli = []
with open(f"results/{d['run']}/{d['programs']}/client.jsonl") as f:
    for line in f:
        if '"kind":"req"' in line:
            r = json.loads(line)
            if r.get("k", 0) > 0 and r.get("ideal_cached", 0) > 0 and r.get("ttft") is not None and lo <= r["t_send"] < hi:
                cli.append(r)
R = d["req"]


def cached(r):
    det = r.get("cached_details") or {}
    return sum(int(det.get(k) or 0) for k in ("device", "host", "storage")) if det else int(r.get("cached_tokens") or 0)


g = collections.defaultdict(list)
for r in cli:
    ev = R.get(r["rid"], {})
    a = ev["ntp_arrive"][0]["t"] if ev.get("ntp_arrive") else (ev["rts"][0]["entry"] if ev.get("rts") else None)
    if any(e.get("reason") == "timeout" and (a is None or e["t"] <= a) for e in ev.get("ntp_expire", [])):
        key = "expired"
    else:
        head, _, k = r["rid"].rpartition("-t")
        regs = [e for e in R.get(f"{head}-t{int(k) - 1}", {}).get("nue_register", [])
                if isinstance(e.get("next_use_ms"), (int, float)) and e["next_use_ms"] != 0]
        key = "overdue" if regs and a is not None and a > regs[-1]["t"] + regs[-1]["next_use_ms"] / 1000 + 60 else "on time"
    g[key].append(r)
print(f"{d['label']}: returning requests sent in [{lo / 60:.0f}, {hi / 60:.0f}) min: {len(cli)}")
for key in ("expired", "overdue", "on time"):
    v = g.get(key, [])
    if not v:
        continue
    reads = [sum(64 * e.get("pages", 0) for e in R.get(r["rid"], {}).get("s2h_io", [])) for r in v]
    again = [max(0, r["ideal_cached"] - cached(r)) for r in v]
    w = sorted(r.get("wait_s") or 0 for r in v)
    print(f"  {key:8s} {len(v):6d} requests: read SSD {sum(1 for x in reads if x > 0):5d} ({sum(reads) / 1e6:6.2f} M tokens), "
          f"computed history again {sum(1 for x in again if x > 0):5d} ({sum(again) / 1e6:6.2f} M); true wait p50 {w[len(w) // 2]:7.1f} s")
