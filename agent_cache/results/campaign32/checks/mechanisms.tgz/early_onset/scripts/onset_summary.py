"""One line per arm: when it falls over and the state of the SSD path before that. From extract.py's JSON, the
campaign's iostat_vdc.log (10 s samples) and the arm's client.jsonl. Usage, from agent_cache/:
  python3 -I -B onset_summary.py results/<campaign> <extract dir> <prefix> label [label ...] [--pre 30 60]
Onsets (minutes since the client's start):
  refusals   first minute m with 5 or more reads refused host room at dispatch (srs_dispatch launched=0) in every minute
             of m..m+4
  device     first minute with the SSD at 95 % util or more in every minute of m..m+4 (iostat means per minute)
  writes     first minute with the SSD write thread (sum of h2s_io ms) 95 % busy or more in every minute of m..m+4
  recompute  first 5-minute bin by send time from which the history computed again per returning request stays over
             1,000 tokens for three bins
Pre-onset window (default minutes 30 to 60): SSD read and write MB/s and util (iostat), write thread busy, SSD write
backlog (h2s submitted minus done, time-weighted), pinned tokens of landed reads (srs_pin/unpin running total,
time-weighted), host evictions (evict_host tokens a minute), refusals, and per returning request sent in the window the
SSD tokens read for it (s2h_io) and the history computed again."""
import bisect
import collections
import datetime as dt
import json
import sys

args = sys.argv[1:]
pre = (30.0, 60.0)
if "--pre" in args:
    i = args.index("--pre")
    pre = (float(args[i + 1]), float(args[i + 2]))
    args = args[:i] + args[i + 3:]
cdir, xdir, prefix, labels = args[0], args[1], args[2], args[3:]


def iostat(t0):
    rows, when, head = [], None, None
    for line in open(f"{cdir}/iostat_vdc.log"):
        s = line.strip()
        if s.endswith(("AM", "PM")) and "/" in s[:3]:
            when = dt.datetime.strptime(s, "%m/%d/%Y %I:%M:%S %p").replace(tzinfo=dt.timezone.utc).timestamp() - t0
        elif s.startswith("Device"):
            head = s.split()
        elif s.startswith("vdc") and head and when is not None and 0 <= when < 7500:
            rows.append((when, dict(zip(head[1:], map(float, s.split()[1:])))))
    per = collections.defaultdict(list)
    for t, v in rows:
        per[int(t // 60)].append(v)
    return {m: {k: sum(x[k] for x in v) / len(v) for k in ("rkB/s", "wkB/s", "%util")} for m, v in per.items()}


def first_run(per_min, test, length=5, start=20):
    for m in range(start, 125):
        if all(test(per_min.get(m + j)) for j in range(length)):
            return m
    return None


def tw(points, lo, hi):
    """time-weighted mean of a step series [(t, level after t)] over [lo, hi)"""
    acc, last_t, last_v = 0.0, lo, 0.0
    i = bisect.bisect_right([p[0] for p in points], lo) - 1
    if i >= 0:
        last_v = points[i][1]
    for t, v in points[i + 1:] if i >= 0 else points:
        if t >= hi:
            break
        if t > lo:
            acc += last_v * (t - last_t)
            last_t = t
        last_v = v
    acc += last_v * (hi - last_t)
    return acc / (hi - lo)


print(f"{'arm':10s} | onset: refusals device writes recompute | minutes {pre[0]:.0f}-{pre[1]:.0f}: rMB/s wMB/s util% wthread% "
      f"wbacklogK pinnedK evhostK/min refused/min | per returning request: SSD read tok, computed again tok")
for label in labels:
    d = json.load(open(f"{xdir}/{prefix}_{label}.json"))
    t0 = d["t_start"]
    io = iostat(t0)
    ref = collections.Counter()
    for ev in d["req"].values():
        for e in ev.get("srs_dispatch", []):
            if not e.get("launched", 1):
                ref[int(e["t"] // 60)] += 1
    wms = collections.Counter()
    for e in d["glob"].get("h2s_io", []):
        wms[int(e["t"] // 60)] += e.get("ms", 0)
    on_ref = first_run(ref, lambda v: (v or 0) >= 5)
    on_dev = first_run(io, lambda v: v is not None and v["%util"] >= 95)
    on_w = first_run(wms, lambda v: (v or 0) >= 0.95 * 60000)
    cli = [json.loads(l) for l in open(f"results/{d['run']}/{d['programs']}/client.jsonl") if '"kind":"req"' in l]
    back = [r for r in cli if r.get("k", 0) > 0 and r.get("ideal_cached", 0) > 0 and r.get("ttft") is not None]

    def again(r):
        det = r.get("cached_details") or {}
        c = sum(int(det.get(k) or 0) for k in ("device", "host", "storage")) if det else int(r.get("cached_tokens") or 0)
        return max(0, r["ideal_cached"] - c)

    bins = collections.defaultdict(list)
    for r in back:
        bins[int(r["t_send"] // 300)].append(again(r))
    per5 = {b: sum(v) / len(v) for b, v in bins.items() if v}
    on_rec = next((b * 5 for b in range(4, 24) if all(per5.get(b + j, 0) > 1000 for j in range(3))), None)
    lo, hi = pre[0] * 60, pre[1] * 60
    mins = range(int(pre[0]), int(pre[1]))
    mean_io = lambda k: sum(io[m][k] for m in mins if m in io) / max(1, sum(1 for m in mins if m in io))
    pins = sorted((e["t"], e["pinned"]) for ev in d["req"].values() for e in ev.get("srs_pin", []) + ev.get("srs_unpin", []))
    evs = sorted([(e["t"], e["op"], e["tokens"], 0) for e in d["glob"].get("h2s_submit", [])] +
                 [(e["t"], e["op"], e["tokens"], 1) for e in d["glob"].get("h2s_done", [])])
    back_pts, level, sub = [], 0, {}
    for t, op, tok, done in evs:
        if done:
            level -= sub.pop(op, 0)
        else:
            sub[op] = tok
            level += tok
        back_pts.append((t, level))
    evh = sum(e["tokens"] for e in d["glob"].get("evict_host", []) if lo <= e["t"] < hi) / ((hi - lo) / 60)
    rs = [r for r in back if lo <= r["t_send"] < hi]
    read = sum(64 * e.get("pages", 0) for r in rs for e in d["req"].get(r["rid"], {}).get("s2h_io", []))
    print(f"{label:10s} | {str(on_ref):>15s} {str(on_dev):>6s} {str(on_w):>6s} {str(on_rec):>9s} | {mean_io('rkB/s') / 1024:12.0f} "
          f"{mean_io('wkB/s') / 1024:5.0f} {mean_io('%util'):5.0f} {sum(wms[m] for m in mins) / (60000 * len(mins)) * 100:8.0f} "
          f"{tw(back_pts, lo, hi) / 1e3:9.1f} {tw(pins, lo, hi) / 1e3:7.0f} {evh / 1e3:11.0f} {sum(ref[m] for m in mins) / len(mins):11.2f} | "
          f"{read / max(1, len(rs)):22.0f} {sum(again(r) for r in rs) / max(1, len(rs)):16.0f}")
