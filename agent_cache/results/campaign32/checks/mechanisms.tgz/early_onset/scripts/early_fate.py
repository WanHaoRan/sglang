"""What became of the reads started before their request arrived (ntp_stage, the prefetcher's case 1), by request:
  expired    the plan expired with the read staged (ntp_expire staged=1) before the request arrived: the read was
             released (srs_unpin reason=abort) and the request, if it came, started again
  reread     the request's pin was released as 'replaced' (another read of it landed) or the plan saw the pages
             evicted again after landing (ntp_reevict after the first landing): read more than once
  used       the request took tokens from SSD at admission (cached_details.storage > 0) and none of the above
  not_used   none of the above and nothing taken from SSD (pages left before admission, or never landed)
Also the tokens read (s2h_io pages x 64) and taken from SSD, the hold of the first pin (landing to its release),
and how many of these requests computed history again. Requests sent before cut_s (default 6,600 s); with a
window, by send time. Usage: python3 -I -B early_fate.py <extract.json> [from_min to_min]"""
import collections
import json
import statistics as st
import sys

d = json.load(open(sys.argv[1]))
lo, hi = (float(sys.argv[2]) * 60, float(sys.argv[3]) * 60) if len(sys.argv) > 3 else (0.0, 6600.0)
cli = {}
with open(f"results/{d['run']}/{d['programs']}/client.jsonl") as f:
    for line in f:
        if '"kind":"req"' in line:
            r = json.loads(line)
            cli[r["rid"]] = r
n, read, took, again, holds = collections.Counter(), collections.Counter(), collections.Counter(), collections.Counter(), collections.defaultdict(list)
never = 0
for rid, ev in d["req"].items():
    if not ev.get("ntp_stage"):
        continue
    r = cli.get(rid)
    t_stage = ev["ntp_stage"][0]["t"]
    if r is None:
        never += 1  # the request was never sent (session ended in the run) or not recorded
        key = "never_sent"
        n[key] += 1
        read[key] += sum(64 * e.get("pages", 0) for e in ev.get("s2h_io", []))
        continue
    if not (lo <= r["t_send"] < hi):
        continue
    arr = ev["ntp_arrive"][0]["t"] if ev.get("ntp_arrive") else None
    landed = sorted(e["t"] for e in ev.get("success", []) if e.get("loaded", 0) > 0)
    unp = ev.get("srs_unpin", [])
    expired = any(e.get("staged") and e.get("reason") == "timeout" for e in ev.get("ntp_expire", []))
    rereads = any(e.get("reason") == "replaced" for e in unp) or (landed and any(e["t"] > landed[0] for e in ev.get("ntp_reevict", [])))
    took_ssd = int((r.get("cached_details") or {}).get("storage") or 0)
    key = "expired" if expired else ("reread" if rereads else ("used" if took_ssd > 0 else "not_used"))
    n[key] += 1
    read[key] += sum(64 * e.get("pages", 0) for e in ev.get("s2h_io", []))
    took[key] += took_ssd
    det = r.get("cached_details") or {}
    c = sum(int(det.get(k) or 0) for k in ("device", "host", "storage")) if det else int(r.get("cached_tokens") or 0)
    if r.get("k", 0) > 0 and r.get("ideal_cached", 0) > 0 and r["ideal_cached"] - c > 0:
        again[key] += r["ideal_cached"] - c
    pins = sorted(ev.get("srs_pin", []), key=lambda e: e["t"])
    if pins:
        u = next((e for e in sorted(unp, key=lambda e: e["t"]) if e["t"] >= pins[0]["t"]), None)
        if u:
            holds[key].append(u["t"] - pins[0]["t"])
tot = sum(v for k, v in n.items() if k != "never_sent")
print(f"{d['label']}: requests with a read staged before arrival, sent in [{lo / 60:.0f}, {hi / 60:.0f}) min: {tot}; "
      f"staged for requests never sent {n['never_sent']} ({read['never_sent'] / 1e6:.2f} M tokens read)")
for key in ("used", "reread", "expired", "not_used"):
    if n[key]:
        h = sorted(holds[key])
        print(f"  {key:9s} {n[key]:5d} ({100 * n[key] / tot:4.1f} %): read {read[key] / 1e6:6.2f} M, took from SSD {took[key] / 1e6:6.2f} M, "
              f"computed again {again[key] / 1e6:5.2f} M; first pin held mean {st.mean(h) if h else float('nan'):6.1f} s, "
              f"p50 {h[len(h) // 2] if h else float('nan'):5.1f}, p90 {h[int(0.9 * (len(h) - 1))] if h else float('nan'):6.1f}")
