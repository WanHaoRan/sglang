"""Per 10 minutes: prefill new tokens (Prefill batch lines), tokens written device->host (d2h_submit) and tokens
submitted to the SSD (h2s_submit). Usage: python3 -I -B write_volume.py <extract.json> ..."""
import collections
import json
import sys

for path in sys.argv[1:]:
    d = json.load(open(path))
    pre, d2h, h2s = collections.Counter(), collections.Counter(), collections.Counter()
    for row in d["glob"].get("prefill", []):
        pre[int(row[0] // 600)] += row[2]
    for e in d["glob"].get("d2h_submit", []):
        d2h[int(e["t"] // 600)] += e["tokens"]
    for e in d["glob"].get("h2s_submit", []):
        h2s[int(e["t"] // 600)] += e["tokens"]
    print(f"{path.split('/')[-1]}: minute: prefill / d2h / h2s, M tokens per 10 min")
    print("  " + "  ".join(f"{m * 10}: {pre[m] / 1e6:.1f}/{d2h[m] / 1e6:.1f}/{h2s[m] / 1e6:.1f}" for m in range(2, 12)))
