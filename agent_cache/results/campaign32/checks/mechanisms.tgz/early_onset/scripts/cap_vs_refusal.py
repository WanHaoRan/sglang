"""The gate's refusals at the read cap ("ntp_gate decision=capped", defect 1's symptom) and the plan's capped marks
("ntp_reevict ... capped=1"), split by what used up the allowance before them:
  refused   a read of the request had been refused host room at dispatch (srs_dispatch launched=0) before the mark
  empty     no lookup before the mark found pages (every s2h_query storage_hit 0): the allowance went on empty lookups
  landed    a read had landed before the mark (the pages were evicted again)
  found     a lookup had found pages but none landed and none was refused
Over the returning requests sent before cut_s (default 6,600 s), with the history each computed again.
Usage: python3 -I -B cap_vs_refusal.py <extract.json> [cut_s] [from_min to_min]"""
import collections
import json
import sys

d = json.load(open(sys.argv[1]))
cut = float(sys.argv[2]) if len(sys.argv) > 2 else 6600.0
lo, hi = (float(sys.argv[3]) * 60, float(sys.argv[4]) * 60) if len(sys.argv) > 4 else (0.0, cut)
cli = {}
with open(f"results/{d['run']}/{d['programs']}/client.jsonl") as f:
    for line in f:
        if '"kind":"req"' in line:
            r = json.loads(line)
            cli[r["rid"]] = r


def cached(r):
    det = r.get("cached_details") or {}
    return sum(int(det.get(k) or 0) for k in ("device", "host", "storage")) if det else int(r.get("cached_tokens") or 0)


n, tok = collections.Counter(), collections.Counter()
for rid, r in cli.items():
    if not (r.get("k", 0) > 0 and r.get("ideal_cached", 0) > 0 and r.get("ttft") is not None and r["t_send"] < cut and lo <= r["t_send"] < hi):
        continue
    ev = d["req"].get(rid, {})
    gates = [e["t"] for e in ev.get("ntp_gate", []) if e.get("decision") == "capped"]
    marks = [e["t"] for e in ev.get("ntp_reevict", []) if e.get("capped")]
    if not gates and not marks:
        continue
    t = min(gates + marks)
    refused = any(not e.get("launched", 1) and e["t"] <= t + 1e-3 for e in ev.get("srs_dispatch", []))
    found = any(e["storage_hit"] > 0 and e["t"] <= t + 1e-3 for e in ev.get("s2h_query", []))
    landed = any(e.get("loaded", 0) > 0 and e["t"] <= t + 1e-3 for e in ev.get("success", []))
    kind = "refused" if refused else ("landed" if landed else ("found" if found else "empty"))
    key = ("gate" if gates else "mark_only") + ":" + kind
    n[key] += 1
    tok[key] += max(0, r["ideal_cached"] - cached(r))
print(f"{d['label']}: returning requests sent in [{lo / 60:.0f}, {hi / 60:.0f}) min with a cap mark or a capped gate decision")
for key in sorted(n):
    print(f"  {key:18s} {n[key]:5d} requests, history computed again {tok[key] / 1e6:6.2f} M tokens")
print(f"  gate refusals (cap_share's count): {sum(v for k, v in n.items() if k.startswith('gate'))}, of them after a room refusal: {n['gate:refused']}")
