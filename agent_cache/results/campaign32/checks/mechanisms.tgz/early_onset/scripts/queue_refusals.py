"""Per minute: queued requests (mean of the decode lines' #queue-req) and reads refused host room at dispatch
(srs_dispatch launched=0), for several arms side by side. Usage: python3 -I -B queue_refusals.py from_min to_min <extract.json> ..."""
import collections
import json
import sys

lo, hi = int(sys.argv[1]), int(sys.argv[2])
cols = []
for path in sys.argv[3:]:
    d = json.load(open(path))
    acc = collections.defaultdict(list)
    for row in d["glob"].get("decode", []):
        acc[int(row[0] // 60)].append(row[4])
    ref = collections.Counter(int(e["t"] // 60) for r in d["req"].values() for e in r.get("srs_dispatch", []) if not e.get("launched", 1))
    cols.append((d["label"], {m: sum(v) / len(v) for m, v in acc.items()}, ref))
print("min " + "".join(f"{label:>18s}" for label, _, _ in cols) + "   (queued / refused)")
for m in range(lo, hi):
    print(f"{m:3d} " + "".join(f"{q.get(m, float('nan')):11.1f} /{r[m]:4d}" for _, q, r in cols))
