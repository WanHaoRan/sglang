"""SSD device statistics per bin of an arm's run, from a campaign's iostat_vdc.log (10 s samples, host time = UTC).
Usage, from agent_cache/: python3 -I -B iostat_bins.py results/<campaign> <label> [bin_s] [from_min to_min]
Columns: read and write MB/s, r_await and w_await ms, queue size, %util (means of the samples in the bin)."""
import datetime as dt
import json
import sys

cdir, label = sys.argv[1], sys.argv[2]
BIN = float(sys.argv[3]) if len(sys.argv) > 3 else 300.0
lo, hi = (float(sys.argv[4]), float(sys.argv[5])) if len(sys.argv) > 5 else (0.0, 125.0)
man = {l.split()[0]: l.split()[1:3] for l in open(f"{cdir}/manifest.txt") if l.strip()}
run, prog = man[label]
T0 = json.loads(open(f"results/{run}/{prog}/client.jsonl").readline())["t_start"]
rows, when, head = [], None, None
for line in open(f"{cdir}/iostat_vdc.log"):
    s = line.strip()
    if s.endswith(("AM", "PM")) and "/" in s[:3]:
        when = dt.datetime.strptime(s, "%m/%d/%Y %I:%M:%S %p").replace(tzinfo=dt.timezone.utc).timestamp() - T0
    elif s.startswith("Device"):
        head = s.split()
    elif s.startswith("vdc") and head and when is not None:
        v = dict(zip(head[1:], map(float, s.split()[1:])))
        rows.append((when, v))
nb = int(7500 // BIN) + 1
acc = [[] for _ in range(nb)]
for t, v in rows:
    if 0 <= t < nb * BIN:
        acc[int(t // BIN)].append(v)
print(f"{label}: iostat per {BIN:.0f} s bin, minutes since the client's start")
print(f"{'min':>5s} {'rMB/s':>7s} {'wMB/s':>7s} {'r_await':>7s} {'w_await':>7s} {'aqu':>6s} {'util%':>6s} {'n':>3s}")
for i in range(nb):
    m0 = i * BIN / 60
    if not acc[i] or m0 < lo or m0 >= hi:
        continue
    mean = lambda k: sum(x[k] for x in acc[i]) / len(acc[i])
    print(f"{m0:5.0f} {mean('rkB/s') / 1024:7.0f} {mean('wkB/s') / 1024:7.0f} {mean('r_await'):7.1f} {mean('w_await'):7.1f} "
          f"{mean('aqu-sz'):6.1f} {mean('%util'):6.1f} {len(acc[i]):3d}")
