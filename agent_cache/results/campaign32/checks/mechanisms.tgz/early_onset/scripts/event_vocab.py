"""Count HICACHE_EVT event names and other notable line kinds in one server.log.
Usage (from agent_cache/): python3 -I -B event_vocab.py results/<run>/server.log"""
import collections
import re
import sys

EVT = re.compile(r"HICACHE_EVT (\S+)")
other = collections.Counter()
evt = collections.Counter()
for line in open(sys.argv[1], errors="replace"):
    m = EVT.search(line)
    if m:
        evt[m[1]] += 1
        continue
    for key in ("prefetch success", "device prefix shrank", "reissue cap", "NIXL L3 cleanup", "admitted without",
                "host_capacity", "Traceback", "ReqTimeStats", "Decode batch", "Prefill batch", "prefetch", "revoke", "timeout"):
        if key in line:
            other[key] += 1
for k, v in sorted(evt.items(), key=lambda x: -x[1]):
    print(f"EVT {k:28s} {v}")
for k, v in sorted(other.items(), key=lambda x: -x[1]):
    print(f"TXT {k:28s} {v}")
