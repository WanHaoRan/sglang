"""Why each returning request computed history again, by the path its SSD read took, from extract.py's JSON and the
arm's client.jsonl. Usage, from agent_cache/:
  python3 -I -B attribute.py <extract.json> [windows as from-to minutes by send time, default 30-60 60-75 75-90 60-90 90-110]
A returning request: k > 0, ideal_cached > 0, a TTFT. History computed again: max(0, ideal_cached - cached), cached =
device + host + storage from the client's cached_details (as cap_share.py and the figures' "recomputed").
Paths, first match wins:
  refused      a read of the request was refused host room at dispatch (srs_dispatch launched=0), whatever followed
  capped       not refused, but the gate answered capped or the plan stopped re-reading (ntp_reevict capped=1):
               defect 1's path (the allowance went on lookups)
  lost_landed  a read landed (prefetch success loaded > 0) and the plan saw the pages evicted again (ntp_reevict)
  ssd_short    the request's last SSD lookup found less than it asked (s2h_query storage_hit < tokens_req - 256)
  no_lookup    no SSD lookup at all
  other        none of these
Also per window: early reads (ntp_stage before arrival) and their fate, overdue/ended registrations at arrival, SSD
tokens read for the request (s2h_io pages x 64) and tokens it took from SSD at admission (cached_details.storage)."""
import collections
import json
import sys

d = json.load(open(sys.argv[1]))
wins = [tuple(float(x) for x in w.split("-")) for w in (sys.argv[2:] or ["30-60", "60-75", "75-90", "60-90", "90-110"])]
cli = {}
with open(f"results/{d['run']}/{d['programs']}/client.jsonl") as f:
    for line in f:
        if '"kind":"req"' in line:
            r = json.loads(line)
            cli[r["rid"]] = r
R = d["req"]


def cached(r):
    det = r.get("cached_details") or {}
    return sum(int(det.get(k) or 0) for k in ("device", "host", "storage")) if det else int(r.get("cached_tokens") or 0)


def prev_rid(rid):
    head, _, k = rid.rpartition("-t")
    return f"{head}-t{int(k) - 1}" if k.isdigit() and int(k) > 0 else None


def classify(rid):
    ev = R.get(rid, {})
    refused = any(not e.get("launched", 1) for e in ev.get("srs_dispatch", []))
    capped = any(e.get("decision") == "capped" for e in ev.get("ntp_gate", [])) or any(e.get("capped") for e in ev.get("ntp_reevict", []))
    landed = [e["t"] for e in ev.get("success", []) if e.get("loaded", 0) > 0]
    lost = bool(landed) and any(e["t"] >= landed[0] for e in ev.get("ntp_reevict", []))
    q = ev.get("s2h_query", [])
    short = bool(q) and q[-1]["storage_hit"] < q[-1]["tokens_req"] - 256
    if refused:
        return "refused"
    if capped:
        return "capped"
    if lost:
        return "lost_landed"
    if short:
        return "ssd_short"
    if not q:
        return "no_lookup"
    return "other"


def arrival(rid):
    ev = R.get(rid, {})
    a = ev.get("ntp_arrive")
    if a:
        return a[0]["t"]
    rts = ev.get("rts")
    return rts[0]["entry"] if rts else None


def registration(rid):
    """The previous turn's next_use registration at its commit: (t_commit, due time) or None; 'ended' if None."""
    p = prev_rid(rid)
    if p is None:
        return None
    regs = [e for e in R.get(p, {}).get("nue_register", []) if e.get("next_use_ms") not in (0, None)]
    if not regs:
        return None
    e = regs[-1]
    v = e["next_use_ms"]
    if v == "ended":
        return ("ended", e["t"])
    return (e["t"], e["t"] + v / 1000.0)


CATS = ("refused", "capped", "lost_landed", "ssd_short", "no_lookup", "other")
back = [r for r in cli.values() if r.get("k", 0) > 0 and r.get("ideal_cached", 0) > 0 and r.get("ttft") is not None]
print(f"{d['label']} ({d['run']}): {len(back)} returning requests in the client file")
for lo, hi in wins:
    rs = [r for r in back if lo * 60 <= r["t_send"] < hi * 60]
    n = len(rs)
    tot = sum(max(0, r["ideal_cached"] - cached(r)) for r in rs)
    hist = sum(r["ideal_cached"] for r in rs)
    by_n, by_tok = collections.Counter(), collections.Counter()
    sub = collections.Counter()
    for r in rs:
        again = max(0, r["ideal_cached"] - cached(r))
        if again <= 0:
            continue
        c = classify(r["rid"])
        by_n[c] += 1
        by_tok[c] += again
        if c == "refused":
            ev = R.get(r["rid"], {})
            capped = any(e.get("decision") == "capped" for e in ev.get("ntp_gate", [])) or any(e.get("capped") for e in ev.get("ntp_reevict", []))
            sub["refused_then_capped"] += capped
    print(f"  sent in minutes {lo:.0f}-{hi:.0f}: {n} returning requests; history computed again {tot / 1e6:.2f} M of {hist / 1e6:.1f} M tokens "
          f"({100 * tot / max(1, hist):.1f} %), {tot / max(1, n):.0f} a request")
    print("    " + "; ".join(f"{c} {by_n[c]} req {by_tok[c] / 1e6:.2f} M ({100 * by_tok[c] / max(1, tot):.0f} %, {by_tok[c] / max(1, n):.0f}/req)" for c in CATS if by_n[c]))
    if by_n["refused"]:
        print(f"    of the refused: {sub['refused_then_capped']} also reached the cap afterwards")
    # early reads and registrations at arrival
    early = [r for r in rs if R.get(r["rid"], {}).get("ntp_stage")]
    e_again = sum(max(0, r["ideal_cached"] - cached(r)) for r in early)
    read_tok = sum(64 * e.get("pages", 0) for r in rs for e in R.get(r["rid"], {}).get("s2h_io", []))
    used_tok = sum(int((r.get("cached_details") or {}).get("storage") or 0) for r in rs)
    early_read = sum(64 * e.get("pages", 0) for r in early for e in R.get(r["rid"], {}).get("s2h_io", []))
    early_used = sum(int((r.get("cached_details") or {}).get("storage") or 0) for r in early)
    exp_before = 0
    od = collections.Counter()
    for r in rs:
        ev = R.get(r["rid"], {})
        a = arrival(r["rid"])
        if any(e.get("reason") == "timeout" and (a is None or e["t"] <= a) for e in ev.get("ntp_expire", [])):
            exp_before += 1
        reg = registration(r["rid"])
        if reg and reg[0] != "ended" and a is not None and a > reg[1] + 60:
            od["overdue_at_arrival"] += 1
    print(f"    SSD tokens read for these requests {read_tok / 1e6:.2f} M, taken from SSD at admission {used_tok / 1e6:.2f} M; "
          f"requests with a read staged before arrival {len(early)} (read {early_read / 1e6:.2f} M, took {early_used / 1e6:.2f} M, "
          f"computed again {e_again / 1e6:.2f} M); plan expired before arrival {exp_before}; overdue at arrival {od['overdue_at_arrival']}")
