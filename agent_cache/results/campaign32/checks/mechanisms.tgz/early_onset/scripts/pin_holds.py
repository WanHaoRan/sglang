"""Pins of landed SSD reads (srs_pin to the last srs_unpin of the request) by whether the read was staged before the
request arrived (ntp_stage) or started in the queue: count, mean pinned tokens, hold time, release reasons, and the
time-weighted pinned tokens they make up over the window (token-seconds / window length).
Usage: python3 -I -B pin_holds.py <extract.json> [from_min to_min ...pairs]"""
import json
import statistics as st
import sys

d = json.load(open(sys.argv[1]))
wins = [(float(a) * 60, float(b) * 60) for a, b in zip(sys.argv[2::2], sys.argv[3::2])] or [(1800, 3900), (3900, 5400)]
pins = []
for rid, ev in d["req"].items():
    staged = bool(ev.get("ntp_stage"))
    ups = sorted(ev.get("srs_unpin", []), key=lambda e: e["t"])
    for p in sorted(ev.get("srs_pin", []), key=lambda e: e["t"]):
        u = next((e for e in ups if e["t"] >= p["t"]), None)
        pins.append((p["t"], u["t"] if u else None, p["tokens"], u["reason"] if u else None, staged))
print(d["label"])
for lo, hi in wins:
    for staged in (True, False):
        w = [x for x in pins if lo <= x[0] < hi and x[4] == staged]
        if not w:
            continue
        held = [x[1] - x[0] for x in w if x[1] is not None]
        ts = sum(x[2] * (min(x[1] if x[1] is not None else hi, hi) - x[0]) for x in w)
        reasons = {}
        for x in w:
            reasons[x[3]] = reasons.get(x[3], 0) + 1
        print(f"  minutes {lo / 60:.0f}-{hi / 60:.0f} {'staged before arrival' if staged else 'read in the queue':22s}: {len(w)} pins, "
              f"{st.mean(x[2] for x in w) / 1e3:.1f} K tokens each, held mean {st.mean(held):.1f} s p50 {sorted(held)[len(held) // 2]:.1f} "
              f"p90 {sorted(held)[int(0.9 * (len(held) - 1))]:.1f}; time-weighted {ts / (hi - lo) / 1e3:.0f} K tokens; released {reasons}")
