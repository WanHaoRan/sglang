"""When the host pool first stops yielding evictable pages: evict_host calls that freed less than asked
(tokens < requested) before cut_s, the first such minute, and the pinned tokens (srs_pin/unpin running total) at
the first five. Usage: python3 -I -B dry_host.py <extract.json> [...] (cut 6,600 s)"""
import bisect
import json
import sys

for path in sys.argv[1:]:
    d = json.load(open(path))
    ev = [e for e in d["glob"].get("evict_host", []) if e["t"] < 6600]
    part = sorted(e["t"] for e in ev if e["tokens"] < e["requested"])
    pins = sorted((e["t"], e["pinned"]) for r in d["req"].values() for e in r.get("srs_pin", []) + r.get("srs_unpin", []))
    pt = [p[0] for p in pins]
    at = []
    for t in part[:5]:
        i = bisect.bisect_right(pt, t) - 1
        at.append(f"{t / 60:.1f} min: {(pins[i][1] if i >= 0 else 0) / 1e3:.0f} K pinned")
    print(f"{path.split('/')[-1]:22s} evict_host calls {len(ev):5d}, freed less than asked {len(part):4d}, first at "
          f"{part[0] / 60 if part else float('nan'):.1f} min; {'; '.join(at)}")
