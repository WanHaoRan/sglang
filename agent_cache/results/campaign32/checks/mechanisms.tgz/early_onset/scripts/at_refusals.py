"""The first read refusals at dispatch (srs_dispatch launched=0) of an arm, with the host-room numbers known at
each: pinned tokens and in-flight read pages (logged on the line), the SSD write backlog (h2s submitted minus done,
tokens), reads parked and not yet dispatched, and the anchor tokens those parked and in-flight lookups lock
(upper bound: the request's matched tokens in memory at its lookup, from ntp_gate/ntp_stage 'matched', else
the prompt minus prefetch_start's tokens). Also a per-minute summary of the same quantities at all dispatches.
Usage: python3 -I -B at_refusals.py <extract.json> [from_min to_min] [show_first_n]"""
import bisect
import collections
import json
import sys

d = json.load(open(sys.argv[1]))
lo, hi = (float(sys.argv[2]) * 60, float(sys.argv[3]) * 60) if len(sys.argv) > 3 else (0.0, 7500.0)
show = int(sys.argv[4]) if len(sys.argv) > 4 else 10
# write backlog timeline
evs = sorted([(e["t"], e["op"], e["tokens"], 0) for e in d["glob"].get("h2s_submit", [])] +
             [(e["t"], e["op"], e["tokens"], 1) for e in d["glob"].get("h2s_done", [])])
bt, bv, level, sub = [], [], 0, {}
for t, op, tok, done in evs:
    if done:
        level -= sub.pop(op, 0)
    else:
        sub[op] = tok
        level += tok
    bt.append(t)
    bv.append(level)


def backlog(t):
    i = bisect.bisect_right(bt, t) - 1
    return bv[i] if i >= 0 else 0


# parked and in-flight lookups: from each srs_park to its srs_dispatch (parked); anchors from lookup to the end of the
# prefetch (approximated by the next success / dispatch launched=0 / admission)
intervals = []  # (start, end, kind, anchor_tokens)
for rid, ev in d["req"].items():
    rts = ev.get("rts", [])
    adm = rts[0]["entry"] + rts[0]["queue"] if rts else None
    prompt = rts[0]["input_len"] if rts else None
    parks = sorted(e["t"] for e in ev.get("srs_park", []))
    disps = sorted((e["t"], e.get("launched", 1)) for e in ev.get("srs_dispatch", []))
    succ = sorted(e["t"] for e in ev.get("success", []))
    matched = [(e["t"], e.get("matched", 0)) for e in ev.get("ntp_gate", []) + ev.get("ntp_stage", [])]
    starts = sorted((e["t"], e["tokens"]) for e in ev.get("prefetch_start", []))
    for p in parks:
        dd = next((t for t, _ in disps if t >= p - 1e-6), None)
        end_park = dd if dd is not None else (adm if adm is not None else p)
        # anchor: matched tokens at the lookup nearest before the park
        m = [mm for t, mm in matched if t <= p + 0.05]
        if m:
            anchor = m[-1]
        else:
            s = [tok for t, tok in starts if t <= p + 0.05]
            anchor = max(0, (prompt or 0) - s[-1]) if s and prompt else 0
        # the lookup ends when its read lands, is refused, or the request is admitted
        launched = next((l for t, l in disps if t >= p - 1e-6), 1)
        if launched:
            end = next((t for t in succ if t >= p), adm if adm is not None else end_park)
        else:
            end = end_park
        intervals.append((p, end_park, "parked", anchor))
        intervals.append((p, end, "anchor", anchor))
starts_k = sorted((s, e, k, a) for s, e, k, a in intervals)


def held(t):
    parked = anchors = n_parked = 0
    for s, e, k, a in starts_k:
        if s > t:
            break
        if e is not None and e >= t:
            if k == "parked":
                n_parked += 1
            else:
                anchors += a
    return n_parked, anchors


rows = []
for rid, ev in d["req"].items():
    for e in ev.get("srs_dispatch", []):
        if lo <= e["t"] < hi:
            rows.append((e["t"], rid, e.get("launched", 1), e.get("pages", 0), e.get("pinned_tokens", 0), e.get("inflight_pages", 0)))
rows.sort()
print(f"{d['label']}: dispatches in [{lo / 60:.0f}, {hi / 60:.0f}) min: {len(rows)}, refused {sum(1 for r in rows if not r[2])}")
print(f"first {show} refusals: t_min rid pages pinnedK inflightK write_backlogK parked anchorsK")
n = 0
for t, rid, launched, pages, pin, infl in rows:
    if launched:
        continue
    n += 1
    if n > show:
        break
    np_, anc = held(t)
    print(f"  {t / 60:7.2f} {rid:24s} {pages:5d} {pin / 1e3:7.1f} {infl * 64 / 1e3:7.1f} {backlog(t) / 1e3:7.1f} {np_:4d} {anc / 1e3:7.1f}")
by = collections.defaultdict(list)
for t, rid, launched, pages, pin, infl in rows:
    by[int(t // 60)].append((launched, pin, infl * 64, backlog(t)) + held(t))
print("per minute at dispatches: min n refused | mean pinnedK inflightK backlogK parked anchorsK (all dispatches) | same at refusals")
for m in sorted(by):
    v = by[m]
    f = lambda rows, i: sum(r[i] for r in rows) / len(rows) / (1e3 if i != 4 else 1) if rows else float("nan")
    ref = [r for r in v if not r[0]]
    print(f"  {m:4d} {len(v):4d} {len(ref):4d} | {f(v, 1):7.1f} {f(v, 2):7.1f} {f(v, 3):7.1f} {f(v, 4):5.1f} {f(v, 5):7.1f} | "
          f"{f(ref, 1):7.1f} {f(ref, 2):7.1f} {f(ref, 3):7.1f} {f(ref, 4):5.1f} {f(ref, 5):7.1f}")
