"""Reads dispatched in a window: how long each was parked before dispatch (srs_dispatch waited_ms), for the
dispatches refused host room (launched=0) and the launched ones, and the share of refusals that were re-reads
dispatched at once (waited 0 to 100 ms). Usage: python3 -I -B refusal_waits.py <extract.json> from_min to_min"""
import json
import sys

d = json.load(open(sys.argv[1]))
lo, hi = float(sys.argv[2]) * 60, float(sys.argv[3]) * 60
ref, ok = [], []
for ev in d["req"].values():
    for e in ev.get("srs_dispatch", []):
        if lo <= e["t"] < hi:
            (ok if e.get("launched", 1) else ref).append(e.get("waited_ms", 0) / 1000)
q = lambda v, p: sorted(v)[int(p * (len(v) - 1))] if v else float("nan")
print(f"{d['label']} minutes {lo / 60:.0f}-{hi / 60:.0f}: refused {len(ref)} (parked p50 {q(ref, .5):.1f} s, p90 {q(ref, .9):.1f} s, "
      f"at once {sum(1 for w in ref if w <= 0.1)}); launched {len(ok)} (parked p50 {q(ok, .5):.1f} s, p90 {q(ok, .9):.1f} s)")
