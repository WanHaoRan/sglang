"""History computed again per returning request sent in a window, split by the request's own state (exclusive):
expired (its plan expired before it arrived: session registered ended), staged (a read started before it arrived,
not expired), queued (neither: any read started in the queue or none). Per request of the window, so arms with
different request counts compare. Also the split by path (refused at dispatch / capped after empty lookups /
other). Usage: python3 -I -B state_split.py from_min to_min <extract.json> [<extract.json> ...]"""
import json
import sys

lo, hi = float(sys.argv[1]) * 60, float(sys.argv[2]) * 60
for path in sys.argv[3:]:
    d = json.load(open(path))
    R = d["req"]
    rs = []
    with open(f"results/{d['run']}/{d['programs']}/client.jsonl") as f:
        for line in f:
            if '"kind":"req"' in line:
                r = json.loads(line)
                if r.get("k", 0) > 0 and r.get("ideal_cached", 0) > 0 and r.get("ttft") is not None and lo <= r["t_send"] < hi:
                    rs.append(r)
    st, pa = {}, {}
    for r in rs:
        det = r.get("cached_details") or {}
        c = sum(int(det.get(k) or 0) for k in ("device", "host", "storage")) if det else int(r.get("cached_tokens") or 0)
        again = max(0, r["ideal_cached"] - c)
        ev = R.get(r["rid"], {})
        a = ev["ntp_arrive"][0]["t"] if ev.get("ntp_arrive") else (ev["rts"][0]["entry"] if ev.get("rts") else None)
        if any(e.get("reason") == "timeout" and (a is None or e["t"] <= a) for e in ev.get("ntp_expire", [])):
            s = "expired"
        elif ev.get("ntp_stage"):
            s = "staged"
        else:
            s = "queued"
        st[s] = st.get(s, 0) + again
        refused = any(not e.get("launched", 1) for e in ev.get("srs_dispatch", []))
        capped = any(e.get("decision") == "capped" for e in ev.get("ntp_gate", [])) or any(e.get("capped") for e in ev.get("ntp_reevict", []))
        found = any(e["storage_hit"] > 0 for e in ev.get("s2h_query", []))
        p = "refused" if refused else ("capped_empty" if capped and not found else ("capped_other" if capped else "other"))
        pa[p] = pa.get(p, 0) + again
    n = len(rs)
    print(f"{d['label']:10s} {n:5d} requests, {sum(st.values()) / n:7.0f} tokens computed again a request | by state: " +
          " ".join(f"{k} {st.get(k, 0) / n:6.0f}" for k in ("expired", "staged", "queued")) + " | by path: " +
          " ".join(f"{k} {pa.get(k, 0) / n:6.0f}" for k in ("refused", "capped_empty", "capped_other", "other")))
