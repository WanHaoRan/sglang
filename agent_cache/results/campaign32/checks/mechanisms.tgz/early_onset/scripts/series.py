"""Per 5-minute bin (engine event time since the client's start), from extract.py's JSON:
reads dispatched and refused room at dispatch (srs_dispatch launched=0), pinned tokens (srs_pin/unpin running total,
time-weighted), SSD write backlog (h2s submitted minus done, tokens, time-weighted), host evictions (evict_host
tokens), re-evictions seen by the plan (ntp_reevict, and capped=1), gate refusals (decision=capped), device prefix
shrank lines, SSD pages read (s2h_io), prefill new tokens, decode running/queued means.
Usage: python3 -I -B series.py <extract.json> [bin_s] [from_min to_min]"""
import collections
import json
import sys

d = json.load(open(sys.argv[1]))
BIN = float(sys.argv[2]) if len(sys.argv) > 2 else 300.0
lo, hi = (float(sys.argv[3]), float(sys.argv[4])) if len(sys.argv) > 4 else (0.0, 125.0)
nb = int(7500 // BIN) + 1
b = lambda t: int(t // BIN) if t is not None and t >= 0 else None
c = collections.defaultdict(lambda: [0.0] * nb)


def add(key, t, v=1.0):
    i = b(t)
    if i is not None and i < nb:
        c[key][i] += v


def step_avg(points, key):
    """points: sorted (t, level after t); time-weighted mean per bin."""
    acc = [0.0] * nb
    for (t0, v), (t1, _) in zip(points, points[1:] + [(7500.0, 0)]):
        t0 = max(t0, 0.0)
        while t0 < t1:
            i = int(t0 // BIN)
            if i >= nb:
                break
            end = min(t1, (i + 1) * BIN)
            acc[i] += v * (end - t0)
            t0 = end
    c[key] = [a / BIN for a in acc]


pins = []
for rid, ev in d["req"].items():
    for e in ev.get("srs_dispatch", []):
        add("dispatch", e["t"])
        if not e.get("launched", 1):
            add("refused", e["t"])
            add("refused_pages", e["t"], e.get("pages", 0))
    for e in ev.get("srs_pin", []):
        pins.append((e["t"], e["pinned"]))
    for e in ev.get("srs_unpin", []):
        pins.append((e["t"], e["pinned"]))
        add("unpin_" + str(e.get("reason")), e["t"])
    for e in ev.get("ntp_reevict", []):
        add("reevict", e["t"])
        if e.get("capped"):
            add("reevict_capped", e["t"])
    for e in ev.get("ntp_gate", []):
        add("gate_" + str(e.get("decision")), e["t"])
    for e in ev.get("shrank", []):
        add("shrank", e["t"])
    for e in ev.get("s2h_io", []):
        add("read_pages", e["t"], e.get("pages", 0))
    for e in ev.get("ntp_due", []):
        add("due_case%s" % e.get("case"), e["t"])
    for e in ev.get("ntp_stage", []):
        add("stage", e["t"])
    for e in ev.get("ntp_expire", []):
        add("expire_staged%s" % e.get("staged"), e["t"])
pins.sort()
step_avg(pins, "pinned")
back = []
level = 0
subm = {}
for e in sorted(d["glob"].get("h2s_submit", []) + [dict(e, done=1) for e in d["glob"].get("h2s_done", [])], key=lambda e: e["t"]):
    if e.get("done"):
        level -= subm.pop(e["op"], 0)
    else:
        subm[e["op"]] = e["tokens"]
        level += e["tokens"]
    back.append((e["t"], level))
step_avg(back, "write_backlog")
for e in d["glob"].get("evict_host", []):
    add("evict_host", e["t"], e["tokens"])
for e in d["glob"].get("h2s_io", []):
    add("write_ms", e["t"], e.get("ms", 0))
n_dec = [0] * nb
for row in d["glob"].get("prefill", []):
    add("prefill_new", row[0], row[2])
for row in d["glob"].get("decode", []):
    add("dec_n", row[0])
    add("dec_run", row[0], row[1])
    add("dec_queue", row[0], row[4])
    add("dec_tok", row[0], row[2])
cols = [("dispatch", "disp", 1), ("refused", "refused", 1), ("refused_pages", "ref_Ktok", 0.064), ("pinned", "pinK", 0.001),
        ("write_backlog", "wbackK", 0.001), ("write_ms", "wbusy%", 100 / 1000 / BIN), ("evict_host", "evhostK", 0.001),
        ("reevict", "reev", 1), ("reevict_capped", "reev_cap", 1), ("gate_capped", "g_cap", 1), ("shrank", "shrank", 1),
        ("read_pages", "readKtok", 0.064), ("due_case1", "case1", 1), ("due_case2", "case2", 1), ("stage", "stage", 1),
        ("expire_staged1", "exp_st", 1), ("expire_staged0", "exp_nost", 1), ("unpin_abort", "unp_abort", 1),
        ("prefill_new", "prefillK", 0.001)]
print(f"{d['label']} ({d['run']})")
print(f"{'min':>5s} " + " ".join(f"{h:>8s}" for _, h, _ in cols) + f" {'run':>5s} {'queue':>5s}")
for i in range(nb):
    m0 = i * BIN / 60
    if m0 < lo or m0 >= hi:
        continue
    n = c["dec_n"][i]
    print(f"{m0:5.0f} " + " ".join(f"{c[k][i] * s:8.1f}" for k, _, s in cols) +
          f" {c['dec_run'][i] / n if n else float('nan'):5.1f} {c['dec_queue'][i] / n if n else float('nan'):5.1f}")
