"""Paired by request (stream instance and index, same recorded tree): returning requests both arms sent in a window,
whether each arm had to read the request's history from SSD, how much it read (s2h_io pages x 64) and how much it
took from SSD at admission (cached_details.storage), split by arm A's state at the request's arrival:
  expired   A's plan for the request expired before it arrived (the engine registered the session as ended)
  overdue   not expired, but the request arrived more than 60 s after the next use A registered at the previous commit
  staged    neither, and A staged a read before arrival (ntp_stage)
  none      neither
Usage: python3 -I -B paired_reads.py <extract A.json> <extract B.json> [from_min to_min]"""
import collections
import json
import sys

A, B = json.load(open(sys.argv[1])), json.load(open(sys.argv[2]))
lo, hi = (float(sys.argv[3]) * 60, float(sys.argv[4]) * 60) if len(sys.argv) > 4 else (1800.0, 3900.0)


def load(d):
    out = {}
    with open(f"results/{d['run']}/{d['programs']}/client.jsonl") as f:
        for line in f:
            if '"kind":"req"' in line:
                r = json.loads(line)
                if r.get("k", 0) > 0 and r.get("ideal_cached", 0) > 0 and r.get("ttft") is not None:
                    out[(r["inst"], r["k"])] = r
    return out


ca, cb = load(A), load(B)


def cached(r):
    det = r.get("cached_details") or {}
    return sum(int(det.get(k) or 0) for k in ("device", "host", "storage")) if det else int(r.get("cached_tokens") or 0)


def read_tok(d, rid):
    return sum(64 * e.get("pages", 0) for e in d["req"].get(rid, {}).get("s2h_io", []))


def arrival(d, rid):
    ev = d["req"].get(rid, {})
    if ev.get("ntp_arrive"):
        return ev["ntp_arrive"][0]["t"]
    return ev["rts"][0]["entry"] if ev.get("rts") else None


def state(d, rid):
    ev = d["req"].get(rid, {})
    a = arrival(d, rid)
    if any(e.get("reason") == "timeout" and (a is None or e["t"] <= a) for e in ev.get("ntp_expire", [])):
        return "expired"
    head, _, k = rid.rpartition("-t")
    prev = f"{head}-t{int(k) - 1}"
    regs = [e for e in d["req"].get(prev, {}).get("nue_register", []) if isinstance(e.get("next_use_ms"), (int, float)) and e["next_use_ms"] != 0]
    if regs and a is not None and a > regs[-1]["t"] + regs[-1]["next_use_ms"] / 1000 + 60:
        return "overdue"
    if ev.get("ntp_stage"):
        return "staged"
    return "none"


pairs = [(k, ca[k], cb[k]) for k in ca if k in cb and lo <= ca[k]["t_send"] < hi and ca[k].get("tree") == cb[k].get("tree")]
print(f"{A['label']} (A) against {B['label']} (B): {len(pairs)} returning requests both sent in [{lo / 60:.0f}, {hi / 60:.0f}) min (by A's send time)")
print(f"{'A state':8s} {'requests':>8s} | {'A read':>6s} {'B read':>6s} {'A only':>6s} {'B only':>6s} | {'A readM':>7s} {'B readM':>7s} | "
      f"{'A tookM':>7s} {'B tookM':>7s} | {'A againM':>8s} {'B againM':>8s} | {'wait p50 s':>10s}")
g = collections.defaultdict(list)
for k, ra, rb in pairs:
    g[state(A, ra["rid"])].append((ra, rb))
tot = collections.Counter()
for s in ("expired", "overdue", "staged", "none"):
    v = g.get(s, [])
    if not v:
        continue
    ar = [read_tok(A, ra["rid"]) for ra, rb in v]
    br = [read_tok(B, rb["rid"]) for ra, rb in v]
    at = [int((ra.get("cached_details") or {}).get("storage") or 0) for ra, rb in v]
    bt = [int((rb.get("cached_details") or {}).get("storage") or 0) for ra, rb in v]
    ag = [max(0, ra["ideal_cached"] - cached(ra)) for ra, rb in v]
    bg = [max(0, rb["ideal_cached"] - cached(rb)) for ra, rb in v]
    waits = sorted(ra.get("wait_s") or 0 for ra, rb in v)
    a_read = sum(1 for x in ar if x > 0)
    b_read = sum(1 for x in br if x > 0)
    a_only = sum(1 for x, y in zip(ar, br) if x > 0 and y == 0)
    b_only = sum(1 for x, y in zip(ar, br) if y > 0 and x == 0)
    print(f"{s:8s} {len(v):8d} | {a_read:6d} {b_read:6d} {a_only:6d} {b_only:6d} | {sum(ar) / 1e6:7.2f} {sum(br) / 1e6:7.2f} | "
          f"{sum(at) / 1e6:7.2f} {sum(bt) / 1e6:7.2f} | {sum(ag) / 1e6:8.2f} {sum(bg) / 1e6:8.2f} | {waits[len(waits) // 2]:10.1f}")
    for key, val in (("n", len(v)), ("ar", sum(ar)), ("br", sum(br)), ("at", sum(at)), ("bt", sum(bt)), ("ag", sum(ag)), ("bg", sum(bg)),
                     ("a_read", a_read), ("b_read", b_read)):
        tot[key] += val
print(f"{'all':8s} {tot['n']:8d} | {tot['a_read']:6d} {tot['b_read']:6d} {'':6s} {'':6s} | {tot['ar'] / 1e6:7.2f} {tot['br'] / 1e6:7.2f} | "
      f"{tot['at'] / 1e6:7.2f} {tot['bt'] / 1e6:7.2f} | {tot['ag'] / 1e6:8.2f} {tot['bg'] / 1e6:8.2f} |")
