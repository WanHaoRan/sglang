"""Extract one arm's engine events into a compact JSON for the early-onset analysis (read-only on the run folder).
Usage, from agent_cache/:
  nice -n 15 python3 -I -B extract.py results/<campaign> <label> <out.json>
Times are seconds since the client's t_start (first line of client.jsonl). Per request (rid): the next-turn
prefetcher's events (plan, due, stage, expire, arrive, gate, refetch, reevict, hold, admit), the storage read path
(s2h_query, srs_park, srs_dispatch with its launched flag, s2h_io, prefetch success, srs_pin/unpin), device prefix
shrank, load_back_init, nue_register and ReqTimeStats. Global series: evict_host, evict_device, h2s submit/done,
d2h_submit, the prefill/decode batch lines, NIXL cleanup. Stdlib only."""
import collections
import datetime as dt
import json
import re
import sys

cdir, label, out = sys.argv[1], sys.argv[2], sys.argv[3]
man = {l.split()[0]: l.split()[1:3] for l in open(f"{cdir}/manifest.txt") if l.strip()}
run, prog = man[label]
first = json.loads(open(f"results/{run}/{prog}/client.jsonl").readline())
T0 = first["t_start"]

TS = re.compile(r"^\[(\d{4})-(\d\d)-(\d\d) (\d\d):(\d\d):(\d\d)\.(\d+)\]")
EVT = re.compile(r"HICACHE_EVT (\S+) (.*)")
KV = re.compile(r"(\w+)=(\S+)")
_day_cache = {}


def stamp(line):
    m = TS.match(line)
    if not m:
        return None
    key = m.group(1, 2, 3)
    base = _day_cache.get(key)
    if base is None:
        base = dt.datetime(int(m[1]), int(m[2]), int(m[3]), tzinfo=dt.timezone.utc).timestamp()
        _day_cache[key] = base
    return base + int(m[4]) * 3600 + int(m[5]) * 60 + int(m[6]) + int(m[7]) / 10 ** len(m[7]) - T0


def num(v):
    try:
        return int(v)
    except ValueError:
        try:
            return float(v)
        except ValueError:
            return v


req = collections.defaultdict(lambda: collections.defaultdict(list))
glob = collections.defaultdict(list)
PER_RID = {"ntp_plan", "ntp_pick", "ntp_due", "ntp_stage", "ntp_expire", "ntp_arrive", "ntp_gate", "ntp_refetch",
           "ntp_reevict", "ntp_hold", "ntp_admit", "s2h_query", "srs_park", "srs_dispatch", "s2h_io", "srs_pin",
           "srs_unpin", "srs_pin_skipped", "nue_register", "load_back_init", "prefetch_start", "ec_start", "ec_price",
           "ec_release", "ec_bump"}
GLOBAL = {"evict_host", "evict_device", "h2s_submit", "h2s_done", "h2s_io", "d2h_submit", "srs_rate"}
PREFILL = re.compile(r"#new-seq: (\d+), #new-token: (\d+), #cached-token: (\d+), token usage: ([\d.]+), #running-req: (\d+), #queue-req: (\d+)")
DECODE = re.compile(r"#running-req: (\d+), #token: (\d+), token usage: ([\d.]+).*#queue-req: (\d+)")
RTS = re.compile(r"ReqTimeStats\(rid=(\S+?), input_len=(\d+), cached_input_len=(\d+), output_len=(\d+).*queue_duration=([\d.]+)(ms|s), "
                 r"forward_duration=([\d.]+)(ms|s), entry_time=([\d.]+)")
SUCCESS = re.compile(r"prefetch success req=(\S+) completed=(\d+) matched=(\d+) loaded=(\d+)")
SHRANK = re.compile(r"device prefix shrank before admission req=(\S+) lookup_match=(\d+) current_match=(\d+)")
other = collections.Counter()
with open(f"results/{run}/server.log", errors="replace") as f:
    for line in f:
        if "HICACHE_EVT" in line:
            m = EVT.search(line)
            if not m:
                continue
            name = m[1]
            if name not in PER_RID and name not in GLOBAL:
                other[name] += 1
                continue
            t = stamp(line)
            fields = {k: num(v) for k, v in KV.findall(m[2])}
            fields["t"] = round(t, 3)
            if name in GLOBAL:
                glob[name].append(fields)
            else:
                rid = fields.pop("rid", None) or fields.pop("req", None)
                if rid is None:
                    other[name + "_norid"] += 1
                    continue
                req[rid][name].append(fields)
        elif "Prefill batch" in line:
            m = PREFILL.search(line)
            if m:
                glob["prefill"].append([round(stamp(line), 3)] + [num(x) for x in m.groups()])
        elif "Decode batch" in line:
            m = DECODE.search(line)
            if m:
                glob["decode"].append([round(stamp(line), 3)] + [num(x) for x in m.groups()])
        elif "ReqTimeStats" in line:
            m = RTS.search(line)
            if m:
                q = float(m[5]) / (1000.0 if m[6] == "ms" else 1.0)
                fw = float(m[7]) / (1000.0 if m[8] == "ms" else 1.0)
                req[m[1]]["rts"].append(dict(t=round(stamp(line), 3), input_len=int(m[2]), cached=int(m[3]), out=int(m[4]),
                                             queue=round(q, 3), forward=round(fw, 3), entry=round(float(m[9]) - T0, 3)))
        elif "prefetch success" in line:
            m = SUCCESS.search(line)
            if m:
                req[m[1]]["success"].append(dict(t=round(stamp(line), 3), completed=int(m[2]), matched=int(m[3]), loaded=int(m[4])))
        elif "device prefix shrank" in line:
            m = SHRANK.search(line)
            if m:
                req[m[1]]["shrank"].append(dict(t=round(stamp(line), 3), lookup_match=int(m[2]), current_match=int(m[3])))
        elif "reissue cap reached" in line:
            m = re.search(r"req=(\S+)", line)
            if m:
                req[m[1].rstrip(",;")]["reissue_cap"].append(dict(t=round(stamp(line), 3)))
        elif "NIXL L3 cleanup" in line:
            glob["cleanup"].append(dict(t=round(stamp(line), 3), text=line.strip()[26:200]))
        elif "admitted without further L3" in line:
            m = re.search(r"req=(\S+)", line)
            if m:
                req[m[1].rstrip(",;")]["no_more_l3"].append(dict(t=round(stamp(line), 3)))
json.dump(dict(label=label, run=run, programs=prog, t_start=T0, other=other, glob=glob, req=req), open(out, "w"))
print(f"{label}: {len(req)} rids, " + ", ".join(f"{k} {len(v)}" for k, v in glob.items()) + f"; other {dict(other)}")
