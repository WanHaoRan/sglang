#!/bin/bash
# Re-run every check of this analysis from agent_cache/ (read-only there), writing into the scratch out/ folder.
set -u
S=/tmp/claude-1001/-home-wanhr-sglang/7c93b1d5-dc1c-431d-8d3e-efb4ae23a30d/scratchpad/c32/early_onset
O=$S/out
X=$S/extract
mkdir -p $O
cd /home/wanhr/sglang/agent_cache
P() { nice -n 15 python3 -I -B "$@"; }
P $S/scripts/onset_summary.py results/campaign32 $X c32 hicache jit_p50 oracle_v2 jit_exact ec_full ec_exact > $O/onset_summary_c32.out
P $S/scripts/onset_summary.py results/campaign32 $X c32 jit_p50 oracle_v2 jit_exact ec_full ec_exact --pre 40 65 > $O/onset_summary_c32_40_65.out
P $S/scripts/onset_summary.py results/campaign28 $X c28 hicache jit_p50 oracle_v2 jit_exact ec_full ec_exact > $O/onset_summary_c28.out
P $S/scripts/state_split.py 60 90 $X/c32_jit_p50.json $X/c32_oracle_v2.json $X/c32_jit_exact.json $X/c32_ec_full.json $X/c32_ec_exact.json > $O/state_split_c32_60_90.out
P $S/scripts/state_split.py 60 75 $X/c32_jit_p50.json $X/c32_oracle_v2.json $X/c32_jit_exact.json $X/c32_ec_full.json $X/c32_ec_exact.json > $O/state_split_c32_60_75.out
P $S/scripts/state_split.py 30 60 $X/c32_jit_p50.json $X/c32_oracle_v2.json $X/c32_jit_exact.json > $O/state_split_c32_30_60.out
P $S/scripts/state_split.py 60 90 $X/c28_jit_p50.json $X/c28_oracle_v2.json $X/c28_jit_exact.json $X/c28_ec_full.json $X/c28_ec_exact.json > $O/state_split_c28_60_90.out
for a in jit_p50 oracle_v2 jit_exact ec_full ec_exact; do P $S/scripts/attribute.py $X/c32_$a.json > $O/attribute_c32_$a.out; done
for a in jit_p50 oracle_v2 jit_exact; do P $S/scripts/attribute.py $X/c28_$a.json 30-60 60-90 90-110 > $O/attribute_c28_$a.out; done
{ P $S/scripts/paired_reads.py $X/c32_jit_p50.json $X/c32_jit_exact.json 30 65; P $S/scripts/paired_reads.py $X/c32_oracle_v2.json $X/c32_jit_exact.json 30 65; } > $O/paired_reads_c32_30_65.out
{ P $S/scripts/paired_reads.py $X/c28_jit_p50.json $X/c28_jit_exact.json 30 65; P $S/scripts/paired_reads.py $X/c28_oracle_v2.json $X/c28_jit_exact.json 30 65; } > $O/paired_reads_c28_30_65.out
for a in jit_p50 oracle_v2 jit_exact ec_full; do P $S/scripts/pin_holds.py $X/c32_$a.json 30 65 65 90; done > $O/pin_holds_c32.out
for a in jit_p50 oracle_v2 jit_exact; do P $S/scripts/pin_holds.py $X/c28_$a.json 30 65 65 90; done > $O/pin_holds_c28.out
for a in jit_p50 oracle_v2; do P $S/scripts/early_fate.py $X/c32_$a.json; P $S/scripts/early_fate.py $X/c32_$a.json 30 65; done > $O/early_fate_c32.out
for a in jit_p50 oracle_v2; do P $S/scripts/early_fate.py $X/c28_$a.json; done > $O/early_fate_c28.out
{ for a in jit_p50 jit_exact oracle_v2 ec_full ec_exact; do P $S/scripts/cap_vs_refusal.py $X/c32_$a.json; done; for a in jit_p50 jit_exact; do P $S/scripts/cap_vs_refusal.py $X/c32_$a.json 6600 60 90; done; } > $O/cap_vs_refusal_c32.out
for a in jit_p50 jit_exact oracle_v2; do P $S/scripts/cap_vs_refusal.py $X/c28_$a.json; done > $O/cap_vs_refusal_c28.out
for a in jit_p50 jit_exact oracle_v2; do P $S/scripts/overdue_returns.py $X/c32_$a.json; P $S/scripts/overdue_returns.py $X/c32_$a.json 60 90; P $S/scripts/overdue_returns.py $X/c32_$a.json 30 65; done > $O/overdue_returns_c32.out
for a in jit_p50 jit_exact; do P $S/scripts/overdue_returns.py $X/c28_$a.json; done > $O/overdue_returns_c28.out
for a in jit_p50:55:75 oracle_v2:66:76 jit_exact:74:84 jit_p50:30:65 oracle_v2:30:65; do IFS=: read l f t <<< "$a"; P $S/scripts/refusal_waits.py $X/c32_$l.json $f $t; done > $O/refusal_waits_c32.out
{ P $S/scripts/at_refusals.py $X/c32_jit_p50.json 30 75 12; P $S/scripts/at_refusals.py $X/c32_oracle_v2.json 28 76 8; P $S/scripts/at_refusals.py $X/c32_jit_exact.json 72 82 6; } > $O/at_refusals_c32.out
for a in jit_p50 oracle_v2 jit_exact ec_full ec_exact; do P $S/scripts/series.py $X/c32_$a.json 300 25 120; P $S/scripts/series.py $X/c32_$a.json 60 55 85; done > $O/series_c32.out
for a in jit_p50 oracle_v2 jit_exact; do P $S/scripts/series.py $X/c28_$a.json 600 0 120; done > $O/series_c28.out
for a in jit_p50 oracle_v2 jit_exact ec_full ec_exact; do P $S/scripts/iostat_bins.py results/campaign32 $a 300 25 120; P $S/scripts/iostat_bins.py results/campaign32 $a 60 55 85; done > $O/iostat_c32.out
for a in jit_p50 oracle_v2 jit_exact; do P $S/scripts/iostat_bins.py results/campaign28 $a 600 0 120; done > $O/iostat_c28.out
echo done
