"""jit_p50's staged reads: hinted gap (ntp_plan gap_ms), commit-to-stage time, stage-to-arrival time, true wait.
Usage: v_stage_gaps.py label"""
import sys, collections
sys.path.insert(0, __import__('os').path.dirname(__file__))
from vcommon import *
lab = sys.argv[1]
sc = scan(lab); _, reqs = client(lab); rec = {r['rid']: r for r in reqs}
plan = {}; stage = {}; arr = {}
for t, e, d in sc['events']:
    if e == 'ntp_plan' and d['rid'] not in plan: plan[d['rid']] = (t, d['gap_ms'] / 1e3)
    elif e == 'ntp_stage' and d['rid'] not in stage: stage[d['rid']] = (t, d['tokens'], d['matched'])
    elif e == 'ntp_arrive' and d['rid'] not in arr: arr[d['rid']] = t
g = [plan[r][1] for r in stage if r in plan]; c2s = [stage[r][0] - plan[r][0] for r in stage if r in plan]
s2a = [arr.get(r, rec[r]['t_send'] if r in rec else None) - stage[r][0] for r in stage if r in rec]
tw = [rec[r]['wait_s'] for r in stage if r in rec]
print(f'{lab}: staged {len(stage)}; hinted gap p10/p50/p90 {q(g,.1):.1f}/{q(g,.5):.1f}/{q(g,.9):.1f} s; plan-to-stage p50 {q(c2s,.5):.1f} s (p90 {q(c2s,.9):.1f}); '
      f'stage-to-arrival p10/p50/p90 {q(s2a,.1):.1f}/{q(s2a,.5):.1f}/{q(s2a,.9):.1f} s; true wait p50 {q(tw,.5):.1f} s; staged tokens p50 {q([v[1] for v in stage.values()],.5)}')
