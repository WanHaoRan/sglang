"""Counts of rule events (ec_*, ntp_stage, ntp_expire by reason, srs_unpin by reason, srs_pin_skipped) per arm."""
import sys, collections
sys.path.insert(0, __import__('os').path.dirname(__file__))
from vcommon import *
for a in ARMS:
    ev = scan(a)['events']
    c = collections.Counter()
    for t, e, d in ev:
        if e.startswith('ec_') or e in ('ntp_stage', 'srs_pin_skipped'): c[e] += 1
        elif e == 'ntp_expire': c[f'ntp_expire:{d.get("reason")}:staged={d.get("staged")}'] += 1
        elif e == 'srs_unpin': c[f'srs_unpin:{d.get("reason")}'] += 1
    print(a, dict(sorted(c.items())))
