"""For ec_full's 'wait' decisions whose next event for the rid was the turn's arrival: time from the decision to the
arrival, and the planned start relative to the arrival. For 'wait' followed by an 'arrival' re-decision: did the
re-decision come before the planned start? Usage: v_wait_next.py label"""
import sys, collections
sys.path.insert(0, __import__('os').path.dirname(__file__))
from vcommon import *
lab = sys.argv[1]
ev = scan(lab)['events']
by = collections.defaultdict(list)
for t, e, d in ev:
    if e in ('ec_start', 'ntp_arrive') and 'rid' in d: by[d['rid']].append((t, e, d))
to_arr = []; redec_before = redec_after = 0
for rid, es in by.items():
    for i, (t, e, d) in enumerate(es):
        if e != 'ec_start' or d['decision'] != 'wait' or i + 1 >= len(es): continue
        t2, e2, d2 = es[i + 1]; ps = t + d['start_ms'] / 1000
        if e2 == 'ntp_arrive': to_arr.append((t2 - t, ps - t2))
        elif d2.get('decision') == 'arrival':
            if t2 <= ps + 0.6: redec_before += 1
            else: redec_after += 1
print(f'{lab}: wait -> arrival of the turn: {len(to_arr)}; decision to arrival median {q([x[0] for x in to_arr],.5):.1f} s; planned start after arrival by median {q([x[1] for x in to_arr],.5):.0f} s')
print(f'  wait -> re-decided arrival: at or before the planned start (+0.6 s) {redec_before}, after {redec_after}')
