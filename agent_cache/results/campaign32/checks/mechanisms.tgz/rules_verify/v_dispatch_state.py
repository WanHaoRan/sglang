"""At each srs_dispatch: in-flight read tokens (inflight_pages*64, logged after the launch), pinned read tokens, and the
size of the read; refused (launched=0) against launched, by window. Usage: v_dispatch_state.py label lo_min hi_min"""
import sys, collections
sys.path.insert(0, __import__('os').path.dirname(__file__))
from vcommon import *
lab, lo, hi = sys.argv[1], float(sys.argv[2]) * 60, float(sys.argv[3]) * 60
ev = scan(lab)['events']
g = {0: collections.defaultdict(list), 1: collections.defaultdict(list)}
for t, e, d in ev:
    if e == 'srs_dispatch' and lo <= t < hi:
        L = d['launched']
        g[L]['inflight'].append(d['inflight_pages'] * 64 - (d['pages'] * 64 if L else 0))
        g[L]['pinned'].append(d['pinned_tokens']); g[L]['size'].append(d['pages'] * 64); g[L]['waited'].append(d['waited_ms'])
for L in (0, 1):
    v = g[L]
    if not v['size']: print(lab, 'launched', L, 'none'); continue
    print(f'{lab} [{lo/60:.0f},{hi/60:.0f}) launched={L}: n {len(v["size"])}; in-flight others K p50 {q(v["inflight"],.5)/1e3:.0f} p90 {q(v["inflight"],.9)/1e3:.0f}; '
          f'pinned K p50 {q(v["pinned"],.5)/1e3:.0f} p90 {q(v["pinned"],.9)/1e3:.0f}; read size K p50 {q(v["size"],.5)/1e3:.1f}; waited ms p50 {q(v["waited"],.5)}')
