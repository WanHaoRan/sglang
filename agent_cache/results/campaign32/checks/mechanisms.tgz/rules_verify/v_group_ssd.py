"""Paired SSD tokens used at admission (client 'storage') and recomputed, per group of a reference arm's plan
(timed out / staged / regular), returning requests sent in [lo, hi) of the reference arm's clock and present in all
arms. Usage: v_group_ssd.py lo hi ref arm..."""
import sys, collections
sys.path.insert(0, __import__('os').path.dirname(__file__))
from vcommon import *
lo, hi, ref = float(sys.argv[1]), float(sys.argv[2]), sys.argv[3]; labs = sys.argv[4:]
R = {}
for a in set(labs + [ref]):
    _, rs = client(a); R[a] = {key(r): r for r in rs}
sc = scan(ref); exp = set(); stg = set()
for t, e, d in sc['events']:
    if e == 'ntp_expire' and d['reason'] == 'timeout': exp.add(d['rid'])
    elif e == 'ntp_stage': stg.add(d['rid'])
rb = R[ref]; grp = collections.defaultdict(list)
for k, r in rb.items():
    if lo <= r['t_send'] < hi and r['k'] > 0 and (r.get('ideal_cached') or 0) > 0 and all(k in R[a] for a in labs):
        grp['plan timed out' if r['rid'] in exp else 'read staged' if r['rid'] in stg else 'regular'].append(k)
for g in ('plan timed out', 'read staged', 'regular'):
    ks = grp[g]
    print(f'{g:15s} n {len(ks):5d}: ' + '; '.join(
        f'{a} SSD {sum(tiers(R[a][k])[2] for k in ks)/1e6:.2f} M, recomputed {sum(max(0, R[a][k]["ideal_cached"] - sum(tiers(R[a][k]))) for k in ks)/1e6:.2f} M' for a in labs))
