"""Count HICACHE_EVT event names (and keys seen) in a server.log. Usage: evt_census.py server.log"""
import sys, re, collections
cnt = collections.Counter(); keys = collections.defaultdict(set); ex = {}
other = collections.Counter()
with open(sys.argv[1], errors='replace') as f:
    for line in f:
        i = line.find('HICACHE_EVT ')
        if i < 0:
            if 'ReqTimeStats' in line: other['ReqTimeStats'] += 1
            elif 'NIXL L3 cleanup' in line or 'L3 cleanup' in line: other['L3cleanup'] += 1
            continue
        rest = line[i+12:].split()
        if not rest: continue
        ev = rest[0]; cnt[ev] += 1
        for kv in rest[1:]:
            if '=' in kv: keys[ev].add(kv.split('=',1)[0])
        if ev not in ex: ex[ev] = line.strip()[:400]
for ev, n in cnt.most_common():
    print(f"{ev:28s} {n:8d}  keys={sorted(keys[ev])}")
print(other)
print('--- examples')
for ev in cnt: print(ex[ev])
