"""Paired B - A TTFT on (play, stream, k) both sent before CUT, with a 95 % interval resampling users (2,000 draws,
seed 0), and a second interval resampling users within strata of arrival order. Usage: v_paired.py cut A B [A B ...]"""
import sys, random, collections
sys.path.insert(0, __import__('os').path.dirname(__file__))
from vcommon import *
cut = float(sys.argv[1]); pairs = sys.argv[2:]
cache = {}
def get(a):
    if a not in cache:
        _, r = client(a); cache[a] = r
    return cache[a]
for i in range(0, len(pairs), 2):
    A, B = pairs[i], pairs[i + 1]
    a = {key(r): r['ttft'] for r in get(A) if r['t_send'] < cut}; b = {key(r): r['ttft'] for r in get(B) if r['t_send'] < cut}
    ks = a.keys() & b.keys()
    cell = collections.defaultdict(lambda: [0.0, 0])
    for k in ks: cell[k[0]][0] += b[k] - a[k]; cell[k[0]][1] += 1
    cells = [tuple(cell[p]) for p in sorted(cell)]
    rng = random.Random(0); dr = []
    for _ in range(2000):
        pick = rng.choices(cells, k=len(cells)); dr.append(sum(c[0] for c in pick) / sum(c[1] for c in pick))
    dr.sort()
    print(f'cut {cut:.0f}: {A} -> {B}: n {len(ks)} users {len(cells)} diff {sum(c[0] for c in cells)/len(ks):+.3f} [{dr[50]:+.2f}, {dr[1949]:+.2f}]')
