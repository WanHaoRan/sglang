"""ec_start decisions of an expected-cost arm: counts, distinct plans, what followed each 'wait', planned start,
read and wait estimates, rent per second. Usage: v_ec_start.py label"""
import sys, collections
sys.path.insert(0, __import__('os').path.dirname(__file__))
from vcommon import *
lab = sys.argv[1]
sc = scan(lab); ev = sc['events']
by = collections.defaultdict(list)
plans = set(); stages = []
for t, e, d in ev:
    if e in ('ec_start', 'ntp_arrive', 'ntp_plan', 'ntp_stage', 'ntp_expire', 'ntp_admit') and 'rid' in d:
        by[d['rid']].append((t, e, d))
    if e == 'ntp_plan': plans.add(d['rid'])
    if e == 'ntp_stage': stages.append((t, d))
dec = collections.Counter(); rids_dec = collections.defaultdict(list)
for rid, es in by.items():
    for t, e, d in es:
        if e == 'ec_start':
            dec[d['decision']] += 1; rids_dec[rid].append(d['decision'])
print(f'{lab}: ntp_plan {len(plans)} plans; ec_start {sum(dec.values())} = {dict(dec)}; distinct rids with ec_start {len(rids_dec)}; '
      f'with a wait {sum(1 for v in rids_dec.values() if "wait" in v)}; ntp_stage {len(stages)}')
first = collections.Counter(v[0] for v in rids_dec.values())
print('first decision per rid:', dict(first))
seqs = collections.Counter(tuple(v) for v in rids_dec.values())
print('decision sequences (top 8):', seqs.most_common(8))
# what followed each 'wait'
nxt = collections.Counter(); arr_before = []; start_ms = []; read_ms = []; wait_ms = []; stall = []; tok = []; rent = []
for rid, es in by.items():
    for i, (t, e, d) in enumerate(es):
        if e != 'ec_start' or d['decision'] != 'wait': continue
        start_ms.append(d['start_ms']); read_ms.append(d['read_ms']); wait_ms.append(d['wait_ms'])
        stall.append(max(0, d['read_ms'] - d['wait_ms'])); tok.append(d['tokens']); rent.append(float(d['price']) * d['tokens'])
        follow = None
        for t2, e2, d2 in es[i + 1:]:
            if e2 == 'ec_start': follow = 'ec_start ' + d2['decision']; break
            if e2 == 'ntp_arrive':
                follow = 'turn arrived'; arr_before.append((t2 - t) - d['start_ms'] / 1000.0); break
        nxt[follow or 'nothing'] += 1
print('after a wait, next:', dict(nxt))
if arr_before:
    print(f'  turn arrived: {len(arr_before)}; arrival minus planned start, s: median {q(arr_before,.5):.1f}, max {max(arr_before):.1f}; '
          f'arrived before the planned start: {sum(1 for x in arr_before if x < 0)}')
print(f'wait: planned start s p10 {q(start_ms,.1)/1e3:.0f} p50 {q(start_ms,.5)/1e3:.0f} p90 {q(start_ms,.9)/1e3:.0f}; read_ms p50 {q(read_ms,.5)}; '
      f'wait_ms p50 {q(wait_ms,.5)}; stall (read-wait) p50 {q(stall,.5)} ms; tokens p50 {q(tok,.5)}; rent s/s at missing tokens p50 {q(rent,.5):.2f}')
# for arrival decisions too
for dn in ('arrival', 'now'):
    rr = [(d['read_ms'], d['wait_ms'], d['tokens'], d['start_ms']) for rid, es in by.items() for t, e, d in es if e == 'ec_start' and d['decision'] == dn]
    if rr:
        print(f'{dn}: n {len(rr)}; read_ms p50 {q([x[0] for x in rr],.5)}; wait_ms p50 {q([x[1] for x in rr],.5)}; '
              f'stall>0: {sum(1 for x in rr if x[0] > x[1])}; tokens p50 {q([x[2] for x in rr],.5)}')
