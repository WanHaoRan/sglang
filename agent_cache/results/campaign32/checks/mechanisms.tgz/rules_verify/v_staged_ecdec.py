"""For the turns jit_p50 staged (sent before the cut), the ec_start decisions ec_full logged for the same turns."""
import sys, collections
sys.path.insert(0, __import__('os').path.dirname(__file__))
from vcommon import *
scj = scan('jit_p50'); _, rj = client('jit_p50'); recj = {r['rid']: r for r in rj}
stg = {d['rid'] for t, e, d in scj['events'] if e == 'ntp_stage'}
keys = {key(recj[r]) for r in stg if r in recj and recj[r]['t_send'] < CUT}
sce = scan('ec_full'); _, re_ = client('ec_full')
ridk = {key(r): r['rid'] for r in re_ if r['t_send'] < CUT}
dec = collections.defaultdict(list)
for t, e, d in sce['events']:
    if e == 'ec_start': dec[d['rid']].append(d['decision'])
c = collections.Counter()
for k in keys:
    if k not in ridk: c['not sent in ec_full'] += 1; continue
    ds = dec.get(ridk[k], [])
    c['none' if not ds else 'only arrival' if set(ds) == {'arrival'} else 'has wait/now'] += 1
print(len(keys), dict(c), 'only arrival or none:', c['none'] + c['only arrival'])
