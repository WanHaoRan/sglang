"""ec_price lines of an expected-cost arm: price values over time, staged, harm, refused. Usage: v_price.py label"""
import sys, collections
sys.path.insert(0, __import__('os').path.dirname(__file__))
from vcommon import *
lab = sys.argv[1]
ev = scan(lab)['events']
P = [(t, d) for t, e, d in ev if e == 'ec_price']
after = [x for x in P if x[0] >= 0]
vals = collections.Counter(d['price'] for t, d in P)
print(f'{lab}: ec_price lines {len(P)} ({len(after)} after t_start); distinct prices {len(vals)}; most common {vals.most_common(4)}')
print(f'  lines with staged>0: {sum(1 for t, d in P if d["staged"] > 0)}; harm_ms>0: {sum(1 for t, d in P if d["harm_ms"] > 0)}; '
      f'refused sum {sum(d["refused"] for t, d in P)/1e6:.2f} M; held max {max(d["held"] for t, d in P)}')
prev = None
for t, d in P:
    if d['price'] != prev:
        print(f'   t={t/60:7.2f} min price {d["price"]:.3g} staged {d["staged"]} harm_ms {d["harm_ms"]} refused {d["refused"]}')
        prev = d['price']
        if t > 7200: break
