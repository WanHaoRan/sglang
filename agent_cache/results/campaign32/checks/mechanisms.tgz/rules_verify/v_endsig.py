"""Session-end registrations (nue_register next_use_ms=ended) before 6,600 s: at a commit (same rid finished within
50 ms, ReqTimeStats) or otherwise; 'false' when the same (play, stream) has a later request in the client records.
Also hint accuracy: ntp_arrive arr_err_ms quantiles. Usage: v_endsig.py label..."""
import sys, collections
sys.path.insert(0, __import__('os').path.dirname(__file__))
from vcommon import *
for lab in sys.argv[1:]:
    sc = scan(lab); _, reqs = client(lab)
    rec = {r['rid']: r for r in reqs}
    have = {(r['play'], r['stream'], r['k']) for r in reqs}
    maxk = collections.defaultdict(int)
    for r in reqs: maxk[(r['play'], r['stream'])] = max(maxk[(r['play'], r['stream'])], r['k'])
    rts = sc['rts']; commit = other = false = 0; false_early = 0
    errs = []
    for t, e, d in sc['events']:
        if e == 'ntp_arrive' and d['arr_err_ms'] != 'na' and t < 6600: errs.append(d['arr_err_ms'] / 1e3)
        if e != 'nue_register' or d['next_use_ms'] != 'ended' or t >= 6600: continue
        rid = d['rid']
        if rid in rts and abs(rts[rid]['t_log'] - t) < 0.05:
            commit += 1
            r = rec.get(rid)
            if r and maxk[(r['play'], r['stream'])] > r['k']:
                false += 1
                if t < 1800: false_early += 1
        else:
            other += 1
    print(f'{lab:10s}: ended at a commit {commit} (false {false}, of them before minute 30 {false_early}); otherwise {other}; '
          f'arr_err s p50 {q(errs,.5):.2f} p90 {q(errs,.9):.2f} p99 {q(errs,.99):.2f} (n {len(errs)})')
