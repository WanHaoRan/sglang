"""Share of returning requests whose history was under 95 % resident (GPU+host per client cached_details) at
admission, on requests present in all arms, sent in [lo, hi) of the first arm's clock; overall and by true wait;
also grouped by the plan of a reference arm (timed out / staged / regular). Usage: v_missed.py lo hi ref arm1 arm2 ..."""
import sys, collections
sys.path.insert(0, __import__('os').path.dirname(__file__))
from vcommon import *
lo, hi, ref = float(sys.argv[1]), float(sys.argv[2]), sys.argv[3]; labs = sys.argv[4:]
R = {}
for a in set(labs + [ref]):
    _, rs = client(a); R[a] = {key(r): r for r in rs}
def missed(r):
    d, h, s = tiers(r); return (d + h) < 0.95 * r['ideal_cached']
base = R[labs[0]]
ks = [k for k, r in base.items() if lo <= r['t_send'] < hi and r['k'] > 0 and (r.get('ideal_cached') or 0) > 0 and all(k in R[a] for a in labs)]
print(f'requests sent in [{lo:.0f},{hi:.0f}) of {labs[0]} clock, in all of {labs}: {len(ks)}')
for name, sel in (('all', ks), ('true wait 10-60 s', [k for k in ks if 10 <= (base[k]['wait_s'] or 0) < 60])):
    print(f'  {name:18s} n {len(sel):5d}: ' + ', '.join(f'{a} {100*sum(missed(R[a][k]) for k in sel)/len(sel):.1f} %' for a in labs))
# grouping by ref's plan, on ref's clock
sc = scan(ref); exp = set(); stg = set()
for t, e, d in sc['events']:
    if e == 'ntp_expire' and d['reason'] == 'timeout': exp.add(d['rid'])
    elif e == 'ntp_stage': stg.add(d['rid'])
rb = R[ref]
ks2 = [k for k, r in rb.items() if lo <= r['t_send'] < hi and r['k'] > 0 and (r.get('ideal_cached') or 0) > 0 and all(k in R[a] for a in labs)]
grp = collections.defaultdict(list)
for k in ks2:
    rid = rb[k]['rid']
    grp['plan timed out' if rid in exp else 'read staged' if rid in stg else 'regular'].append(k)
for g in ('plan timed out', 'read staged', 'regular'):
    sel = grp[g]
    print(f'  {ref} {g:15s} n {len(sel):5d}: ' + ', '.join(f'{a} {100*sum(missed(R[a][k]) for k in sel)/max(1,len(sel)):.1f} %' for a in labs))
