#!/bin/bash
# Reruns the reviewer's checks (after vscan.py has written v_<label>.json for the six arms). From agent_cache/.
S=/tmp/claude-1001/-home-wanhr-sglang/7c93b1d5-dc1c-431d-8d3e-efb4ae23a30d/scratchpad/c32/rules_verify
P() { nice -n 15 python3 -I -B "$@"; }
{ P $S/v_refusals.py 30 110; P $S/v_refusals.py 0 76; } > $S/v_refusals.out
{ P $S/v_ec_start.py ec_full; P $S/v_ec_start.py ec_exact; P $S/v_wait_vs_arrival.py ec_full; P $S/v_wait_next.py ec_full; } > $S/v_ec_start.out
{ P $S/v_price.py ec_full; P $S/v_price.py ec_exact; P $S/v_rule_events.py; } > $S/v_price_rules.out
{ P $S/v_staged.py jit_p50 ec_full jit_exact; P $S/v_abort_pins.py jit_p50; P $S/v_staged_ecdec.py; P $S/v_staged_control.py jit_p50 ec_full; P $S/v_expired_control.py jit_p50 ec_full; P $S/v_stage_gaps.py jit_p50; P $S/v_stage_times.py ec_full ec_exact jit_exact; } > $S/v_staged.out
P $S/v_expired.py jit_p50 ec_full jit_exact > $S/v_expired.out
{ P $S/v_read_split.py 1800 3900 jit_p50 ec_full; P $S/v_group_ssd.py 1800 3900 jit_p50 jit_p50 ec_full; } > $S/v_read_split.out
{ P $S/v_missed.py 1800 3900 jit_p50 ec_full jit_p50 jit_exact ec_exact; P $S/v_missed.py 3900 4800 jit_p50 ec_full jit_p50 jit_exact ec_exact; } > $S/v_missed.out
{ P $S/v_recompute.py 4560 6600 ec_full jit_p50 jit_exact ec_exact oracle_v2; P $S/v_recompute.py 1800 4560 ec_full jit_p50 jit_exact ec_exact oracle_v2; } > $S/v_recompute.out
{ P $S/v_endsig.py ec_full jit_p50 ec_exact jit_exact; P $S/v_false_end_hints.py ec_full; } > $S/v_endsig.out
{ P $S/v_paired.py 6600 ec_full jit_p50 ec_full jit_exact ec_full ec_exact ec_exact jit_exact jit_p50 jit_exact jit_exact oracle_v2; P $S/v_paired.py 5500 ec_full jit_p50 ec_full jit_exact ec_full ec_exact; } > $S/v_paired.out
{ P $S/v_dispatch_state.py jit_p50 0 76; P $S/v_dispatch_state.py oracle_v2 0 76; P $S/v_dispatch_state.py jit_p50 76 110; P $S/v_dispatch_state.py ec_full 76 110; } > $S/v_dispatch_state.out
P $S/v_queue.py 25 100 > $S/v_queue.out
