"""Per-minute median #queue-req and #running-req from Decode batch lines (my scan), minutes lo..hi, all arms.
Usage: v_queue.py lo hi"""
import sys
sys.path.insert(0, __import__('os').path.dirname(__file__))
from vcommon import *
lo, hi = int(sys.argv[1]), int(sys.argv[2])
arms = ['ec_full', 'jit_p50', 'jit_exact', 'ec_exact', 'oracle_v2', 'hicache']
data = {a: scan(a)['dec_min'] for a in arms}
print('min  ' + ' '.join(f'{a:>13s}' for a in arms) + '   (queue/running medians)')
for m in range(lo, hi + 1):
    cells = []
    for a in arms:
        v = data[a].get(str(m))
        cells.append(f'{v[1]:5.0f}/{v[0]:3.0f}    ' if v else '      -      ')
    print(f'{m:3d}  ' + ' '.join(cells))
