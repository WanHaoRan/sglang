"""Paired B - A TTFT on requests both arms sent before 6,600 s; contribution of each 5-minute bin of A's send time
(sum of B - A in the bin / all shared requests). Usage: v_paired_bins.py A B [bin_minutes]"""
import sys, collections
sys.path.insert(0, __import__('os').path.dirname(__file__))
from vcommon import *
A, B = sys.argv[1], sys.argv[2]; W = float(sys.argv[3]) if len(sys.argv) > 3 else 5.0
_, ra = client(A); _, rb = client(B)
a = {key(r): r for r in ra if r['t_send'] < CUT}; b = {key(r): r for r in rb if r['t_send'] < CUT}
ks = a.keys() & b.keys(); n = len(ks)
tot = sum(b[k]['ttft'] - a[k]['ttft'] for k in ks) / n
print(f'{A} -> {B}: shared {n}, diff {tot:+.3f} s')
bins = collections.defaultdict(lambda: [0.0, 0, 0.0, 0.0])
for k in ks:
    m = int(a[k]['t_send'] // (W * 60))
    c = bins[m]; c[0] += b[k]['ttft'] - a[k]['ttft']; c[1] += 1; c[2] += a[k]['ttft']; c[3] += b[k]['ttft']
cum = 0.0
print('bin(min)   n   contrib   cum   meanA  meanB  (bin by A send time)')
for m in sorted(bins):
    c = bins[m]; cum += c[0] / n
    print(f'{m*W:5.0f}-{(m+1)*W:<5.0f} {c[1]:5d} {c[0]/n:+7.3f} {cum:+7.3f} {c[2]/c[1]:7.2f} {c[3]/c[1]:7.2f}')
def span(lo, hi):
    return sum(b[k]['ttft'] - a[k]['ttft'] for k in ks if lo * 60 <= a[k]['t_send'] < hi * 60) / n
for lo, hi in [(0, 65), (65, 70), (70, 75), (75, 80), (80, 85), (85, 90), (65, 90), (90, 200), (0, 80), (80, 200)]:
    print(f'span {lo}-{hi}: {span(lo, hi):+.3f}')
