"""When each arm staged reads (ntp_stage), by 5-minute window, with tokens. Usage: v_stage_times.py label..."""
import sys, collections
sys.path.insert(0, __import__('os').path.dirname(__file__))
from vcommon import *
for lab in sys.argv[1:]:
    c = collections.Counter(); tok = collections.Counter()
    for t, e, d in scan(lab)['events']:
        if e == 'ntp_stage': c[int(t // 300)] += 1; tok[int(t // 300)] += d['tokens']
    print(f'{lab:10s} ' + ' '.join(f'{w*5}:{c[w]}({tok[w]/1e3:.0f}K)' for w in sorted(c)))
