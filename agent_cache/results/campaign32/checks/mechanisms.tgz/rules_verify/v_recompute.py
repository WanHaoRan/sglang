"""History recomputed by returning requests (ideal_cached minus device+host+storage, >= 0) in a time window, and the part
from requests with a refused read (any srs_dispatch launched=0 for the rid). Window by (a) the ReqTimeStats log time
(request finish), (b) admission (ntp_admit, else t_send + ttft). Usage: v_recompute.py lo_s hi_s label..."""
import sys, collections
sys.path.insert(0, __import__('os').path.dirname(__file__))
from vcommon import *
lo, hi = float(sys.argv[1]), float(sys.argv[2])
for lab in sys.argv[3:]:
    sc = scan(lab); _, reqs = client(lab)
    refused = set(); capped = set(); adm = {}; expired = set(); staged = set()
    for t, e, d in sc['events']:
        if e == 'srs_dispatch' and d['launched'] == 0: refused.add(d['rid'])
        elif e == 'ntp_gate' and d['decision'] == 'capped': capped.add(d['rid'])
        elif e == 'ntp_admit' and d['rid'] not in adm: adm[d['rid']] = t
        elif e == 'ntp_expire' and d['reason'] == 'timeout': expired.add(d['rid'])
        elif e == 'ntp_stage': staged.add(d['rid'])
    rts = sc['rts']
    for mode in ('finish', 'admit'):
        tot = ref = 0; n = nref = 0; grp = collections.Counter()
        for r in reqs:
            if r['k'] == 0 or not r.get('ideal_cached'): continue
            rid = r['rid']
            if mode == 'finish':
                if rid not in rts: continue
                tt = rts[rid]['t_log']
            else:
                tt = adm.get(rid, r['t_send'] + r['ttft'])
            if not (lo <= tt < hi): continue
            a = max(0, r['ideal_cached'] - sum(tiers(r)))
            tot += a; n += 1
            g = 'refused' if rid in refused else 'capped' if rid in capped else 'expired' if rid in expired else 'staged' if rid in staged else 'other'
            grp[g] += a
            if rid in refused: ref += a; nref += 1
        print(f'{lab:10s} [{lo:.0f},{hi:.0f}) by {mode:6s}: returning {n}, recomputed {tot/1e6:.2f} M; refused-read requests {nref}: {ref/1e6:.2f} M '
              f'({100*ref/max(1,tot):.1f} %); groups ' + ', '.join(f'{k} {v/1e6:.2f}' for k, v in grp.most_common()))
