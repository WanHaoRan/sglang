"""What the client hinted for the requests whose commit registered the session as ended (nue_register ended at the
request's finish) while the stream sent again: hint fields. Usage: v_false_end_hints.py label"""
import sys, collections
sys.path.insert(0, __import__('os').path.dirname(__file__))
from vcommon import *
lab = sys.argv[1]
sc = scan(lab); _, reqs = client(lab); rec = {r['rid']: r for r in reqs}
maxk = collections.defaultdict(int)
for r in reqs: maxk[(r['play'], r['stream'])] = max(maxk[(r['play'], r['stream'])], r['k'])
rts = sc['rts']; kinds = collections.Counter(); ex = []
for t, e, d in sc['events']:
    if e != 'nue_register' or d['next_use_ms'] != 'ended' or t >= 6600: continue
    rid = d['rid']
    if rid in rts and abs(rts[rid]['t_log'] - t) < 0.05 and rid in rec:
        r = rec[rid]; false = maxk[(r['play'], r['stream'])] > r['k']
        h = r.get('hint') or {}
        sig = ('false' if false else 'true', 'next_rid' if h.get('next_rid') else 'no next_rid', 'matched=' + str(h.get('matched'))[:20], 'point' if h.get('point_s') is not None else 'no point', 'dist' if h.get('dist') or h.get('p10_s') is not None else '')
        kinds[sig] += 1
        if false and len(ex) < 3: ex.append(h)
for k, v in kinds.most_common(12): print(v, k)
print(ex)
