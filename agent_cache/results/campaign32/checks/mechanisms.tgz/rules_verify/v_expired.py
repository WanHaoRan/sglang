"""Plans that timed out (ntp_expire reason=timeout): did the same instant register the session as ended
(nue_register rid=<same> next_use_ms=ended)? Did the turn come, when, and how did those turns fare in other arms?
Usage: v_expired.py label [cmp...]"""
import sys, collections
sys.path.insert(0, __import__('os').path.dirname(__file__))
from vcommon import *
lab = sys.argv[1]; cmps = sys.argv[2:]
sc = scan(lab); _, reqs = client(lab); rec = {r['rid']: r for r in reqs}
exp = {}; ended = collections.defaultdict(list); plan = {}; arr = {}
for t, e, d in sc['events']:
    if e == 'ntp_expire' and d['reason'] == 'timeout': exp[d['rid']] = t
    elif e == 'nue_register' and d['next_use_ms'] == 'ended': ended[d['rid']].append(t)
    elif e == 'ntp_plan' and d['rid'] not in plan: plan[d['rid']] = (t, d)
    elif e == 'ntp_arrive' and d['rid'] not in arr: arr[d['rid']] = t
same = sum(1 for rid, t in exp.items() if any(abs(x - t) < 0.01 for x in ended.get(rid, [])))
came = [rid for rid in exp if rid in rec]
after = [arr.get(rid, rec[rid]['t_send']) - exp[rid] for rid in came]
gap = [plan[rid][1]['gap_ms'] / 1e3 for rid in exp if rid in plan]
true_wait = [rec[rid]['wait_s'] for rid in came]
print(f'{lab}: timed-out plans {len(exp)}; with nue_register ended at the same instant {same}; turn came {len(came)}; '
      f'arrival after expiry median {q(after,.5):.1f} s (came before expiry: {sum(1 for x in after if x < 0)}); hinted gap median {q(gap,.5):.1f} s; true wait median {q(true_wait,.5):.0f} s')
keys = [key(rec[rid]) for rid in came if rec[rid]['t_send'] < CUT]
def summ(rs_all):
    bk = {key(r): r for r in rs_all if r['t_send'] < CUT}
    rs = [bk[k] for k in keys if k in bk]
    ag = [max(0, r['ideal_cached'] - sum(tiers(r))) / r['ideal_cached'] for r in rs if r.get('ideal_cached')]
    return f'n {len(rs)} TTFT {mean(r["ttft"] for r in rs):.2f} recomputed {mean(ag):.3f}'
print(f'  those turns sent before the cut: {lab} {summ(reqs)}')
for c in cmps:
    _, cr = client(c); print(f'     {c}: {summ(cr)}')
