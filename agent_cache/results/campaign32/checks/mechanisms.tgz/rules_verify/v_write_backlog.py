"""SSD write backlog (h2s_submit tokens minus h2s_done tokens, i.e. host nodes held by a host lock until their SSD
write is acknowledged) at every srs_dispatch, launched=0 against launched=1, by 5-minute window. Reviewer's code.
Usage, from agent_cache/: v_write_backlog.py label [label...]"""
import sys, os, json, datetime as dt, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vcommon import AC, manifest, q, mean
for lab in sys.argv[1:]:
    run, prog = manifest()[lab]
    t0 = json.loads(open(os.path.join(AC, 'results', run, prog, 'client.jsonl')).readline())['t_start']
    sub = {}; backlog = 0; rows = []; wmax = collections.defaultdict(int); wavg = collections.defaultdict(list)
    with open(os.path.join(AC, 'results', run, 'server.log'), errors='replace') as f:
        for line in f:
            if 'HICACHE_EVT h2s_' not in line and 'HICACHE_EVT srs_dispatch' not in line: continue
            t = dt.datetime.strptime(line[1:20], '%Y-%m-%d %H:%M:%S').replace(tzinfo=dt.timezone.utc).timestamp() + int(line[21:24]) / 1000 - t0
            p = line.split('HICACHE_EVT ', 1)[1].split()
            d = dict(x.split('=', 1) for x in p[1:] if '=' in x)
            if p[0] == 'h2s_submit':
                sub[d['op']] = int(d['tokens']); backlog += int(d['tokens'])
            elif p[0] == 'h2s_done':
                backlog -= sub.pop(d['op'], 0)
            elif p[0] == 'srs_dispatch':
                rows.append((t, int(d['launched']), backlog))
            w = int(t // 300)
            wmax[w] = max(wmax[w], backlog)
    print(f'===== {lab}: write backlog at dispatch (K tokens): launched=0 n={sum(1 for r in rows if r[1]==0)} '
          f'p10/p50/p90 {q([r[2] for r in rows if r[1]==0],.1)/1e3:.0f}/{q([r[2] for r in rows if r[1]==0],.5)/1e3:.0f}/{q([r[2] for r in rows if r[1]==0],.9)/1e3:.0f}; '
          f'launched=1 n={sum(1 for r in rows if r[1]==1)} p10/p50/p90 {q([r[2] for r in rows if r[1]==1],.1)/1e3:.0f}/{q([r[2] for r in rows if r[1]==1],.5)/1e3:.0f}/{q([r[2] for r in rows if r[1]==1],.9)/1e3:.0f}')
    by = collections.defaultdict(lambda: [0, 0, [], []])
    for t, l, b in rows:
        c = by[int(t // 300)]
        c[l] += 1; c[2 + l].append(b)
    print(' window | refused launched | backlog at refused p50 | at launched p50 | max backlog in window (K tokens)')
    for w in range(4, 23):
        c = by.get(w, [0, 0, [], []])
        print(f'  {w*5:3d}-{w*5+5:3d} | {c[0]:5d} {c[1]:5d} | {q(c[2],.5)/1e3 if c[2] else float("nan"):7.0f} | {q(c[3],.5)/1e3 if c[3] else float("nan"):7.0f} | {wmax.get(w,0)/1e3:7.0f}')
