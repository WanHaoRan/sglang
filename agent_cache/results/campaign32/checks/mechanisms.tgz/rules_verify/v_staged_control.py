"""Control for the staged-turn comparison: jit_p50's staged turns against its other returning turns sent in the same
minutes (matched by send-minute weights), paired with ec_full: mean TTFT difference and recomputed share.
Usage: v_staged_control.py A B   (A = jit_p50, B = ec_full)"""
import sys, collections
sys.path.insert(0, __import__('os').path.dirname(__file__))
from vcommon import *
A, B = sys.argv[1], sys.argv[2]
sc = scan(A); _, ra = client(A); _, rb = client(B)
stg = {d['rid'] for t, e, d in sc['events'] if e == 'ntp_stage'}
exp = {d['rid'] for t, e, d in sc['events'] if e == 'ntp_expire' and d['reason'] == 'timeout'}
kb = {key(r): r for r in rb if r['t_send'] < CUT}
def rec_share(r):
    return max(0, r['ideal_cached'] - sum(tiers(r))) / r['ideal_cached'] if r.get('ideal_cached') else None
grp = collections.defaultdict(lambda: collections.defaultdict(list))
for r in ra:
    if r['t_send'] >= CUT or r['k'] == 0 or key(r) not in kb: continue
    g = 'staged' if r['rid'] in stg else 'expired' if r['rid'] in exp else 'other'
    grp[g][int(r['t_send'] // 300)].append((r, kb[key(r)]))
st = grp['staged']
# weight 'other' turns by the staged turns' send-window counts
def stats(cells, weights=None):
    num = den = 0.0; ra_ = rb_ = 0.0; n = 0
    for w, pairs in cells.items():
        if not pairs: continue
        wt = (weights.get(w, 0) / len(pairs)) if weights is not None else 1.0
        for a, b in pairs:
            sa, sb = rec_share(a), rec_share(b)
            if sa is None or sb is None: continue
            num += wt * (a['ttft'] - b['ttft']); ra_ += wt * sa; rb_ += wt * sb; den += wt; n += 1
    return n, num / den, ra_ / den, rb_ / den
wts = {w: len(v) for w, v in st.items()}
print(f'{A} - {B} on paired returning turns: group n, TTFT diff, recomputed share {A}, {B}')
print('  staged          ', stats(st))
print('  other, same mix ', stats(grp['other'], wts))
print('  other, all      ', stats(grp['other']))
print('  expired, all    ', stats(grp['expired']))
