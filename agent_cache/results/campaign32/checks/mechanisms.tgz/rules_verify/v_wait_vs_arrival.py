"""For every 'wait' decision: planned start time (t + start_ms) against the turn's arrival (ntp_arrive, else client
t_send). Usage: v_wait_vs_arrival.py label"""
import sys, collections
sys.path.insert(0, __import__('os').path.dirname(__file__))
from vcommon import *
lab = sys.argv[1]
ev = scan(lab)['events']; _, reqs = client(lab)
send = {r['rid']: r['t_send'] for r in reqs}
arr = {}
for t, e, d in ev:
    if e == 'ntp_arrive' and d['rid'] not in arr: arr[d['rid']] = t
before = after = none = 0; gaps = []; since = []
for t, e, d in ev:
    if e == 'ec_start' and d['decision'] == 'wait':
        ta = arr.get(d['rid'], send.get(d['rid']))
        if ta is None: none += 1; continue
        ps = t + d['start_ms'] / 1000
        if ta < ps: before += 1; gaps.append(ps - ta)
        else: after += 1
        since.append(ta - t)
print(f'{lab}: waits {before + after + none}; turn arrived before the planned start {before}, after {after}, never {none}; '
      f'planned start minus arrival p50 {q(gaps,.5):.0f} s; arrival minus the wait decision p50 {q(since,.5):.1f} s, p10 {q(since,.1):.1f}')
