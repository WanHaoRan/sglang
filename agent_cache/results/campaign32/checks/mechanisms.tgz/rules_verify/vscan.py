"""Independent scan of one campaign-32 arm (reviewer's own code). Usage, from agent_cache/:
  python3 -I -B vscan.py <label> <out.json>
Stores: t_start (client), engine events (t relative to client t_start) except bulk transfer lines, ReqTimeStats per rid,
per-minute medians of the scheduler's Decode batch stats (running, queue, usage), NIXL cleanup times."""
import sys, os, json, re, datetime as dt, statistics as st, collections
AC = '/home/wanhr/sglang/agent_cache'
label, out = sys.argv[1], sys.argv[2]
man = {l.split()[0]: l.split()[1:3] for l in open(os.path.join(AC, 'results/campaign32/manifest.txt')) if l.strip()}
run, prog = man[label]
rdir = os.path.join(AC, 'results', run)
with open(os.path.join(rdir, prog, 'client.jsonl')) as f:
    t_start = json.loads(f.readline())['t_start']
SKIP = {'h2s_submit', 'h2s_done', 'd2h_submit', 'd2h_done', 'evict_device', 'prefetch_start', 'h2d_submit'}
def ts(s):
    # "[YYYY-MM-DD HH:MM:SS.mmm]"
    d = dt.datetime.strptime(s[1:20], '%Y-%m-%d %H:%M:%S').replace(tzinfo=dt.timezone.utc).timestamp()
    return d + int(s[21:24]) / 1000.0 - t_start
def num(v):
    try:
        if v.lstrip('-').isdigit(): return int(v)
        return float(v)
    except ValueError:
        return v
events = []; rts = {}; dec = collections.defaultdict(list); cleanup = []
DEC = re.compile(r"Decode batch, #running-req: (\d+), #token: \d+, token usage: ([\d.]+), .*#queue-req: (\d+)")
PF = re.compile(r"HiCache prefetch (success|dropped) req=(\S+) completed=(\d+) matched=(\d+) loaded=(\d+)")
RTS = re.compile(r"ReqTimeStats\(rid=([^,]+), input_len=(\d+), cached_input_len=(\d+), output_len=(\d+).*queue_duration=([\d.]+)ms, forward_duration=([\d.]+)ms, entry_time=([\d.]+)")
with open(os.path.join(rdir, 'server.log'), errors='replace') as f:
    for line in f:
        if not line.startswith('[20'): continue
        i = line.find('HICACHE_EVT ')
        if i >= 0:
            parts = line[i + 12:].split()
            if not parts or parts[0] in SKIP: continue
            d = {}
            for kv in parts[1:]:
                if '=' in kv:
                    k, v = kv.split('=', 1); d[k] = num(v)
            events.append([round(ts(line), 3), parts[0], d])
            continue
        if 'Decode batch' in line:
            m = DEC.search(line)
            if m:
                t = ts(line)
                if t >= 0: dec[int(t // 60)].append((int(m[1]), int(m[3]), float(m[2])))
            continue
        if 'HiCache prefetch ' in line:
            m = PF.search(line)
            if m:
                events.append([round(ts(line), 3), 'pf_' + m[1], {'rid': m[2], 'completed': int(m[3]), 'matched': int(m[4]), 'loaded': int(m[5])}])
            continue
        if 'ReqTimeStats(' in line:
            m = RTS.search(line)
            if m:
                rts[m[1]] = {'t_log': round(ts(line), 3), 'input_len': int(m[2]), 'cached_input_len': int(m[3]), 'output_len': int(m[4]),
                             'queue_ms': float(m[5]), 'fwd_ms': float(m[6]), 'entry': round(float(m[7]) - t_start, 3)}
            continue
        if 'L3 cleanup' in line:
            cleanup.append([round(ts(line), 1), line.strip()[25:200]])
mins = {m: [st.median(x[0] for x in v), st.median(x[1] for x in v), st.median(x[2] for x in v), len(v)] for m, v in sorted(dec.items())}
json.dump({'label': label, 't_start': t_start, 'events': events, 'rts': rts, 'dec_min': mins, 'cleanup': cleanup}, open(out, 'w'))
print(label, len(events), 'events', len(rts), 'rts', len(mins), 'minutes', cleanup)
