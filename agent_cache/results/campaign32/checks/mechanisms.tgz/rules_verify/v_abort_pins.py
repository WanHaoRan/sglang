"""jit_p50's early-read pins given back at an abort: did the later turn still find the read pages in memory?
For each such rid: tokens pinned, the turn's admission split (client cached_details) and what was read again for it
after arrival (pf_success loaded after arrival). Usage: v_abort_pins.py label"""
import sys, collections
sys.path.insert(0, __import__('os').path.dirname(__file__))
from vcommon import *
lab = sys.argv[1]
sc = scan(lab); _, reqs = client(lab); rec = {r['rid']: r for r in reqs}
by = collections.defaultdict(list)
for t, e, d in sc['events']:
    if isinstance(d, dict) and 'rid' in d: by[d['rid']].append((t, e, d))
rows = []
for rid, es in by.items():
    if not any(e == 'ntp_stage' for t, e, d in es): continue
    arr = next((t for t, e, d in es if e == 'ntp_arrive'), rec[rid]['t_send'] if rid in rec else float('inf'))
    pin = None
    for t, e, d in es:
        if e == 'srs_pin' and t < arr and pin is None: pin = [t, d['tokens'], None, None]
        elif e == 'srs_unpin' and pin is not None and pin[2] is None: pin[2], pin[3] = t, d['reason']
    if not pin or pin[3] != 'abort' or rid not in rec: continue
    r = rec[rid]; dv, h, s = tiers(r)
    reread = sum(d['loaded'] for t, e, d in es if e == 'pf_success' and t >= arr)
    rows.append((pin[1], dv, h, s, r['ideal_cached'], reread, arr - pin[2]))
n = len(rows)
print(f'{lab}: abort-released early-read pins whose turn came: {n}; pinned {sum(x[0] for x in rows)/1e6:.2f} M tokens; '
      f'turn arrived after the release: median {q([x[6] for x in rows],.5):.0f} s')
print(f'  at admission: ideal {sum(x[4] for x in rows)/1e6:.2f} M, GPU {sum(x[1] for x in rows)/1e6:.2f}, host {sum(x[2] for x in rows)/1e6:.2f}, '
      f'SSD {sum(x[3] for x in rows)/1e6:.2f}, recomputed {sum(max(0, x[4]-x[1]-x[2]-x[3]) for x in rows)/1e6:.2f}; read again after arrival {sum(x[5] for x in rows)/1e6:.2f} M')
