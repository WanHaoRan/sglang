"""Reviewer's shared loaders (stdlib)."""
import os, json, collections
AC = '/home/wanhr/sglang/agent_cache'
S = os.path.dirname(os.path.abspath(__file__))
CUT = 6600.0
ARMS = ['hicache', 'ec_full', 'ec_exact', 'jit_p50', 'jit_exact', 'oracle_v2']
def manifest():
    return {l.split()[0]: l.split()[1:3] for l in open(os.path.join(AC, 'results/campaign32/manifest.txt')) if l.strip()}
def client(label, all_phases=False):
    run, prog = manifest()[label]
    out = []; run_rec = None
    with open(os.path.join(AC, 'results', run, prog, 'client.jsonl')) as f:
        for line in f:
            if not line.strip(): continue
            r = json.loads(line)
            if r['kind'] == 'run': run_rec = r
            elif r['kind'] == 'req' and (all_phases or r.get('phase') == 'profile'):
                if r.get('error') or r.get('ttft') is None: continue
                out.append(r)
    return run_rec, out
def scan(label):
    return json.load(open(os.path.join(S, f'v_{label}.json')))
def key(r):
    return (r['play'], r['stream'], r['k'])
def tiers(r):
    d = r.get('cached_details') or {}
    if d:
        return int(d.get('device') or 0), int(d.get('host') or 0), int(d.get('storage') or 0)
    return int(r.get('cached_tokens') or 0), 0, 0
def q(v, p):
    v = sorted(v)
    return v[min(len(v) - 1, int(p * (len(v) - 1) + 0.5))] if v else float('nan')
def mean(v):
    v = list(v)
    return sum(v) / len(v) if v else float('nan')
