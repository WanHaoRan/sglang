"""SSD device (iostat_vdc.log, 10 s samples stamped at their end, UTC) against each arm's client clock, with the
engine's write I/O seconds (sum of h2s_io ms), read volume landed (pf_success loaded) and refused dispatches, in
5-minute windows. Reviewer's code. Usage: v_ssd.py lo_min hi_min label..."""
import sys, os, re, json, datetime as dt, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vcommon import *
lo, hi = int(sys.argv[1]), int(sys.argv[2]); W = 5
samples = []; t = None; hdr = None
for line in open(os.path.join(AC, 'results/campaign32/iostat_vdc.log')):
    m = re.match(r'^(\d\d)/(\d\d)/(\d{4}) (\d\d):(\d\d):(\d\d) (AM|PM)', line)
    if m:
        mo, d, y, h, mi, s, ap = m.groups(); h = int(h) % 12 + (12 if ap == 'PM' else 0)
        t = dt.datetime(int(y), int(mo), int(d), h, int(mi), int(s), tzinfo=dt.timezone.utc).timestamp(); continue
    if line.startswith('Device'): hdr = line.split(); continue
    if line.startswith('vdc') and t is not None:
        v = line.split(); rec = dict(zip(hdr[1:], map(float, v[1:])))
        samples.append((t, rec))
samples = samples[1:]  # first sample is since boot
res = {}
for lab in sys.argv[3:]:
    sc = scan(lab); t0 = sc['t_start']
    wio = collections.Counter(); wtok = collections.Counter(); ref = collections.Counter(); rd = collections.Counter()
    for tt, e, d in sc['events']:
        w = int(tt // 60 // W)
        if e == 'h2s_io': wio[w] += d['ms'] / 1e3; wtok[w] += d['tokens']
        elif e == 'srs_dispatch' and d['launched'] == 0: ref[w] += 1
        elif e == 'pf_success': rd[w] += d['loaded']
    dev = collections.defaultdict(list)
    for ts, r in samples:
        mid = ts - 5 - t0  # sample covers [ts-10, ts)
        dev[int(mid // 60 // W)].append(r)
    rows = {}
    print(f'===== {lab}: window | util % | read MB/s | write MB/s | engine write I/O s/min | write K tok per I/O s | read landed M tok | refused')
    for w in range(lo // W, hi // W):
        d = dev.get(w, [])
        n = max(1, len(d))
        util = sum(x['%util'] for x in d) / n; rmb = sum(x['rkB/s'] for x in d) / n / 1024; wmb = sum(x['wkB/s'] for x in d) / n / 1024
        rows[w] = (util, rmb, wio[w] / W, ref[w], rd[w])
        print(f'  {w*W:3d}-{w*W+W:3d} | {util:5.1f} | {rmb:6.0f} | {wmb:6.0f} | {wio[w]/W:5.1f} | {wtok[w]/max(1e-9, wio[w])/1e3:5.1f} | {rd[w]/1e6:5.2f} | {ref[w]:4d}')
    res[lab] = rows
    sel = [rows[w] for w in range(30 // W, 65 // W)]
    print(f'  minutes 30-65 mean: util {mean(x[0] for x in sel):.1f} %, read {mean(x[1] for x in sel):.0f} MB/s, write I/O {mean(x[2] for x in sel):.1f} s/min, landed {sum(x[4] for x in sel)/1e6:.2f} M')
allref = [(lab, w, r) for lab, rows in res.items() for w, r in rows.items() if r[3] > 0]
print('windows with a refusal:', len(allref), '; min util', min(r[0] for _, _, r in allref) if allref else None,
      '; min write s/min', min(r[2] for _, _, r in allref) if allref else None)
sat = [(lab, w) for lab, rows in res.items() for w, r in rows.items() if r[0] >= 65 and r[3] == 0]
print('windows with util >= 65 % and no refusal:', sat)
