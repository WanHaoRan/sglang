"""SSD tokens landed (pf_success loaded) in a window split by purpose (reviewer's version), and a paired check of the
excess: requests (play, stream, k) both arms sent in the window, SSD tokens used at admission (client 'storage') in A
and B, and where B got those tokens instead. Usage: v_read_split.py lo_s hi_s A B"""
import sys, collections
sys.path.insert(0, __import__('os').path.dirname(__file__))
from vcommon import *
lo, hi, A, B = float(sys.argv[1]), float(sys.argv[2]), sys.argv[3], sys.argv[4]
def split(lab):
    sc = scan(lab); _, reqs = client(lab); rec = {r['rid']: r for r in reqs}
    arr = {}; expired = set(); abort_pin = set(); io = collections.defaultdict(float)
    for t, e, d in sc['events']:
        if e == 'ntp_arrive' and d['rid'] not in arr: arr[d['rid']] = t
        elif e == 'ntp_expire' and d['reason'] == 'timeout': expired.add(d['rid'])
        elif e == 'srs_unpin' and d['reason'] == 'abort': abort_pin.add(d['rid'])
    c = collections.Counter(); ios = collections.Counter()
    for t, e, d in sc['events']:
        if e not in ('pf_success', 's2h_io') or not (lo <= t < hi): continue
        rid = d['rid']; ta = arr.get(rid, rec[rid]['t_send'] if rid in rec else None)
        if ta is None or t < ta: g = 'staged, given back' if rid in abort_pin else 'staged, used/replaced'
        elif rid in expired: g = 'after expired plan'
        else: g = 'arrived turn'
        if e == 'pf_success': c[g] += d['loaded']
        else: ios[g] += d['ms'] / 1e3
    return c, ios, rec
ca, ia, ra = split(A); cb, ib, rb = split(B)
for lab, c, i in ((A, ca, ia), (B, cb, ib)):
    print(f'{lab}: landed {sum(c.values())/1e6:.2f} M, I/O {sum(i.values()):.0f} s; ' + ', '.join(f'{g} {v/1e6:.2f} M ({i[g]:.0f} s)' for g, v in c.most_common()))
print(f'excess {A} - {B}: {(sum(ca.values()) - sum(cb.values()))/1e6:.2f} M')
# paired: requests sent in the window in A
ka = {key(r): r for r in ra.values() if lo <= r['t_send'] < hi}
kb = {key(r): r for r in rb.values()}
both = [k for k in ka if k in kb]
sA = sum(tiers(ka[k])[2] for k in both); sB = sum(tiers(kb[k])[2] for k in both)
more = 0; more_res = 0; more_ssd = 0; more_rec = 0; n_more = 0
for k in both:
    a, b = ka[k], kb[k]
    da, db = tiers(a), tiers(b)
    x = da[2] - db[2]
    if x > 0:
        n_more += 1; more += x
        resB = db[0] + db[1]; resA = da[0] + da[1]
        # where B got the tokens A read: resident in B beyond what A had resident, else recomputed in B
        gain = min(x, max(0, resB - resA)); more_res += gain
        more_rec += max(0, x - gain)
print(f'paired requests sent in [{lo:.0f},{hi:.0f}) by {A}: {len(both)}; SSD tokens used at admission {A} {sA/1e6:.2f} M, {B} {sB/1e6:.2f} M')
print(f'  requests where {A} used more SSD tokens: {n_more}, {more/1e6:.2f} M more; of that, resident (GPU+host) in {B}: {more_res/1e6:.2f} M; not: {more_rec/1e6:.2f} M')
