"""Fate of an arm's staged reads (ntp_stage), reviewer's version. Usage: v_staged.py label [cmp arms...]
Arrival = ntp_arrive (else client t_send). Reads that landed before arrival: pf_success loaded>0 before arrival.
Pins: srs_pin before arrival and the srs_unpin that ended it."""
import sys, collections
sys.path.insert(0, __import__('os').path.dirname(__file__))
from vcommon import *
lab = sys.argv[1]; cmps = sys.argv[2:]
ev = scan(lab)['events']; _, reqs = client(lab)
rec = {r['rid']: r for r in reqs}
by = collections.defaultdict(list)
for t, e, d in ev:
    rid = d.get('rid') if isinstance(d, dict) else None
    if rid: by[rid].append((t, e, d))
staged = [rid for rid, es in by.items() if any(e == 'ntp_stage' for t, e, d in es)]
came = [r for r in staged if r in rec]
moved = 0; moved_tok = 0; io_ms = 0.0; pinned = 0; reasons = collections.Counter(); held = collections.defaultdict(list)
pin_tok = collections.Counter(); came_after_abort = 0; pin_intervals = []
for rid in staged:
    es = by[rid]
    arr = next((t for t, e, d in es if e == 'ntp_arrive'), rec[rid]['t_send'] if rid in rec else float('inf'))
    l = sum(d['loaded'] for t, e, d in es if e == 'pf_success' and t < arr)
    if l > 0: moved += 1; moved_tok += l
    io_ms += sum(d['ms'] for t, e, d in es if e == 's2h_io' and t < arr)
    pin = None
    for t, e, d in es:
        if e == 'srs_pin' and t < arr and pin is None: pin = [t, d['tokens'], None, None]
        elif e == 'srs_unpin' and pin is not None and pin[2] is None: pin[2], pin[3] = t, d['reason']
    if pin:
        pinned += 1; reasons[pin[3]] += 1; pin_tok[pin[3]] += pin[1]
        end = pin[2] if pin[2] is not None else arr
        held[pin[3]].append(min(end, arr) - pin[0])
        pin_intervals.append((pin[0], min(end, arr), pin[1]))
        if pin[3] == 'abort' and rid in rec: came_after_abort += 1
print(f'{lab}: staged {len(staged)}; came {len(came)}; moved pages before arrival {moved} ({moved_tok/1e6:.2f} M tokens); '
      f'read-thread I/O before arrival {io_ms/1e3:.0f} s; pinned before arrival {pinned}; pin ends {dict(reasons)}')
for k in reasons:
    print(f'   {k}: {reasons[k]} pins {pin_tok[k]/1e6:.2f} M tokens, held before arrival median {q(held[k], .5):.1f} s')
print(f'   abort pins whose turn came later: {came_after_abort}')
# time-weighted pinned tokens from staged pins (before arrival)
def avg_pinned(lo, hi):
    return sum(tok * max(0, min(b, hi) - max(a, lo)) for a, b, tok in pin_intervals) / (hi - lo)
print(f'   staged pins held before arrival, time average: minutes 30-110 {avg_pinned(1800, 6600)/1e3:.0f} K; ' +
      ', '.join(f'{m}-{m+10}: {avg_pinned(m*60, (m+10)*60)/1e3:.0f} K' for m in range(30, 110, 10)))
# same turns in other arms
keys = [key(rec[r]) for r in came if rec[r]['t_send'] < CUT]
def summ(arm_reqs, ks):
    bk = {key(r): r for r in arm_reqs if r['t_send'] < CUT}
    rs = [bk[k] for k in ks if k in bk]
    again = [max(0, r['ideal_cached'] - sum(tiers(r))) / r['ideal_cached'] for r in rs if r.get('ideal_cached')]
    return len(rs), mean(r['ttft'] for r in rs), mean(again)
print(f'   same turns ({len(keys)} sent before cut in {lab}): {lab} n/TTFT/recomputed share {summ(reqs, keys)}')
for c in cmps:
    _, cr = client(c)
    print(f'      {c}: {summ(cr, keys)}')
