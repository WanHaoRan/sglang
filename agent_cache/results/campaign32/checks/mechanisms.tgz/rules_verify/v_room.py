"""ec_price lines by 5-minute window: host room beyond the device mirror (room), held by in-flight and pinned reads
(held), refused tokens. Usage: v_room.py label lo_min hi_min"""
import sys, collections
sys.path.insert(0, __import__('os').path.dirname(__file__))
from vcommon import *
lab, lo, hi = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
w = collections.defaultdict(list)
for t, e, d in scan(lab)['events']:
    if e == 'ec_price' and lo * 60 <= t < hi * 60: w[int(t // 300)].append(d)
for k in sorted(w):
    v = w[k]
    print(f'{lab} {k*5:3d}-{k*5+5:3d}: room K min/med {min(x["room"] for x in v)/1e3:.0f}/{q([x["room"] for x in v],.5)/1e3:.0f}; held K med/max {q([x["held"] for x in v],.5)/1e3:.0f}/{max(x["held"] for x in v)/1e3:.0f}; refused {sum(x["refused"] for x in v)/1e6:.2f} M')
