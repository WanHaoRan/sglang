"""Per minute: SSD write demand (h2s_submit tokens), host evictions (evict_host tokens), prefill work from the client
(prompt tokens not served from cache, by send minute), history recomputed (ideal_cached - cached), refused dispatches.
Usage, from agent_cache/: v_write_demand.py lo_min hi_min label..."""
import sys, os, json, datetime as dt, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vcommon import *
lo, hi = int(sys.argv[1]), int(sys.argv[2])
for lab in sys.argv[3:]:
    run, prog = manifest()[lab]
    t0 = json.loads(open(os.path.join(AC, 'results', run, prog, 'client.jsonl')).readline())['t_start']
    sub = collections.Counter(); ev_h = collections.Counter(); ref = collections.Counter()
    with open(os.path.join(AC, 'results', run, 'server.log'), errors='replace') as f:
        for line in f:
            if 'HICACHE_EVT h2s_submit' in line or 'HICACHE_EVT evict_host' in line or ('srs_dispatch' in line and 'launched=0' in line):
                t = dt.datetime.strptime(line[1:20], '%Y-%m-%d %H:%M:%S').replace(tzinfo=dt.timezone.utc).timestamp() + int(line[21:24]) / 1000 - t0
                m = int(t // 60)
                if 'h2s_submit' in line: sub[m] += int(line.rsplit('tokens=', 1)[1].split()[0])
                elif 'evict_host' in line: ev_h[m] += int(line.split('tokens=', 1)[1].split()[0])
                else: ref[m] += 1
    _, reqs = client(lab)
    new = collections.Counter(); again = collections.Counter(); n = collections.Counter()
    for r in reqs:
        m = int((r['t_send'] + r['ttft']) // 60)
        new[m] += r['prompt_tokens'] - sum(tiers(r)); again[m] += max(0, (r.get('ideal_cached') or 0) - sum(tiers(r))); n[m] += 1
    print(f'===== {lab}: minute | SSD write submitted K tok | host evicted K tok | prefill (uncached prompt) K tok by first-token minute | of it history recomputed K | refused')
    for m in range(lo, hi):
        print(f'  {m:3d} | {sub[m]/1e3:7.0f} | {ev_h[m]/1e3:7.0f} | {new[m]/1e3:7.0f} | {again[m]/1e3:7.0f} | {ref[m]:4d}')
