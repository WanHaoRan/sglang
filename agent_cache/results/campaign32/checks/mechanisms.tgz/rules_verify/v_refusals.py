"""Refused dispatches (srs_dispatch launched=0) and cut reads (launched=1, then s2h_io with fewer pages) per arm,
by window; for the expected-cost arms the ec_price 'refused' sum in the same window. Usage: v_refusals.py lo_min hi_min"""
import sys, collections
sys.path.insert(0, __import__('os').path.dirname(__file__))
from vcommon import *
lo, hi = float(sys.argv[1]) * 60, float(sys.argv[2]) * 60
PAGE = 64
for a in ['ec_full', 'ec_exact', 'jit_p50', 'jit_exact', 'oracle_v2', 'hicache']:
    ev = scan(a)['events']
    pend = collections.defaultdict(list)  # rid -> [dispatch pages] awaiting s2h_io
    ref_n = ref_tok = cut_tok = cut_n = 0; launched = 0; first_ref = None; io_unmatched = 0
    price_ref = 0; price_lines = 0; s2h_tok_pages = 0; s2h_tok_done = 0
    for t, e, d in ev:
        if e == 'srs_dispatch':
            if d['launched'] == 0:
                if first_ref is None: first_ref = t
                if lo <= t < hi: ref_n += 1; ref_tok += d['pages'] * PAGE
            else:
                pend[d['rid']].append((t, d['pages'])); launched += 1
        elif e == 's2h_io':
            p = pend.get(d['rid'])
            if p:
                t0, pages = p.pop(0)
                if lo <= t0 < hi and d['pages'] < pages:
                    cut_n += 1; cut_tok += (pages - d['pages']) * PAGE
            else:
                io_unmatched += 1
            if lo <= t < hi: s2h_tok_pages += d['pages'] * PAGE; s2h_tok_done += d['tokens']
        elif e == 'ec_price':
            if lo <= t < hi: price_ref += d['refused']; price_lines += 1
    print(f'{a:10s} first refusal {first_ref/60 if first_ref is not None else float("nan"):6.1f} min | window: refused {ref_n:5d} disp {ref_tok/1e6:6.2f} M; '
          f'cut {cut_n:4d} reads {cut_tok/1e6:5.2f} M; sum {(ref_tok+cut_tok)/1e6:6.2f} M | ec_price refused {price_ref/1e6:6.2f} M ({price_lines} lines) | '
          f's2h_io pages*64 {s2h_tok_pages/1e6:6.2f} M, tokens {s2h_tok_done/1e6:6.2f} M | launched {launched}, s2h_io unmatched {io_unmatched}')
