"""Reviewer's check of C3/C4: srs_dispatch launched=0 over time, evict_host freed < requested over time, first times,
sustained onset (>= N a minute for M consecutive minutes), and counts in windows.
Usage: python3 -I -B refusals.py <x.json> [...]"""
import collections
import json
import sys

for path in sys.argv[1:]:
    d = json.load(open(path))
    per, glob = d["per"], d["glob"]
    ref = sorted(e["t"] for ev in per.values() for e in ev.get("srs_dispatch", []) if e.get("launched") == 0)
    disp = sorted(e["t"] for ev in per.values() for e in ev.get("srs_dispatch", []))
    eh = glob.get("evict_host", [])
    part = sorted(e["t"] for e in eh if e["tokens"] < e["requested"])
    part_before = [t for t in part if t < 6600]
    pm = collections.Counter(int(t // 60) for t in ref)
    def sustained(cnt, n=5, m=5):
        for s in range(0, 130):
            if all(cnt.get(s + i, 0) >= n for i in range(m)):
                return s
        return None
    w = lambda lo, hi: sum(1 for t in ref if lo * 60 <= t < hi * 60)
    print(f"{d['label']}: dispatches {len(disp)}, launched=0 {len(ref)} (before 6600 s {sum(1 for t in ref if t < 6600)}); "
          f"first launched=0 at {ref[0]/60 if ref else float('nan'):.2f} min; sustained (>=5/min x5) from minute {sustained(pm)}; "
          f"in minutes 30-65: {w(30,65)}; 65-76: {w(65,76)}")
    print(f"   evict_host lines {len(eh)} (before 6600 s {sum(1 for e in eh if e['t'] < 6600)}); freed < requested: {len(part)} (before 6600 s {len(part_before)}), "
          f"first at {part[0]/60 if part else float('nan'):.2f} min; in minutes 30-65: {sum(1 for t in part if 1800 <= t < 3900)}")
    b5 = collections.Counter(int(t // 300) * 5 for t in ref)
    print("   launched=0 per 5-min bin (minute:count):", " ".join(f"{k}:{v}" for k, v in sorted(b5.items()) if k < 120))
    bp = collections.Counter(int(t // 300) * 5 for t in part)
    print("   partial evict_host per 5-min bin:", " ".join(f"{k}:{v}" for k, v in sorted(bp.items()) if k < 120))
