"""Reviewer's check of C5/C6/C13/C14: per arm and window (minutes since the client's t_start): iostat read/write MB/s
(MB = 1e6 bytes, kB = 1024 bytes as iostat prints) and %util; read/write thread busy (sum of s2h_io / h2s_io ms over the
window); SSD tokens read (s2h_io pages x 64) by I/O time and per returning request sent in the window; host evictions
(evict_host tokens) per minute; d2h and h2s tokens; prefill new tokens; decode-line #queue-req mean.
Usage: python3 -I -B onset.py <iostat log> <lo_min> <hi_min> <x.json> [...]"""
import datetime as dt
import json
import re
import sys

io_path, lo, hi = sys.argv[1], float(sys.argv[2]) * 60, float(sys.argv[3]) * 60
samples = []
STAMP = re.compile(r"^(\d\d)/(\d\d)/(\d{4}) (\d\d):(\d\d):(\d\d) (AM|PM)")
cur = None
first = True
with open(io_path) as f:
    for line in f:
        m = STAMP.match(line)
        if m:
            h = int(m[4]) % 12 + (12 if m[7] == "PM" else 0)
            cur = dt.datetime(int(m[3]), int(m[1]), int(m[2]), h, int(m[5]), int(m[6]), tzinfo=dt.timezone.utc).timestamp()
            continue
        if line.startswith("vdc") and cur is not None:
            p = line.split()
            if first:   # since-boot average
                first = False
                continue
            samples.append((cur, float(p[2]), float(p[8]), float(p[-1])))   # rkB/s, wkB/s, %util


def mean(x):
    return sum(x) / len(x) if x else float("nan")


for path in sys.argv[4:]:
    d = json.load(open(path))
    t0, per, glob = d["t0"], d["per"], d["glob"]
    # iostat sample at clock c covers (c-10, c]
    s = [x for x in samples if lo <= x[0] - t0 - 5 < hi]
    rd = mean([x[1] * 1024 / 1e6 for x in s]); wr = mean([x[2] * 1024 / 1e6 for x in s]); ut = mean([x[3] for x in s])
    span = hi - lo
    s2h = [(e["t"], e["pages"], e["ms"]) for ev in per.values() for e in ev.get("s2h_io", [])]
    read_busy = sum(ms for t, p, ms in s2h if lo <= t < hi) / 1000 / span
    read_tok = sum(p * 64 for t, p, ms in s2h if lo <= t < hi)
    h2s = [(e["t"], e["pages"], e["ms"]) for e in glob.get("h2s_io", [])]
    write_busy = sum(ms for t, p, ms in h2s if lo <= t < hi) / 1000 / span
    h2s_tok = sum(p * 64 for t, p, ms in h2s if lo <= t < hi)
    ev_host = sum(e["tokens"] for e in glob.get("evict_host", []) if lo <= e["t"] < hi)
    d2h_tok = sum(e["tokens"] for e in glob.get("d2h_submit", []) if lo <= e["t"] < hi)
    pre = sum(x[2] for x in glob.get("prefill", []) if lo <= x[0] < hi)
    dq = mean([x[4] for x in glob.get("decode", []) if lo <= x[0] < hi])
    back = [c for c in d["clients"] if (c["k"] or 0) > 0 and (c["ideal"] or 0) > 0 and c["ttft"] is not None and lo <= c["t_send"] < hi]
    bset = {c["rid"] for c in back}
    read_for = sum(64 * e["pages"] for rid in bset for e in per.get(rid, {}).get("s2h_io", []))
    print(f"{d['label']:9s} min {lo/60:.0f}-{hi/60:.0f}: iostat read {rd:6.0f} MB/s write {wr:5.0f} MB/s util {ut:5.1f} % ({len(s)} samples); "
          f"read thread busy {100*read_busy:5.1f} %, write thread busy {100*write_busy:5.1f} %; s2h tokens {read_tok/1e6:6.2f} M "
          f"({read_tok*98304/span/1e6:5.0f} MB/s); SSD tokens read for returning requests sent here {read_for/max(1,len(back)):5.0f}/req ({len(back)} req); "
          f"host evictions {ev_host/(span/60)/1e3:6.0f} K/min; d2h {d2h_tok/1e6:5.2f} M, h2s {h2s_tok/1e6:5.2f} M, prefill new {pre/1e6:5.2f} M; decode queue mean {dq:5.1f}")
