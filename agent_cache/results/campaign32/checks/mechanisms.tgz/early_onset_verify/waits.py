"""Reviewer's check of C12: srs_dispatch waited_ms (parked before dispatch) for refused (launched=0) vs launched
dispatches in a window; how many refused were dispatched at once (waited 0) and were re-reads (not the rid's first
dispatch); read thread busy and tokens/s per 10-minute bin. Usage: python3 -I -B waits.py <x.json> <lo_min> <hi_min>"""
import json, sys, collections
d = json.load(open(sys.argv[1])); lo, hi = float(sys.argv[2]) * 60, float(sys.argv[3]) * 60
ref, lau = [], []; at_once_re = 0; re_n = 0
for rid, ev in d["per"].items():
    ds = sorted(ev.get("srs_dispatch", []), key=lambda e: e["t"])
    for i, e in enumerate(ds):
        if not (lo <= e["t"] < hi): continue
        if e.get("launched") == 0:
            ref.append(e["waited_ms"] / 1000)
            if i > 0:
                re_n += 1
                at_once_re += e["waited_ms"] == 0
        else:
            lau.append(e["waited_ms"] / 1000)
p50 = lambda x: sorted(x)[len(x) // 2] if x else float("nan")
print(f"{d['label']} minutes {lo/60:.0f}-{hi/60:.0f}: refused {len(ref)} waited p50 {p50(ref):.1f} s (at once {sum(1 for w in ref if w == 0)}; "
      f"re-reads {re_n}, of them at once {at_once_re}); launched {len(lau)} waited p50 {p50(lau):.1f} s")
io = [(e["t"], e["pages"], e["ms"]) for ev in d["per"].values() for e in ev.get("s2h_io", [])]
b = collections.defaultdict(lambda: [0, 0])
for t, p, ms in io:
    b[int(t // 600)][0] += ms; b[int(t // 600)][1] += p * 64
print("   read thread busy % / K tokens per busy s, 10-min bins since t_start: " + " ".join(
    f"{k*10}:{v[0]/6000:.0f}%/{v[1]/max(1,v[0]):.1f}" for k, v in sorted(b.items()) if 2 <= k < 11))
