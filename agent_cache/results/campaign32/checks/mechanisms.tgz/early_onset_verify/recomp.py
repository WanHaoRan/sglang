"""Reviewer's check of C1/C2: history computed again per returning request, by send-time window, split by the
read path (own classification, several priorities) and by the request's plan state.
Usage: python3 -I -B recomp.py <lo_min> <hi_min> <x.json> [...]"""
import collections
import json
import sys

lo, hi = float(sys.argv[1]) * 60, float(sys.argv[2]) * 60


def cached(c):
    if c["has_det"]:
        return sum(int(c[k] or 0) for k in ("dev", "host", "ssd"))
    return int(c["cached_tokens"] or 0)


def again(c):
    return max(0, (c["ideal"] or 0) - cached(c))


def facts(ev):
    disp = ev.get("srs_dispatch", [])
    refused = [e for e in disp if e.get("launched") == 0]
    launched = [e for e in disp if e.get("launched") == 1]
    gate = ev.get("ntp_gate", [])
    capped_gate = [e for e in gate if e.get("decision") == "capped"]
    capped_re = [e for e in ev.get("ntp_reevict", []) if e.get("capped") == 1]
    ps = [e for e in ev.get("ps", []) if e["kind"] == "success" and e["loaded"] > 0]
    q = ev.get("s2h_query", [])
    empty_q = [e for e in q if e.get("storage_hit", 0) == 0]
    stage = ev.get("ntp_stage", [])
    arr = ev.get("ntp_arrive", [])
    arr_t = arr[0]["t"] if arr else None
    exp = [e for e in ev.get("ntp_expire", []) if e.get("reason") == "timeout" and (arr_t is None or e["t"] <= arr_t)]
    return dict(refused=bool(refused), refused_t=refused[0]["t"] if refused else None,
                later_launch=bool(refused) and any(e["t"] > refused[-1]["t"] for e in launched),
                capped=bool(capped_gate or capped_re), capped_gate=bool(capped_gate), landed=bool(ps), nq=len(q),
                n_empty=len(empty_q), short=bool(q) and q[-1]["storage_hit"] < q[-1]["tokens_req"] - 256,
                staged=bool(stage) and (arr_t is None or stage[0]["t"] < arr_t), expired=bool(exp), arr_t=arr_t)


for path in sys.argv[3:]:
    d = json.load(open(path))
    per = d["per"]
    rs = [c for c in d["clients"] if (c["k"] or 0) > 0 and (c["ideal"] or 0) > 0 and c["ttft"] is not None and lo <= c["t_send"] < hi]
    rs_fig = [c for c in d["clients"] if (c["k"] or 0) > 0 and c["phase"] != "warmup" and c["ttft"] is not None and not c["err"] and lo <= c["t_send"] < hi]
    tot = sum(again(c) for c in rs)
    n = len(rs)
    print(f"== {d['label']}: minutes {lo/60:.0f}-{hi/60:.0f}: {n} returning (ideal>0), {tot/1e6:.2f} M again, {tot/max(1,n):.0f}/req; "
          f"figure definition {len(rs_fig)} req, {sum(again(c) for c in rs_fig)/max(1,len(rs_fig)):.0f}/req")
    # priority A (analyst's): refused > capped > lost_landed > ssd_short > no_lookup > other
    cat = collections.Counter(); cat_n = collections.Counter()
    # priority B: capped first
    catB = collections.Counter()
    cross = collections.Counter()
    state = collections.Counter(); state_n = collections.Counter()
    for c in rs:
        a = again(c)
        ev = per.get(c["rid"], {})
        f = facts(ev)
        st = "expired" if f["expired"] else ("staged" if f["staged"] else "neither")
        state[st] += a; state_n[st] += 1
        if a <= 0:
            continue
        lost = f["landed"] and any(e["t"] >= min(x["t"] for x in ev.get("ps", [])) for e in ev.get("ntp_reevict", []))
        if f["refused"]:
            k = "refused"
        elif f["capped"]:
            k = "capped_empty" if f["n_empty"] > 0 else "capped_other"
        elif lost:
            k = "lost_landed"
        elif f["short"]:
            k = "ssd_short"
        elif f["nq"] == 0:
            k = "no_lookup"
        else:
            k = "other"
        cat[k] += a; cat_n[k] += 1
        if f["capped"]:
            kb = "capped_empty" if f["n_empty"] > 0 else ("capped_after_refusal" if f["refused"] else "capped_other")
        elif f["refused"]:
            kb = "refused_not_capped"
        else:
            kb = k
        catB[kb] += a
        cross[(f["refused"], f["capped"], f["later_launch"])] += a
    print("  priority A (refused first):", "; ".join(f"{k} {cat_n[k]} req {v/max(1,n):.0f}/req" for k, v in sorted(cat.items(), key=lambda x: -x[1])))
    print("  priority B (capped first):", "; ".join(f"{k} {v/max(1,n):.0f}/req" for k, v in sorted(catB.items(), key=lambda x: -x[1])))
    print("  (refused, capped, launched after refusal) -> tokens/req:", "; ".join(f"{k}: {v/max(1,n):.0f}" for k, v in sorted(cross.items(), key=lambda x: -x[1])))
    print("  state split:", "; ".join(f"{k} {state_n[k]} req {v/max(1,n):.0f}/req" for k, v in state.items()))
