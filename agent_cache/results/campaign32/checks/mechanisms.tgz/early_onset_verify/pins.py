"""Reviewer's check of C8/C9: time-weighted pinned tokens (srs_pin/srs_unpin running total 'pinned='), split into
pins of requests whose read was staged before arrival (ntp_stage before ntp_arrive) and the rest; pin hold times
(pin to unpin, per rid in order), unpin reasons; plus in-flight read tokens (dispatched with launched=1 until s2h_io)
and srs_pin_skipped counts. Usage: python3 -I -B pins.py <lo_min> <hi_min> <x.json> [...]"""
import collections
import json
import sys

lo, hi = float(sys.argv[1]) * 60, float(sys.argv[2]) * 60


def tw(series, lo, hi):
    """time-weighted mean of a step series [(t, value)] (value holds from t on) over [lo, hi)."""
    series = sorted(series)
    acc, cur, last = 0.0, 0.0, lo
    for t, v in series:
        if t < lo:
            cur = v
            continue
        if t >= hi:
            break
        acc += cur * (t - last)
        cur, last = v, t
    acc += cur * (hi - last)
    return acc / (hi - lo)


for path in sys.argv[3:]:
    d = json.load(open(path))
    per = d["per"]
    tot_series = []
    early_delta = []   # (t, +/- tokens) for early pins
    other_delta = []
    holds_e, holds_o = [], []
    reasons_e, reasons_o = collections.Counter(), collections.Counter()
    n_e = n_o = 0
    tok_e = []
    skipped = 0
    for rid, ev in per.items():
        arr = ev.get("ntp_arrive", [])
        arr_t = arr[0]["t"] if arr else None
        stage = ev.get("ntp_stage", [])
        early = bool(stage) and (arr_t is None or stage[0]["t"] < arr_t)
        pins = sorted(ev.get("srs_pin", []), key=lambda e: e["t"])
        unp = sorted(ev.get("srs_unpin", []), key=lambda e: e["t"])
        skipped += len(ev.get("srs_pin_skipped", []))
        for e in pins + unp:
            tot_series.append((e["t"], e["pinned"]))
        # pair pins and unpins in order (a pin is released before the next pin of the same rid: 'replaced')
        j = 0
        for p in pins:
            while j < len(unp) and unp[j]["t"] < p["t"]:
                j += 1
            u = unp[j] if j < len(unp) else None
            j += 1
            end = u["t"] if u else 1e9
            tgt = early_delta if early else other_delta
            tgt.append((p["t"], p["tokens"]))
            tgt.append((end, -p["tokens"]))
            if lo <= p["t"] < hi:
                if early:
                    n_e += 1; tok_e.append(p["tokens"])
                    holds_e.append(end - p["t"]); reasons_e[u["reason"] if u else "none"] += 1
                else:
                    n_o += 1
                    holds_o.append(end - p["t"]); reasons_o[u["reason"] if u else "none"] += 1
    def cum(deltas):
        deltas.sort()
        s, out = 0, []
        for t, dv in deltas:
            s += dv
            out.append((t, s))
        return out
    ce, co = cum(early_delta), cum(other_delta)
    hold = lambda h: (sum(h) / len(h) if h else float("nan"), sorted(h)[int(0.9 * len(h))] if h else float("nan"))
    he, ho = hold(holds_e), hold(holds_o)
    print(f"{d['label']} minutes {lo/60:.0f}-{hi/60:.0f}: pinned tokens time-weighted (running total) {tw(tot_series, lo, hi)/1e3:.1f} K; "
          f"early-read pins {tw(ce, lo, hi)/1e3:.1f} K, other pins {tw(co, lo, hi)/1e3:.1f} K")
    print(f"   early-read pins made in window {n_e} (mean {sum(tok_e)/max(1,len(tok_e))/1e3:.1f} K tokens), held mean {he[0]:.1f} s p90 {he[1]:.1f} s, "
          f"released {dict(reasons_e)}; other pins {n_o}, held mean {ho[0]:.1f} s p90 {ho[1]:.1f}, released {dict(reasons_o)}; srs_pin_skipped (whole run) {skipped}")
