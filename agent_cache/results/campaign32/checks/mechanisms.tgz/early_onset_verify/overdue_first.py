"""Reviewer's test of C10's ordering claim: for returning requests whose plan expired before arrival, was the previous
turn's registration already overdue (due + 60 s) before the expiry? Then the overdue tier ranked the session first.
Usage: python3 -I -B overdue_first.py <x.json> [...]"""
import json, sys
def prev_rid(rid):
    head, _, k = rid.rpartition("-t")
    return f"{head}-t{int(k) - 1}"
for path in sys.argv[1:]:
    d = json.load(open(path)); per = d["per"]
    n = first = 0; lead = []; plan_gap = []
    for c in d["clients"]:
        if not ((c["k"] or 0) > 0 and (c["ideal"] or 0) > 0 and c["ttft"] is not None and c["t_send"] < 6600):
            continue
        ev = per.get(c["rid"], {})
        arr = ev.get("ntp_arrive", []); arr_t = arr[0]["t"] if arr else c["t_send"]
        ex = [e for e in ev.get("ntp_expire", []) if e.get("reason") == "timeout" and e["t"] <= arr_t + 1e-3]
        if not ex: continue
        regs = [e for e in per.get(prev_rid(c["rid"]), {}).get("nue_register", []) if isinstance(e.get("next_use_ms"), int) and e["next_use_ms"] != 0]
        if not regs: continue
        n += 1
        due = regs[-1]["t"] + regs[-1]["next_use_ms"] / 1000
        pl = ev.get("ntp_plan", [])
        if pl: plan_gap.append(pl[0]["gap_ms"] / 1000)
        if due + 60 < ex[0]["t"]:
            first += 1; lead.append(ex[0]["t"] - (due + 60))
    lead.sort(); plan_gap.sort()
    print(f"{d['label']}: expired with a registration {n}; overdue before expiry {first}; overdue time before expiry p50 "
          f"{lead[len(lead)//2] if lead else float('nan'):.0f} s, sum {sum(lead):.0f} s; plan gap (p50 hint) p50 {plan_gap[len(plan_gap)//2] if plan_gap else float('nan'):.0f} s, >60 s {sum(1 for g in plan_gap if g > 60)}")
