"""Reviewer's check of C8: fate of requests with a read staged before arrival (ntp_stage before ntp_arrive),
sent before 6600 s. Fates (first match): expired (ntp_expire timeout staged=1 before arrival), reread (an unpin
'replaced' or an ntp_reevict after the first landing, or a second s2h_io), used (cached_details.storage > 0),
not_used. Also an alternative 'reread' = more than one s2h_io for the rid. Usage: python3 -I -B early.py <x.json> [...]"""
import collections, json, sys
def again(c):
    cached = sum(int(c[k] or 0) for k in ("dev", "host", "ssd")) if c["has_det"] else int(c["cached_tokens"] or 0)
    return max(0, (c["ideal"] or 0) - cached)
for path in sys.argv[1:]:
    d = json.load(open(path)); per = d["per"]
    cli = {c["rid"]: c for c in d["clients"]}
    n = collections.Counter(); rd = collections.Counter(); ag = collections.Counter(); hold = collections.defaultdict(list)
    multi_io = 0; total = 0
    for rid, ev in per.items():
        st = ev.get("ntp_stage")
        c = cli.get(rid)
        if not st or c is None or c["t_send"] is None or c["t_send"] >= 6600 or c["ttft"] is None:
            continue
        arr = ev.get("ntp_arrive", []); arr_t = arr[0]["t"] if arr else c["t_send"]
        if st[0]["t"] >= arr_t:
            continue
        total += 1
        landed = sorted(e["t"] for e in ev.get("ps", []) if e["kind"] == "success" and e["loaded"] > 0)
        ios = ev.get("s2h_io", [])
        multi_io += len(ios) > 1
        if any(e.get("reason") == "timeout" and e.get("staged") == 1 and e["t"] <= arr_t + 1e-3 for e in ev.get("ntp_expire", [])):
            k = "expired"
        elif any(e.get("reason") == "replaced" for e in ev.get("srs_unpin", [])) or (landed and any(e["t"] >= landed[0] for e in ev.get("ntp_reevict", []))):
            k = "reread"
        elif int(c["ssd"] or 0) > 0:
            k = "used"
        else:
            k = "not_used"
        n[k] += 1; rd[k] += sum(64 * e["pages"] for e in ios); ag[k] += again(c)
        pins = sorted(ev.get("srs_pin", []), key=lambda e: e["t"]); unp = sorted(ev.get("srs_unpin", []), key=lambda e: e["t"])
        if pins:
            u = [x for x in unp if x["t"] >= pins[0]["t"]]
            if u: hold[k].append(u[0]["t"] - pins[0]["t"])
    print(f"{d['label']}: {total} requests with an early read; with more than one s2h_io {multi_io}")
    for k in ("used", "reread", "expired", "not_used"):
        h = hold[k]
        print(f"   {k:8s} {n[k]:5d} ({100*n[k]/max(1,total):4.1f} %) read {rd[k]/1e6:6.2f} M, computed again {ag[k]/1e6:5.2f} M, first pin held mean {sum(h)/max(1,len(h)):.1f} s")
