"""List HICACHE_EVT event names with counts and one sample line each, plus other common line kinds.
Usage: python3 -I -B vocab.py <server.log>"""
import collections, re, sys
EVT = re.compile(r"HICACHE_EVT (\S+)")
cnt = collections.Counter(); sample = {}
other = collections.Counter(); osample = {}
with open(sys.argv[1], errors="replace") as f:
    for line in f:
        m = EVT.search(line)
        if m:
            cnt[m[1]] += 1
            if m[1] not in sample:
                sample[m[1]] = line.strip()[:400]
        else:
            body = line[26:].strip()
            key = re.sub(r"\d+", "N", body)[:60]
            other[key] += 1
            if key not in osample:
                osample[key] = line.strip()[:300]
for k, v in cnt.most_common():
    print(f"{v:8d} {k}\n         {sample[k]}")
print("---- other lines (top 60)")
for k, v in other.most_common(60):
    print(f"{v:8d} {osample[k]}")
