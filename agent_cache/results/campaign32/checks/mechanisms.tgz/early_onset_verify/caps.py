"""Reviewer's check of C11: requests the gate refused at the cap (ntp_gate decision=capped) and requests with a cap
mark (ntp_reevict capped=1), split by what preceded the first cap event: a room refusal (srs_dispatch launched=0),
a landed read (prefetch success loaded>0), a lookup that found pages, or only lookups that found nothing. Also, for
cap-after-refusal requests, how many of their lookups before the cap found nothing (the mixed case).
Returning requests (k>0, ideal>0, ttft) sent in [lo, hi) min and before 6600 s.
Usage: python3 -I -B caps.py <lo_min> <hi_min> <x.json> [...]"""
import collections
import json
import sys

lo, hi = float(sys.argv[1]) * 60, min(float(sys.argv[2]) * 60, 6600.0)


def again(c):
    cached = sum(int(c[k] or 0) for k in ("dev", "host", "ssd")) if c["has_det"] else int(c["cached_tokens"] or 0)
    return max(0, (c["ideal"] or 0) - cached)


for path in sys.argv[3:]:
    d = json.load(open(path))
    n, tok = collections.Counter(), collections.Counter()
    mixed = collections.Counter()
    for c in d["clients"]:
        if not ((c["k"] or 0) > 0 and (c["ideal"] or 0) > 0 and c["ttft"] is not None and lo <= c["t_send"] < hi):
            continue
        ev = d["per"].get(c["rid"], {})
        g = [e["t"] for e in ev.get("ntp_gate", []) if e.get("decision") == "capped"]
        m = [e["t"] for e in ev.get("ntp_reevict", []) if e.get("capped") == 1]
        if not g and not m:
            continue
        t = min(g + m) + 1e-3
        refused = [e for e in ev.get("srs_dispatch", []) if e.get("launched") == 0 and e["t"] <= t]
        landed = [e for e in ev.get("ps", []) if e["kind"] == "success" and e["loaded"] > 0 and e["t"] <= t]
        qs = [e for e in ev.get("s2h_query", []) if e["t"] <= t]
        found = [e for e in qs if e["storage_hit"] > 0]
        kind = "refused" if refused else "landed" if landed else "found" if found else "empty"
        key = ("gate" if g else "mark") + ":" + kind
        n[key] += 1
        tok[key] += again(c)
        if kind == "refused":
            mixed[(len(qs) - len(found), len(refused))] += 1
    print(f"{d['label']} minutes {lo/60:.0f}-{hi/60:.0f}: " + "; ".join(f"{k} {n[k]} ({tok[k]/1e6:.2f} M)" for k in sorted(n)))
    print(f"   gate refusals at the cap {sum(v for k, v in n.items() if k.startswith('gate'))}; "
          f"cap-after-refusal requests by (empty lookups before the cap, refused dispatches): {dict(sorted(mixed.items()))}")
