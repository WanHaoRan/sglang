"""Reviewer's test of C4's 'early reads holding most of the logged room': at time T (minutes), split the logged locks:
pinned spans (srs_pin not yet unpinned) and reads in flight (srs_dispatch launched=1 not yet followed by the rid's
s2h_io) into early (the rid not arrived yet at T, i.e. a read staged before arrival) and queued/arrived requests.
Usage: python3 -I -B locks_at.py <x.json> <T_min> [...]"""
import json, sys
args = sys.argv[1:]
d = json.load(open(args[0]))
for Tm in args[1:]:
    T = float(Tm) * 60
    pin_e = pin_q = fl_e = fl_q = 0; npe = npq = nfe = nfq = 0
    for rid, ev in d["per"].items():
        arr = ev.get("ntp_arrive", []); arr_t = arr[0]["t"] if arr else None
        rts = ev.get("rts", [])
        if arr_t is None and rts: arr_t = rts[0]["entry"]
        early = arr_t is None or arr_t > T
        pins = sorted(ev.get("srs_pin", []), key=lambda e: e["t"]); unp = sorted(ev.get("srs_unpin", []), key=lambda e: e["t"])
        # pinned at T: last pin before T without an unpin between it and T
        for p in pins:
            if p["t"] > T: break
            if not any(p["t"] <= u["t"] <= T for u in unp):
                if early: pin_e += p["tokens"]; npe += 1
                else: pin_q += p["tokens"]; npq += 1
        ds = [e for e in ev.get("srs_dispatch", []) if e.get("launched") == 1 and e["t"] <= T]
        ios = ev.get("s2h_io", [])
        for e in ds:
            if not any(e["t"] <= io["t"] <= T for io in ios):
                if early: fl_e += 64 * e["pages"]; nfe += 1
                else: fl_q += 64 * e["pages"]; nfq += 1
    print(f"{d['label']} at {float(Tm):.2f} min: pinned early {pin_e/1e3:.0f} K ({npe}), pinned arrived {pin_q/1e3:.0f} K ({npq}); "
          f"in flight early {fl_e/1e3:.0f} K ({nfe}), in flight arrived {fl_q/1e3:.0f} K ({nfq})")
