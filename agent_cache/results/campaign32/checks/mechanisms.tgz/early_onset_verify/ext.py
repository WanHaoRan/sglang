"""Independent extractor (reviewer's own code). One arm's server.log + client.jsonl -> compact JSON.
Usage, from agent_cache/:  nice -n 15 python3 -I -B ext.py <campaign dir> <label> <out.json>
Times: seconds since the client's t_start. Stdlib only."""
import calendar
import collections
import json
import re
import sys

cdir, label, out = sys.argv[1], sys.argv[2], sys.argv[3]
man = {}
for line in open(f"{cdir}/manifest.txt"):
    p = line.split()
    if p:
        man[p[0]] = (p[1], p[2])
run, prog = man[label]
cl_path = f"results/{run}/{prog}/client.jsonl"
with open(cl_path) as f:
    first = json.loads(f.readline())
T0 = first["t_start"]

clients = []
with open(cl_path) as f:
    for line in f:
        r = json.loads(line)
        if r.get("kind") != "req":
            continue
        det = r.get("cached_details") or {}
        clients.append(dict(rid=r["rid"], inst=r.get("inst"), k=r.get("k"), tree=r.get("tree"), stream=r.get("stream"),
                            phase=r.get("phase"), t_send=r.get("t_send"), ttft=r.get("ttft"), err=bool(r.get("error")),
                            ideal=r.get("ideal_cached"), prompt=r.get("prompt_tokens"), sent=r.get("prompt_sent"),
                            cached_tokens=r.get("cached_tokens"),
                            dev=det.get("device"), host=det.get("host"), ssd=det.get("storage"), has_det=bool(det),
                            wait_s=r.get("wait_s"), gap=r.get("gap"),
                            hint=r.get("hint")))

STAMP = re.compile(r"^\[(\d{4})-(\d\d)-(\d\d) (\d\d):(\d\d):(\d\d)\.(\d{3})\]")
_days = {}


def ts(line):
    m = STAMP.match(line)
    if not m:
        return None
    k = (m[1], m[2], m[3])
    b = _days.get(k)
    if b is None:
        b = calendar.timegm((int(m[1]), int(m[2]), int(m[3]), 0, 0, 0))
        _days[k] = b
    return round(b + int(m[4]) * 3600 + int(m[5]) * 60 + int(m[6]) + int(m[7]) / 1000.0 - T0, 3)


KV = re.compile(r"(\w+)=(\S+)")


def val(v):
    try:
        return int(v)
    except ValueError:
        try:
            return float(v)
        except ValueError:
            return v


per = collections.defaultdict(lambda: collections.defaultdict(list))
glob = collections.defaultdict(list)
cnt = collections.Counter()
PREF = re.compile(r"Prefill batch, #new-seq: (\d+), #new-token: (\d+), #cached-token: (\d+), token usage: ([\d.]+), #running-req: (\d+), #queue-req: (\d+)")
DEC = re.compile(r"Decode batch, #running-req: (\d+), #token: (\d+), token usage: ([\d.]+).*#queue-req: (\d+)")
RTS = re.compile(r"ReqTimeStats\(rid=(\S+?), input_len=(\d+), cached_input_len=(\d+), output_len=(\d+).*?queue_duration=([\d.]+)(ms|s), forward_duration=([\d.]+)(ms|s), entry_time=([\d.]+)")
PS = re.compile(r"HiCache prefetch (success|dropped) req=(\S+) completed=(\d+) matched=(\d+) loaded=(\d+) occupied=(\d+)")
GLOBAL_EVT = {"evict_host", "evict_device", "h2s_submit", "h2s_io", "h2s_done", "d2h_submit", "d2h_done", "h2d_submit", "srs_rate", "ec_price"}
with open(f"results/{run}/server.log", errors="replace") as f:
    for line in f:
        i = line.find("HICACHE_EVT ")
        if i >= 0:
            rest = line[i + 12:].split(" ", 1)
            name = rest[0].strip()
            fields = {k: val(v) for k, v in KV.findall(rest[1] if len(rest) > 1 else "")}
            t = ts(line)
            fields["t"] = t
            cnt[name] += 1
            rid = fields.get("rid")
            if name in GLOBAL_EVT or rid is None or rid == "io":
                glob[name].append(fields)
            else:
                del fields["rid"]
                per[rid][name].append(fields)
            continue
        if "Decode batch" in line:
            m = DEC.search(line)
            if m:
                glob["decode"].append((ts(line), int(m[1]), int(m[2]), float(m[3]), int(m[4])))
            continue
        if "Prefill batch" in line:
            m = PREF.search(line)
            if m:
                glob["prefill"].append((ts(line), int(m[1]), int(m[2]), int(m[3]), float(m[4]), int(m[5]), int(m[6])))
            continue
        if "ReqTimeStats" in line:
            m = RTS.search(line)
            if m:
                q = float(m[5]) / (1000.0 if m[6] == "ms" else 1.0)
                fw = float(m[7]) / (1000.0 if m[8] == "ms" else 1.0)
                per[m[1]]["rts"].append(dict(t=ts(line), input_len=int(m[2]), cached=int(m[3]), out=int(m[4]), queue=q, fwd=fw,
                                             entry=round(float(m[9]) - T0, 3)))
            continue
        if "HiCache prefetch " in line:
            m = PS.search(line)
            if m:
                per[m[2]]["ps"].append(dict(t=ts(line), kind=m[1], completed=int(m[3]), matched=int(m[4]), loaded=int(m[5]), occ=int(m[6])))
            continue
        if "NIXL L3 cleanup" in line:
            glob["cleanup"].append(dict(t=ts(line), text=line.strip()[26:240]))
            continue
        if "Traceback" in line or "Error" in line[:200] and "ERROR" in line[:60]:
            glob["errors"].append(dict(t=ts(line), text=line.strip()[:200]))
json.dump(dict(label=label, run=run, prog=prog, t0=T0, clients=clients, per=per, glob=glob, counts=cnt), open(out, "w"))
print(label, run, len(clients), "client reqs;", len(per), "rids;", dict(cnt.most_common(40)))
