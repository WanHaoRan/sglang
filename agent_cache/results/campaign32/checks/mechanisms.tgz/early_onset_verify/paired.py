"""Reviewer's check of C7 (and an alternative for jit_p50): SSD tokens read (s2h_io pages x 64) per request, paired by
(stream instance, index) with the same tree, for returning requests both arms sent with A's send time in [lo, hi) min.
Split by A's state before arrival: expired (ntp_expire timeout before ntp_arrive), staged (ntp_stage before arrival),
neither. For 'neither', also the previous turn's registered next_use (nue_register next_use_ms at commit) in A: ended,
far (> 300 s horizon: TIER_FAR, evicted before LRU), soon; and the true wait (client wait_s).
Usage: python3 -I -B paired.py <A.json> <B.json> <lo_min> <hi_min>"""
import collections
import json
import sys

A, B = json.load(open(sys.argv[1])), json.load(open(sys.argv[2]))
lo, hi = float(sys.argv[3]) * 60, float(sys.argv[4]) * 60


def index(d):
    return {(c["inst"], c["k"]): c for c in d["clients"] if (c["k"] or 0) > 0 and (c["ideal"] or 0) > 0 and c["ttft"] is not None}


def readtok(d, rid):
    return sum(64 * e["pages"] for e in d["per"].get(rid, {}).get("s2h_io", []))


def prev_rid(rid):
    head, _, k = rid.rpartition("-t")
    return f"{head}-t{int(k) - 1}"


def state(d, rid):
    ev = d["per"].get(rid, {})
    arr = ev.get("ntp_arrive", [])
    arr_t = arr[0]["t"] if arr else None
    if any(e.get("reason") == "timeout" and (arr_t is None or e["t"] <= arr_t) for e in ev.get("ntp_expire", [])):
        return "expired"
    st = ev.get("ntp_stage", [])
    if st and (arr_t is None or st[0]["t"] < arr_t):
        return "staged"
    return "neither"


def reg(d, rid):
    """the previous turn's registration at commit: next_use_ms (int) or 'ended' or None"""
    regs = d["per"].get(prev_rid(rid), {}).get("nue_register", [])
    regs = [e for e in regs if e.get("next_use_ms") != 0]
    return regs[-1]["next_use_ms"] if regs else None


ia, ib = index(A), index(B)
pairs = [(ia[k], ib[k]) for k in ia if k in ib and ia[k]["tree"] == ib[k]["tree"] and lo <= ia[k]["t_send"] < hi]
tot_a = sum(readtok(A, a["rid"]) for a, b in pairs)
tot_b = sum(readtok(B, b["rid"]) for a, b in pairs)
print(f"{A['label']} vs {B['label']}, minutes {lo/60:.0f}-{hi/60:.0f} by {A['label']} send time: {len(pairs)} pairs; SSD tokens read "
      f"{tot_a/1e6:.2f} M vs {tot_b/1e6:.2f} M (+{(tot_a-tot_b)/1e6:.2f} M)")
grp = collections.defaultdict(list)
for a, b in pairs:
    grp[state(A, a["rid"])].append((a, b))
for s, ps in grp.items():
    ra = sum(readtok(A, a["rid"]) for a, b in ps); rb = sum(readtok(B, b["rid"]) for a, b in ps)
    na = sum(1 for a, b in ps if readtok(A, a["rid"]) > 0); nb = sum(1 for a, b in ps if readtok(B, b["rid"]) > 0)
    waits = sorted(a["wait_s"] or 0 for a, b in ps)
    print(f"  {s:8s} {len(ps):5d} pairs, median wait {waits[len(waits)//2]:.1f} s: read {ra/1e6:6.2f} vs {rb/1e6:6.2f} M (+{(ra-rb)/1e6:5.2f} M, "
          f"{100*(ra-rb)/max(1,tot_a-tot_b):.0f} % of the extra); requests reading {na} vs {nb}")
    if s == "neither":
        # registration class of the previous turn in A, for the requests that read in A but not in B
        cls = collections.Counter(); tok = collections.Counter(); w = collections.defaultdict(list)
        for a, b in ps:
            ta, tb = readtok(A, a["rid"]), readtok(B, b["rid"])
            if ta <= tb:
                continue
            r = reg(A, a["rid"])
            if r is None:
                c = "none"
            elif r == "ended":
                c = "ended"
            elif r > 300000:
                c = "far>300s"
            else:
                c = "soon<=300s"
            cls[c] += 1; tok[c] += ta - tb; w[c].append(a["wait_s"] or 0)
        print("     neither, A reads more than B, by A's previous-turn registration: " + "; ".join(
            f"{c} {cls[c]} req +{tok[c]/1e6:.2f} M (true wait median {sorted(w[c])[len(w[c])//2]:.1f} s)" for c in cls))
