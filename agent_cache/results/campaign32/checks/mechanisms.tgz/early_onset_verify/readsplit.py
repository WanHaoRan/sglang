"""Reviewer's split of SSD read volume (s2h_io pages x 64, by I/O time) per 2-minute bin into reads that landed before
their request arrived (early) and reads after arrival; plus the pin series. Usage: python3 -I -B readsplit.py <lo> <hi> <x.json> [...]"""
import collections, json, sys
lo, hi = int(sys.argv[1]), int(sys.argv[2])
for path in sys.argv[3:]:
    d = json.load(open(path))
    cli = {c["rid"]: c for c in d["clients"]}
    e_, a_ = collections.Counter(), collections.Counter()
    for rid, ev in d["per"].items():
        arr = ev.get("ntp_arrive", []); at = arr[0]["t"] if arr else (ev["rts"][0]["entry"] if ev.get("rts") else (cli[rid]["t_send"] if rid in cli and cli[rid]["t_send"] is not None else 1e9))
        for io in ev.get("s2h_io", []):
            b = int(io["t"] // 120) * 2
            (e_ if io["t"] < at else a_)[b] += 64 * io["pages"]
    print(f"{d['label']}: 2-min bin: SSD read MiB/s early / after arrival")
    print("   " + " | ".join(f"{b}: {e_[b]*98304/120/2**20:.0f}/{a_[b]*98304/120/2**20:.0f}" for b in range(lo, hi, 2)))
