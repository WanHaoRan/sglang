"""Reviewer's test of an alternative for jit_p50's 'neither' extra reads (C7): p50 hints mis-time the next use, so
within next_use's SOON tier (farthest first) a session returning soon can be ranked farther than it is. For returning
requests sent in [lo, hi) min that read from SSD in A but not in B (paired), compare A's registered due (previous
turn's nue_register next_use_ms) with the true wait (client wait_s): over-predicted (due > wait + 30 s), about right,
under-predicted. Also the same split over all 'neither' requests of A, as a baseline.
Usage: python3 -I -B misrank.py <A.json> <B.json> <lo_min> <hi_min>"""
import collections, json, sys
A, B = json.load(open(sys.argv[1])), json.load(open(sys.argv[2])); lo, hi = float(sys.argv[3]) * 60, float(sys.argv[4]) * 60
def idx(d): return {(c["inst"], c["k"]): c for c in d["clients"] if (c["k"] or 0) > 0 and (c["ideal"] or 0) > 0 and c["ttft"] is not None}
def rt(d, rid): return sum(64 * e["pages"] for e in d["per"].get(rid, {}).get("s2h_io", []))
def prev(rid):
    h, _, k = rid.rpartition("-t"); return f"{h}-t{int(k)-1}"
def state(d, rid):
    ev = d["per"].get(rid, {}); arr = ev.get("ntp_arrive", []); at = arr[0]["t"] if arr else None
    if any(e.get("reason") == "timeout" and (at is None or e["t"] <= at) for e in ev.get("ntp_expire", [])): return "expired"
    st = ev.get("ntp_stage", [])
    return "staged" if st and (at is None or st[0]["t"] < at) else "neither"
def cls(d, c):
    regs = [e for e in d["per"].get(prev(c["rid"]), {}).get("nue_register", []) if e.get("next_use_ms") != 0]
    if not regs: return "none"
    v = regs[-1]["next_use_ms"]
    if v == "ended": return "ended"
    due = v / 1000; w = c["wait_s"] or 0
    return "over" if due > w + 30 else ("under" if due < w - 30 else "about")
ia, ib = idx(A), idx(B)
sel = collections.Counter(); base = collections.Counter()
for k, a in ia.items():
    if k not in ib or ib[k]["tree"] != a["tree"] or not (lo <= a["t_send"] < hi) or state(A, a["rid"]) != "neither": continue
    c = cls(A, a); base[c] += 1
    if rt(A, a["rid"]) > 0 and rt(B, ib[k]["rid"]) == 0: sel[c] += 1
tot_s, tot_b = sum(sel.values()), sum(base.values())
print(f"{A['label']} vs {B['label']} {lo/60:.0f}-{hi/60:.0f}: 'neither' pairs reading in A only {tot_s}: " + ", ".join(f"{k} {v} ({100*v/tot_s:.0f} %)" for k, v in sel.most_common())
      + f"; all 'neither' pairs {tot_b}: " + ", ".join(f"{k} {v} ({100*v/tot_b:.0f} %)" for k, v in base.most_common()))
