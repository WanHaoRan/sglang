"""Reviewer's check of C13: per 10-minute bin since t_start, prefill new tokens (Prefill batch #new-token), d2h_submit
tokens, h2s_submit tokens, and the SSD write backlog (h2s_submit minus h2s_done tokens) mean over the bin, sampled each 10 s.
Usage: python3 -I -B writes.py <x.json> [...]"""
import bisect, collections, json, sys
for path in sys.argv[1:]:
    d = json.load(open(path)); g = d["glob"]
    pre, d2h, h2s = collections.Counter(), collections.Counter(), collections.Counter()
    for x in g.get("prefill", []): pre[int(x[0] // 600)] += x[2]
    for e in g.get("d2h_submit", []): d2h[int(e["t"] // 600)] += e["tokens"]
    for e in g.get("h2s_submit", []): h2s[int(e["t"] // 600)] += e["tokens"]
    ev = sorted([(e["t"], e["tokens"]) for e in g.get("h2s_submit", [])] + [(e["t"], -e["tokens"]) for e in g.get("h2s_done", [])])
    ts = [x[0] for x in ev]; cum = []; s = 0
    for t, v in ev:
        s += v; cum.append(s)
    def at(t):
        j = bisect.bisect_right(ts, t) - 1
        return cum[j] if j >= 0 else 0
    print(f"{d['label']}: 10-min bin: prefill/d2h/h2s M tokens, write backlog mean K")
    print("   " + " | ".join(f"{k*10}: {pre[k]/1e6:.1f}/{d2h[k]/1e6:.1f}/{h2s[k]/1e6:.1f} bl{sum(at(k*600+i*10) for i in range(60))/60/1e3:.0f}K" for k in range(3, 12)))
