"""Reviewer's check of C4's lock snapshot: at the first refused dispatches (srs_dispatch launched=0), the logged
pinned_tokens and inflight_pages (x64), the running pinned total from srs_pin/unpin, and the SSD write backlog
(h2s_submit tokens minus h2s_done tokens so far). Also the max pinned total over the run vs the pin budget, and the
ec_price room= field range (ec_full). Usage: python3 -I -B at_ref.py <x.json> <n_first> [...]"""
import bisect, json, sys
args = sys.argv[1:]
for i in range(0, len(args), 2):
    d = json.load(open(args[i])); k = int(args[i + 1]); per, glob = d["per"], d["glob"]
    ref = sorted(((e["t"], rid, e) for rid, ev in per.items() for e in ev.get("srs_dispatch", []) if e.get("launched") == 0), key=lambda x: x[0])
    pins = sorted((e["t"], e["pinned"]) for ev in per.values() for nm in ("srs_pin", "srs_unpin") for e in ev.get(nm, []))
    pt = [p[0] for p in pins]
    sub = sorted((e["t"], e["tokens"]) for e in glob.get("h2s_submit", []))
    done = sorted((e["t"], e["tokens"]) for e in glob.get("h2s_done", []))
    def backlog(t):
        return sum(x for tt, x in sub if tt <= t) - sum(x for tt, x in done if tt <= t)
    print(f"{d['label']}: max pinned total {max(p[1] for p in pins) if pins else 0}")
    for t, rid, e in ref[:k]:
        j = bisect.bisect_right(pt, t) - 1
        print(f"   {t/60:7.2f} min {rid}: pages {e['pages']} logged pinned_tokens {e['pinned_tokens']}, inflight {e['inflight_pages']*64} tokens; "
              f"running pinned {pins[j][1] if j >= 0 else 0}; SSD write backlog {backlog(t)} tokens")
    rooms = [e["room"] for e in glob.get("ec_price", []) if "room" in e]
    if rooms:
        rooms.sort()
        print(f"   ec_price room= n {len(rooms)}: min {rooms[0]} p10 {rooms[len(rooms)//10]} p50 {rooms[len(rooms)//2]} p90 {rooms[9*len(rooms)//10]} max {rooms[-1]}")
