"""Reviewer's check of C3's bump matching: per 5-minute send bin, history computed again per returning request
(figure definition: k>0, not warmup, ttft, no error) split into requests with a refused dispatch and the rest.
Usage: python3 -I -B bumps.py <lo_min> <hi_min> <x.json> [...]"""
import collections, json, sys
lo, hi = int(sys.argv[1]), int(sys.argv[2])
for path in sys.argv[3:]:
    d = json.load(open(path))
    n = collections.Counter(); ref = collections.Counter(); oth = collections.Counter(); nref = collections.Counter()
    for c in d["clients"]:
        if not ((c["k"] or 0) > 0 and c["phase"] != "warmup" and c["ttft"] is not None and not c["err"]): continue
        b = int(c["t_send"] // 300) * 5
        if not (lo <= b < hi): continue
        cached = sum(int(c[k] or 0) for k in ("dev", "host", "ssd")) if c["has_det"] else int(c["cached_tokens"] or 0)
        a = max(0, (c["ideal"] or 0) - cached)
        n[b] += 1
        ev = d["per"].get(c["rid"], {})
        if any(e.get("launched") == 0 for e in ev.get("srs_dispatch", [])):
            ref[b] += a; nref[b] += 1
        else:
            oth[b] += a
    print(f"{d['label']}: bin: per-request recompute total = refused-path + other (refused requests)")
    print("   " + " | ".join(f"{b}: {(ref[b]+oth[b])/n[b]:.0f} = {ref[b]/n[b]:.0f} + {oth[b]/n[b]:.0f} ({nref[b]})" for b in sorted(n)))
