"""Reviewer's per-minute iostat view: read MB/s, write MB/s (MiB here, as the analyst), util, by minute since t_start.
Also decode #queue-req mean and launched=0 dispatches per minute. Usage: python3 -I -B iomin.py <iostat log> <lo> <hi> <x.json> [...]"""
import collections
import datetime as dt
import json
import re
import sys

io_path, lo, hi = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
samples = []
STAMP = re.compile(r"^(\d\d)/(\d\d)/(\d{4}) (\d\d):(\d\d):(\d\d) (AM|PM)")
cur, first = None, True
with open(io_path) as f:
    for line in f:
        m = STAMP.match(line)
        if m:
            h = int(m[4]) % 12 + (12 if m[7] == "PM" else 0)
            cur = dt.datetime(int(m[3]), int(m[1]), int(m[2]), h, int(m[5]), int(m[6]), tzinfo=dt.timezone.utc).timestamp()
            continue
        if line.startswith("vdc") and cur is not None:
            p = line.split()
            if first:
                first = False
                continue
            samples.append((cur, float(p[2]) / 1024, float(p[8]) / 1024, float(p[-1])))
for path in sys.argv[4:]:
    d = json.load(open(path))
    t0 = d["t0"]
    by = collections.defaultdict(list)
    for c, r, w, u in samples:
        by[int((c - t0 - 5) // 60)].append((r, w, u))
    q = collections.defaultdict(list)
    for x in d["glob"].get("decode", []):
        q[int(x[0] // 60)].append(x[4])
    ref = collections.Counter(int(e["t"] // 60) for ev in d["per"].values() for e in ev.get("srs_dispatch", []) if e.get("launched") == 0)
    print(f"== {d['label']}: minute: read/write MiB/s util% | decode queue mean | launched=0")
    row = []
    for m in range(lo, hi):
        v = by.get(m, [])
        if not v:
            continue
        r = sum(x[0] for x in v) / len(v); w = sum(x[1] for x in v) / len(v); u = sum(x[2] for x in v) / len(v)
        qq = q.get(m, [])
        row.append(f"{m}:{r:.0f}/{w:.0f} {u:.1f}% q{(sum(qq)/len(qq) if qq else float('nan')):.1f} r{ref.get(m,0)}")
    for i in range(0, len(row), 5):
        print("  " + " | ".join(row[i:i + 5]))
