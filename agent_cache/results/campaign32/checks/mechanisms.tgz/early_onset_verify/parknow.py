"""Reviewer's check of the read line for early reads: srs_park deadline_ms ('now' = no deadline: dispatched past the
window and the budget) for parks before the request's arrival, minutes 30-65. Usage: python3 -I -B parknow.py <x.json> [...]"""
import collections, json, sys
for path in sys.argv[1:]:
    d = json.load(open(path)); c = collections.Counter(); tok = collections.Counter()
    for rid, ev in d["per"].items():
        arr = ev.get("ntp_arrive", []); at = arr[0]["t"] if arr else (ev["rts"][0]["entry"] if ev.get("rts") else 1e9)
        for p in ev.get("srs_park", []):
            if not (1800 <= p["t"] < 3900): continue
            k = ("early" if p["t"] < at else "arrived") + ":" + ("now" if p["deadline_ms"] == "now" else "deadline")
            c[k] += 1; tok[k] += 64 * p["pages"]
    print(d["label"], "parks in minutes 30-65:", {k: (c[k], round(tok[k] / 1e6, 2)) for k in sorted(c)})
