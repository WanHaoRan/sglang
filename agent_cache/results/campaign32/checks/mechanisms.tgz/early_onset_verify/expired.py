"""Reviewer's check of C10: returning requests (k>0, ideal>0, ttft, sent before 6600 s) whose plan expired before
arrival (ntp_expire reason=timeout), with true wait, SSD read tokens (s2h_io pages x 64), history computed again;
and requests whose previous-turn registration went overdue (due + 60 s passed before arrival) without an expiry.
Arrival = the request's ReqTimeStats entry (wait-queue entry) if present, else ntp_arrive, else t_send.
Usage: python3 -I -B expired.py <lo_min> <hi_min> <x.json> [...]"""
import json
import sys

lo, hi = float(sys.argv[1]) * 60, min(float(sys.argv[2]) * 60, 6600.0)


def again(c):
    cached = sum(int(c[k] or 0) for k in ("dev", "host", "ssd")) if c["has_det"] else int(c["cached_tokens"] or 0)
    return max(0, (c["ideal"] or 0) - cached)


def prev_rid(rid):
    head, _, k = rid.rpartition("-t")
    return f"{head}-t{int(k) - 1}"


for path in sys.argv[3:]:
    d = json.load(open(path))
    per = d["per"]
    exp = []; od = []
    for c in d["clients"]:
        if not ((c["k"] or 0) > 0 and (c["ideal"] or 0) > 0 and c["ttft"] is not None and lo <= c["t_send"] < hi):
            continue
        ev = per.get(c["rid"], {})
        arr = ev.get("ntp_arrive", [])
        arr_t = arr[0]["t"] if arr else c["t_send"]
        rd = sum(64 * e["pages"] for e in ev.get("s2h_io", []))
        if any(e.get("reason") == "timeout" and e["t"] <= arr_t + 1e-3 for e in ev.get("ntp_expire", [])):
            exp.append((c, rd))
            continue
        regs = [e for e in per.get(prev_rid(c["rid"]), {}).get("nue_register", []) if isinstance(e.get("next_use_ms"), int) and e["next_use_ms"] != 0]
        if regs:
            r = regs[-1]
            due = r["t"] + r["next_use_ms"] / 1000.0
            if c["t_send"] > due + 60:
                od.append((c, rd))
    w = sorted(c["wait_s"] or 0 for c, rd in exp)
    print(f"{d['label']} minutes {lo/60:.0f}-{hi/60:.0f}: plan expired before arrival {len(exp)} (true wait p50 {w[len(w)//2] if w else float('nan'):.0f} s); "
          f"reading from SSD {sum(1 for c, rd in exp if rd > 0)} ({sum(rd for c, rd in exp)/1e6:.2f} M); computed again {sum(again(c) for c, rd in exp)/1e6:.2f} M; "
          f"overdue (sent > due + 60 s) without expiry {len(od)}, reading {sum(1 for c, rd in od if rd > 0)} ({sum(rd for c, rd in od)/1e6:.2f} M)")
