"""Reviewer's per-minute lock series: time-weighted pinned tokens (srs_pin/unpin running total), mean SSD write
backlog (h2s_submit - h2s_done), dispatches launched=0, partial evict_host, and srs_dispatch's logged inflight pages x64
(mean of the dispatch lines in the minute). Usage: python3 -I -B lockseries.py <lo> <hi> <x.json> [...]"""
import bisect, collections, json, sys
lo, hi = int(sys.argv[1]), int(sys.argv[2])
for path in sys.argv[3:]:
    d = json.load(open(path)); per, g = d["per"], d["glob"]
    pins = sorted((e["t"], e["pinned"]) for ev in per.values() for nm in ("srs_pin", "srs_unpin") for e in ev.get(nm, []))
    pt = [p[0] for p in pins]
    def pinned(t):
        j = bisect.bisect_right(pt, t) - 1
        return pins[j][1] if j >= 0 else 0
    ev = sorted([(e["t"], e["tokens"]) for e in g.get("h2s_submit", [])] + [(e["t"], -e["tokens"]) for e in g.get("h2s_done", [])])
    ts = [x[0] for x in ev]; cum = []; s = 0
    for t, v in ev:
        s += v; cum.append(s)
    def bl(t):
        j = bisect.bisect_right(ts, t) - 1
        return cum[j] if j >= 0 else 0
    ref = collections.Counter(int(e["t"] // 60) for x in per.values() for e in x.get("srs_dispatch", []) if e.get("launched") == 0)
    part = collections.Counter(int(e["t"] // 60) for e in g.get("evict_host", []) if e["tokens"] < e["requested"])
    infl = collections.defaultdict(list)
    for x in per.values():
        for e in x.get("srs_dispatch", []):
            infl[int(e["t"] // 60)].append(e["inflight_pages"] * 64)
    print(f"== {d['label']}: minute: pinned K / write backlog K / dispatch-line inflight K / refused / partial evictions")
    row = []
    for m in range(lo, hi):
        p = sum(pinned(m * 60 + i) for i in range(60)) / 60
        b = sum(bl(m * 60 + i) for i in range(60)) / 60
        f = sum(infl[m]) / len(infl[m]) if infl[m] else 0
        row.append(f"{m}: {p/1e3:.0f}/{b/1e3:.0f}/{f/1e3:.0f} r{ref[m]} p{part[m]}")
    for i in range(0, len(row), 6):
        print("  " + " | ".join(row[i:i + 6]))
