"""Reviewer's small checks run inline during the review, collected for re-running (reads ext.py's JSONs in x/):
  load      requests sent, prompt tokens and new tokens per 5-minute send bin, five arms (C5)
  refcap    refused requests with recompute in minutes 60-90 that also reached the cap (C1)
  cleanup   NIXL L3 cleanup pass times per arm (ruled-out item)
  ehnear    refused dispatches with an evict_host line within 2 ms (C4)
  repeat    first vs repeat SSD reads per request in minutes 36-64 and 64-71 (C15)
  misrank   jit_p50 - jit_exact extra SSD tokens of 'neither' pairs in 30-65 by jit_p50's previous-turn registration (C7)
Usage: python3 -I -B inline_checks.py <check>"""
import bisect
import collections
import json
import sys

V = "/tmp/claude-1001/-home-wanhr-sglang/7c93b1d5-dc1c-431d-8d3e-efb4ae23a30d/scratchpad/c32/early_onset_verify"
L = lambda a: json.load(open(f"{V}/x/c32_{a}.json"))
what = sys.argv[1]


def prev(rid):
    h, _, k = rid.rpartition("-t")
    return f"{h}-t{int(k) - 1}"


if what == "load":
    arms = ["jit_p50", "oracle_v2", "jit_exact", "ec_full", "ec_exact"]
    rows = {}
    for a in arms:
        d = L(a)
        n, tok, new = collections.Counter(), collections.Counter(), collections.Counter()
        for c in d["clients"]:
            if c["t_send"] is None:
                continue
            b = int(c["t_send"] // 300) * 5
            n[b] += 1; tok[b] += c["prompt"] or 0; new[b] += max(0, (c["prompt"] or 0) - (c["ideal"] or 0))
        rows[a] = (n, tok, new)
    for b in range(25, 80, 5):
        print(f"{b:3d} | " + " ".join(f"{rows[a][0][b]:4d}" for a in arms) + " | " + " ".join(f"{rows[a][1][b]/1e6:5.1f}" for a in arms)
              + " | " + " ".join(f"{rows[a][2][b]/1e6:4.2f}" for a in arms))
elif what == "refcap":
    for a in ("jit_p50", "oracle_v2", "jit_exact"):
        d = L(a); n = nc = 0
        for c in d["clients"]:
            if not ((c["k"] or 0) > 0 and (c["ideal"] or 0) > 0 and c["ttft"] is not None and 3600 <= c["t_send"] < 5400):
                continue
            cached = sum(int(c[k] or 0) for k in ("dev", "host", "ssd")) if c["has_det"] else int(c["cached_tokens"] or 0)
            if max(0, c["ideal"] - cached) <= 0:
                continue
            ev = d["per"].get(c["rid"], {})
            if any(e.get("launched") == 0 for e in ev.get("srs_dispatch", [])):
                n += 1
                nc += any(e.get("decision") == "capped" for e in ev.get("ntp_gate", [])) or any(e.get("capped") == 1 for e in ev.get("ntp_reevict", []))
        print(a, "refused requests with recompute, 60-90:", n, "also capped:", nc)
elif what == "cleanup":
    for a in ["hicache", "ec_full", "ec_exact", "jit_p50", "jit_exact", "oracle_v2"]:
        print(a, [(round(e["t"]), e["text"][:60]) for e in L(a)["glob"].get("cleanup", [])])
elif what == "ehnear":
    for a in ["jit_p50", "oracle_v2", "jit_exact"]:
        d = L(a); eh = sorted(e["t"] for e in d["glob"]["evict_host"])
        ref = [e["t"] for ev in d["per"].values() for e in ev.get("srs_dispatch", []) if e.get("launched") == 0 and e["t"] < 6600]
        near = 0
        for t in ref:
            j = bisect.bisect_left(eh, t - 0.002)
            near += j < len(eh) and eh[j] <= t + 0.002
        print(a, "refused dispatches before 6600 s", len(ref), "with an evict_host line within 2 ms", near)
elif what == "repeat":
    for a in ["oracle_v2", "jit_exact", "jit_p50"]:
        d = L(a)
        for lo, hi in ((36 * 60, 64 * 60), (64 * 60, 71 * 60)):
            rids, first, again = collections.Counter(), 0, 0
            for rid, ev in d["per"].items():
                for i, io in enumerate(sorted(ev.get("s2h_io", []), key=lambda e: e["t"])):
                    if lo <= io["t"] < hi:
                        rids[rid] += 1
                        if i == 0:
                            first += 64 * io["pages"]
                        else:
                            again += 64 * io["pages"]
            print(f"{a} {lo/60:.0f}-{hi/60:.0f}: requests reading {len(rids)}, reads {sum(rids.values())}, first reads {first/1e6:.2f} M, repeat {again/1e6:.2f} M")
elif what == "misrank":
    A, B = L("jit_p50"), L("jit_exact")
    idx = lambda d: {(c["inst"], c["k"]): c for c in d["clients"] if (c["k"] or 0) > 0 and (c["ideal"] or 0) > 0 and c["ttft"] is not None}
    rt = lambda d, rid: sum(64 * e["pages"] for e in d["per"].get(rid, {}).get("s2h_io", []))

    def state(d, rid):
        ev = d["per"].get(rid, {}); arr = ev.get("ntp_arrive", []); at = arr[0]["t"] if arr else None
        if any(e.get("reason") == "timeout" and (at is None or e["t"] <= at) for e in ev.get("ntp_expire", [])):
            return "expired"
        st = ev.get("ntp_stage", [])
        return "staged" if st and (at is None or st[0]["t"] < at) else "neither"
    ia, ib = idx(A), idx(B); tok, n = collections.Counter(), collections.Counter()
    for k, a in ia.items():
        if k not in ib or ib[k]["tree"] != a["tree"] or not (1800 <= a["t_send"] < 3900) or state(A, a["rid"]) != "neither":
            continue
        ex = rt(A, a["rid"]) - rt(B, ib[k]["rid"])
        regs = [e for e in A["per"].get(prev(a["rid"]), {}).get("nue_register", []) if e.get("next_use_ms") != 0]
        if not regs:
            c = "none"
        elif regs[-1]["next_use_ms"] == "ended":
            c = "ended"
        else:
            due = regs[-1]["next_use_ms"] / 1000; w = a["wait_s"] or 0
            c = "over" if due > w + 30 else ("under" if due < w - 30 else "about")
        tok[c] += ex; n[c] += 1
    tot = sum(tok.values())
    print({k: (n[k], round(v / 1e6, 2), f"{100 * v / tot:.0f}%") for k, v in tok.items()}, "total", round(tot / 1e6, 2))
