"""SSD device statistics (iostat, 10 s samples, UTC clock) by 10 minutes of each arm's client clock: read and write
MB/s, r_await and w_await ms, queue depth and %util (means). From agent_cache/:
  python3 -I -B iostat_arms.py <iostat log> <manifest> [label ...]"""
import collections, datetime as dt, json, re, sys
log, manifest = sys.argv[1], sys.argv[2]
want = set(sys.argv[3:])
rows = [l.split() for l in open(manifest) if l.strip()]
samples = []
when = None
hdr = None
for line in open(log):
    line = line.rstrip()
    m = re.match(r"^(\d\d)/(\d\d)/(\d{4}) (\d\d):(\d\d):(\d\d) (AM|PM)$", line)
    if m:
        mo, d, y, H, M, S, ap = m.groups()
        H = int(H) % 12 + (12 if ap == "PM" else 0)
        when = dt.datetime(int(y), int(mo), int(d), H, int(M), int(S), tzinfo=dt.timezone.utc).timestamp()
        continue
    if line.startswith("Device"):
        hdr = line.split()
        continue
    if line.startswith("vdc") and hdr and when:
        v = dict(zip(hdr, line.split()))
        samples.append((when, float(v["rkB/s"]), float(v["wkB/s"]), float(v["r_await"]), float(v["w_await"]), float(v["aqu-sz"]), float(v["%util"]), float(v["r/s"]), float(v["w/s"])))
samples = samples[1:]  # the first sample is the average since boot
for lab, run, prog in rows:
    if want and lab not in want:
        continue
    with open(f"results/{run}/{prog}/client.jsonl") as f:
        t0 = json.loads(f.readline())["t_start"]
    by = collections.defaultdict(list)
    for s in samples:
        t = s[0] - t0
        if -600 <= t < 7300:
            by[int(t // 600)].append(s)
    print(f"===== {lab}: 10 min | read MB/s write MB/s | r_await w_await ms | aqu-sz %util | reads/s writes/s")
    for k in sorted(by):
        v = by[k]
        n = len(v)
        mean = lambda i: sum(x[i] for x in v) / n
        print(f"  {10*k:4d}-{10*k+10:<4d} | {mean(1)/1e3:7.0f} {mean(2)/1e3:7.0f} | {mean(3):6.1f} {mean(4):6.1f} | {mean(5):6.1f} {mean(6):5.1f} | {mean(7):6.0f} {mean(8):6.0f}  (n={n})")
