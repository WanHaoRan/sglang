"""Minute-by-minute onset of the FA3 loop for one arm: users in session, queue, sends, history computed again per
returning request, SSD reads (s2h_io) and read-thread busy, SSD read/write MB/s and %util (iostat), write-back
submit->done median and tokens outstanding, dispatches and launched=0, capped re-evictions. From agent_cache/:
  python3 -I -B onset.py <scan dir> <label> results/<run> <programs> <iostat log> [from_min to_min]"""
import bisect, collections, datetime as dt, json, re, statistics as st, sys
scan, label, run, prog, iolog = sys.argv[1:6]
lo, hi = (int(sys.argv[6]), int(sys.argv[7])) if len(sys.argv) > 7 else (20, 120)
s = json.load(open(f"{scan}/{label}.json"))
mins = {int(k): v for k, v in s["minutes"].items()}
t0 = s["t0"]
with open(f"{run}/{prog}/client.jsonl") as f:
    f.readline()
    recs = [json.loads(l) for l in f]
lanes = {int(r["t"] // 60) - 1: r["live"] for r in recs if r["kind"] == "lanes"}
reqs = [r for r in recs if r["kind"] == "req" and r.get("ttft") is not None]
def cached(r):
    d = r.get("cached_details") or {}
    return sum(int(d.get(k) or 0) for k in ("device", "host", "storage")) if d else int(r.get("cached_tokens") or 0)
cl = collections.defaultdict(list)
for r in reqs:
    cl[int(r["t_send"] // 60)].append(r)
# write-back
TS = re.compile(r"^\[(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d\.\d+)\] HICACHE_EVT (h2s_submit|h2s_done) op=(\d+)(?: node=\d+ tokens=(\d+))?")
sub, done = {}, {}
for line in open(f"{run}/server.log", errors="replace"):
    if "HICACHE_EVT h2s_" not in line:
        continue
    m = TS.match(line)
    if not m:
        continue
    t = dt.datetime.strptime(m[1], "%Y-%m-%d %H:%M:%S.%f").replace(tzinfo=dt.timezone.utc).timestamp() - t0
    if m[2] == "h2s_submit":
        sub[int(m[3])] = (t, int(m[4]))
    else:
        done[int(m[3])] = t
lat = collections.defaultdict(list)
ev = []
for op, (t, tok) in sub.items():
    if op in done:
        lat[int(t // 60)].append(done[op] - t)
        ev.append((done[op], -tok))
    ev.append((t, tok))
ev.sort()
outst = {}
cur, i = 0, 0
for m in range(0, 125):
    while i < len(ev) and ev[i][0] < 60 * (m + 1):
        cur += ev[i][1]; i += 1
    outst[m] = cur
# iostat
io = collections.defaultdict(list)
when, hdr = None, None
for line in open(iolog):
    line = line.rstrip()
    mm = re.match(r"^(\d\d)/(\d\d)/(\d{4}) (\d\d):(\d\d):(\d\d) (AM|PM)$", line)
    if mm:
        mo, d, y, H, M, S, ap = mm.groups()
        H = int(H) % 12 + (12 if ap == "PM" else 0)
        when = dt.datetime(int(y), int(mo), int(d), H, int(M), int(S), tzinfo=dt.timezone.utc).timestamp() - t0
        continue
    if line.startswith("Device"):
        hdr = line.split(); continue
    if line.startswith("vdc") and hdr and when is not None and 0 <= when < 7300:
        v = dict(zip(hdr, line.split()))
        io[int(when // 60)].append((float(v["rkB/s"]) / 1e3, float(v["wkB/s"]) / 1e3, float(v["%util"])))
print(f"{label}: min | live queue sent | again/ret  SSD% | reads busy% | rMB wMB util | wb p50 s  outst K | disp l0 capped")
for m in range(lo, hi):
    b = mins.get(m, {})
    v = cl.get(m, [])
    ret = [r for r in v if r["k"] > 0]
    again = sum(max(0, r["ideal_cached"] - cached(r)) for r in ret) / max(1, len(ret))
    ssd = 100 * sum(int((r.get("cached_details") or {}).get("storage") or 0) > 0 for r in ret) / max(1, len(ret))
    x = io.get(m, [(0, 0, 0)])
    L = sorted(lat.get(m, [float("nan")]))
    print(f"  {m:3d} | {lanes.get(m, 0):4d} {b.get('queue_med', 0):5.0f} {len(v):4d} | {again:7.0f} {ssd:4.0f} | {b.get('io_n', 0):4.0f} {100 * b.get('io_ms', 0) / 6e4:4.0f} | "
          f"{st.mean(a for a, _, _ in x):5.0f} {st.mean(w for _, w, _ in x):5.0f} {st.mean(u for _, _, u in x):4.0f} | {L[len(L) // 2]:6.2f} {outst[m] / 1e3:6.0f} | "
          f"{b.get('disp_n', 0):4.0f} {b.get('disp_l0', 0):4.0f} {b.get('reevict_capped', 0):4.0f}")
