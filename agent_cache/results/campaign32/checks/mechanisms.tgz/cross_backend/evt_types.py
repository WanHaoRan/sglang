"""Count line kinds and HICACHE_EVT event types in a server.log; print the first two samples of each.
  python3 -I -B evt_types.py results/<run>/server.log"""
import collections, re, sys
cnt, samp = collections.Counter(), collections.defaultdict(list)
EV = re.compile(r"HICACHE_EVT (\S+)")
TS = re.compile(r"^\[(.{23})\] (.*)")
for line in open(sys.argv[1], errors="replace"):
    m = TS.match(line)
    if not m:
        key = "<no ts>"
    else:
        body = m[2]
        if (e := EV.search(body)):
            key = "EVT " + e[1]
        else:
            key = " ".join(body.split()[:2])[:40]
    cnt[key] += 1
    if len(samp[key]) < 2:
        samp[key].append(line.rstrip()[:400])
for k, v in cnt.most_common():
    if v < 3 and not k.startswith("EVT"):
        continue
    print(f"{v:9d}  {k}")
    for s in samp[k]:
        print("            ", s)
