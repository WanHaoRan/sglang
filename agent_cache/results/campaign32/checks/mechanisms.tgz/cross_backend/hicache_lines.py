"""Count non-EVT log line kinds (first words, ids stripped) in each server.log of a manifest; samples of rare ones.
  python3 -I -B hicache_lines.py <manifest> [label ...]"""
import collections, re, sys
rows = [l.split() for l in open(sys.argv[1]) if l.strip()]
want = set(sys.argv[2:])
TS = re.compile(r"^\[(.{23})\] (.*)")
for lab, run, _ in rows:
    if want and lab not in want:
        continue
    cnt, samp = collections.Counter(), collections.defaultdict(list)
    for line in open(f"results/{run}/server.log", errors="replace"):
        m = TS.match(line)
        if not m:
            continue
        body = m[2]
        if body.startswith(("HICACHE_EVT", "INFO:", "Decode batch", "Prefill batch", "ReqTimeStats")):
            continue
        key = re.sub(r"\S*\d\S*", "#", " ".join(body.split()[:6]))[:70]
        cnt[key] += 1
        if len(samp[key]) < 1:
            samp[key].append(line.rstrip()[:300])
    print(f"===== {lab} {run}")
    for k, v in cnt.most_common(40):
        print(f"{v:8d}  {k}")
        if v < 2000:
            print("            ", samp[k][0])
