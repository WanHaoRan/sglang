"""Queue over the run, every run: by 10 minutes of the client clock, queued requests (decode lines' median a minute,
averaged) / mean queue wait in s (ReqTimeStats queue_duration, by queue entry time) / users in session (lanes, mean).
From agent_cache/, after scan_run.py:  python3 -I -B queue_bins.py <scan dir> <manifest>"""
import json, sys
scan, manifest = sys.argv[1], sys.argv[2]
rows = [l.split() for l in open(manifest) if l.strip()]
print("cells: queued / wait s / users in session")
print("arm            | " + " ".join(f"{10*k:>4d}-{10*k+10:<4d}       " for k in range(11)))
for lab, run, prog in rows:
    s = json.load(open(f"{scan}/{lab}.json"))
    mins = {int(k): v for k, v in s["minutes"].items()}
    with open(f"results/{run}/{prog}/client.jsonl") as f:
        f.readline()
        lanes = {}
        for l in f:
            if '"kind": "lanes"' in l or '"kind":"lanes"' in l:
                r = json.loads(l); lanes[int(r["t"] // 60) - 1] = r["live"]
    cells = []
    for k in range(11):
        qs = [mins[m]["queue_med"] for m in range(10 * k, 10 * k + 10) if m in mins and "queue_med" in mins[m]]
        ws = [v["queue_s"] for v in s["req"].values() if "queue_s" in v and 600 * k <= v["entry"] < 600 * (k + 1)]
        ls = [lanes[m] for m in range(10 * k, 10 * k + 10) if m in lanes]
        cells.append(f"{(sum(qs)/len(qs) if qs else 0):4.0f}/{(sum(ws)/len(ws) if ws else 0):5.1f}/{(sum(ls)/len(ls) if ls else 0):3.0f}")
    print(f"{lab:14s} | " + "  ".join(cells))
