"""SSD reads that served their request: per arm and send window, tokens read for a request (s2h_io pages x 64 under
its rid) against the tokens its admission took from storage (client cached_details.storage), and the requests whose
reads delivered nothing. From agent_cache/, after scan_run.py:
  python3 -I -B read_use.py <scan dir> <manifest>"""
import json, sys
scan, manifest = sys.argv[1], sys.argv[2]
rows = [l.split() for l in open(manifest) if l.strip()]
WIN = ((0, 1800), (1800, 4200), (4200, 6600))
print("arm            | window      | requests with reads | read M | delivered from SSD M | delivered/read | requests whose reads delivered 0 | their read M")
for lab, run, prog in rows:
    s = json.load(open(f"{scan}/{lab}.json"))
    R = s["req"]
    with open(f"results/{run}/{prog}/client.jsonl") as f:
        f.readline()
        reqs = {json.loads(l)["rid"]: json.loads(l) for l in f if '"kind":"req"' in l}
    for lo, hi in WIN:
        n = rd = dl = z = zr = 0
        for rid, q in R.items():
            r = reqs.get(rid)
            if r is None or not (lo <= r["t_send"] < hi) or not q.get("io_pages"):
                continue
            tok = q["io_pages"] * 64
            st_ = int((r.get("cached_details") or {}).get("storage") or 0)
            n += 1; rd += tok; dl += st_
            if st_ == 0:
                z += 1; zr += tok
        print(f"{lab:14s} | {lo:5.0f}-{hi:<5.0f} | {n:6d} | {rd/1e6:7.2f} | {dl/1e6:7.2f} | {dl/max(1,rd):5.2f} | {z:6d} | {zr/1e6:6.2f}")
