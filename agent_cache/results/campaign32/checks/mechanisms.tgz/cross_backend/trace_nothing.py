"""Pick returning requests sent in [lo, hi) that got under 2 % of their ideal history although an SSD lookup found
pages for them; print each one's server-log lines. From agent_cache/:
  python3 -I -B trace_nothing.py results/<run> <programs> lo hi n_examples [seed]"""
import json, random, re, sys
run, programs, lo, hi, n = sys.argv[1], sys.argv[2], float(sys.argv[3]), float(sys.argv[4]), int(sys.argv[5])
seed = int(sys.argv[6]) if len(sys.argv) > 6 else 1
found = {}
for line in open(f"{run}/server.log", errors="replace"):
    if "s2h_query" in line and (m := re.search(r"rid=(\S+) tokens_req=\d+ storage_hit=(\d+)", line)):
        found[m[1]] = found.get(m[1], 0) + int(m[2])
reqs = [json.loads(l) for l in open(f"{run}/{programs}/client.jsonl") if '"kind":"req"' in l]
def cached(r):
    d = r.get("cached_details") or {}
    return sum(int(d.get(k) or 0) for k in ("device", "host", "storage")) if d else int(r.get("cached_tokens") or 0)
pick = [r for r in reqs if lo <= r["t_send"] < hi and r["k"] > 0 and r["ideal_cached"] > 0 and r.get("ttft") is not None
        and cached(r) / r["ideal_cached"] < 0.02 and found.get(r["rid"], 0) > 0]
print(f"{len(pick)} such requests")
random.seed(seed)
ex = random.sample(pick, min(n, len(pick)))
for r in ex:
    print(f"===== {r['rid']} t_send={r['t_send']:.1f} prompt={r['prompt_tokens']} ideal={r['ideal_cached']} cached={cached(r)} ttft={r['ttft']:.1f} details={r.get('cached_details')}")
    pat = re.compile(r"(rid|req)=" + re.escape(r["rid"]) + r"[ ,)]")
    for line in open(f"{run}/server.log", errors="replace"):
        if r["rid"] in line and pat.search(line):
            print("   ", line.rstrip()[:260])
