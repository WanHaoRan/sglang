"""Per 10 minutes of the client clock: pinned read tokens held (mean over dispatches of srs_dispatch pinned_tokens),
read starts by case (ntp_due case 1 = before arrival on the hint, case 2 = in the queue), staged reads (ntp_stage),
expired plans (ntp_expire), arrival holds (ntp_hold) and their mean hold, SSD reads done (s2h_io). From agent_cache/:
  python3 -I -B pins_cases.py <scan dir> <manifest> [label ...]"""
import json, sys
scan, manifest = sys.argv[1], sys.argv[2]
want = set(sys.argv[3:])
rows = [l.split() for l in open(manifest) if l.strip()]
for lab, run, prog in rows:
    if want and lab not in want:
        continue
    s = json.load(open(f"{scan}/{lab}.json"))
    mins = {int(k): v for k, v in s["minutes"].items()}
    print(f"===== {lab}: 10 min | pinned K at dispatch | due case1 case2 | staged expired | holds, mean hold s | reads")
    for k in range(0, 12):
        g = lambda key: sum(mins.get(m, {}).get(key, 0) for m in range(10 * k, 10 * k + 10))
        d = g("disp_n")
        h = g("hold")
        print(f"  {10*k:4d}-{10*k+10:<4d} | {g('pinned_sum') / max(1, d) / 1e3:6.0f} | {g('due_case1'):5.0f} {g('due_case2'):5.0f} | {g('stage'):5.0f} {g('expire'):5.0f} | {h:5.0f} {g('hold_ms') / max(1, h) / 1e3:5.1f} | {g('io_n'):5.0f}")
