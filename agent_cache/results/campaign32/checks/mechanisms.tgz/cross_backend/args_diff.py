"""Diff server_args between each campaign-28 arm and its campaign-32 run. From agent_cache/:
  python3 -I -B args_diff.py results/campaign32/checks/vs_c28/manifest.txt"""
import ast, sys
rows = [l.split() for l in open(sys.argv[1]) if l.strip()]
runs = {lab: run for lab, run, _ in rows}
def load(run):
    t = open(f"results/{run}/server_args.txt").read()
    t = t[t.index("server_args=") + len("server_args="):].strip()
    return ast.literal_eval(t.splitlines()[0])
arms = sorted({lab.rsplit("_", 1)[0] for lab in runs})
skip = {"random_seed"}
for a in arms:
    tri, fa3 = load(runs[a + "_tri"]), load(runs[a + "_fa3"])
    keys = sorted(set(tri) | set(fa3))
    d = [(k, tri.get(k, "<absent>"), fa3.get(k, "<absent>")) for k in keys if tri.get(k, "<absent>") != fa3.get(k, "<absent>") and k not in skip]
    print(f"== {a}: {len(d)} differing keys")
    for k, x, y in d:
        print(f"  {k}: tri={str(x)[:150]} | fa3={str(y)[:150]}")
# arm-specific flags of interest in fa3
print()
for a in arms:
    fa3 = load(runs[a + "_fa3"])
    ks = [k for k in fa3 if any(s in k for s in ("hicache", "prefetch", "next_turn", "eviction", "storage", "hint", "ntp", "read", "price", "pin", "gate", "hold"))]
    print(a, {k: fa3[k] for k in ks})
