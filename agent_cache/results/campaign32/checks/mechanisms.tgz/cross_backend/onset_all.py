"""Per-minute series for every run of a manifest (as onset.py) and the minute each threshold is first crossed.
From agent_cache/:
  python3 -I -B onset_all.py <scan dir> <manifest> <iostat log c28> <iostat log c32> <out.json>
Thresholds (first minute, sustained over that minute and the next two where noted): 128 users in session; read
thread >= 80 % busy (3 min); SSD util >= 95 % (3 min); write-back submit->done median >= 5 s (3 min); launched=0
dispatches >= 5 a minute (3 min); history computed again >= 2,000 tokens per returning request (3-min mean)."""
import collections, datetime as dt, json, re, statistics as st, sys
scan, manifest, io28, io32, outp = sys.argv[1:6]
rows = [l.split() for l in open(manifest) if l.strip()]
def iostat(log):
    out, when, hdr = [], None, None
    for line in open(log):
        line = line.rstrip()
        mm = re.match(r"^(\d\d)/(\d\d)/(\d{4}) (\d\d):(\d\d):(\d\d) (AM|PM)$", line)
        if mm:
            mo, d, y, H, M, S, ap = mm.groups()
            H = int(H) % 12 + (12 if ap == "PM" else 0)
            when = dt.datetime(int(y), int(mo), int(d), H, int(M), int(S), tzinfo=dt.timezone.utc).timestamp()
            continue
        if line.startswith("Device"):
            hdr = line.split(); continue
        if line.startswith("vdc") and hdr and when is not None:
            v = dict(zip(hdr, line.split()))
            out.append((when, float(v["rkB/s"]) / 1e3, float(v["wkB/s"]) / 1e3, float(v["%util"])))
    return out[1:]
IO = {"tri": iostat(io28), "fa3": iostat(io32)}
def cached(r):
    d = r.get("cached_details") or {}
    return sum(int(d.get(k) or 0) for k in ("device", "host", "storage")) if d else int(r.get("cached_tokens") or 0)
TS = re.compile(r"^\[(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d\.\d+)\] HICACHE_EVT (h2s_submit|h2s_done) op=(\d+)(?: node=\d+ tokens=(\d+))?")
allser = {}
for lab, run, prog in rows:
    s = json.load(open(f"{scan}/{lab}.json"))
    mins = {int(k): v for k, v in s["minutes"].items()}
    t0 = s["t0"]
    with open(f"results/{run}/{prog}/client.jsonl") as f:
        f.readline()
        recs = [json.loads(l) for l in f]
    lanes = {int(r["t"] // 60) - 1: r["live"] for r in recs if r["kind"] == "lanes"}
    cl = collections.defaultdict(list)
    for r in recs:
        if r["kind"] == "req" and r.get("ttft") is not None:
            cl[int(r["t_send"] // 60)].append(r)
    sub, done = {}, {}
    for line in open(f"results/{run}/server.log", errors="replace"):
        if "HICACHE_EVT h2s_" not in line:
            continue
        m = TS.match(line)
        if m:
            t = dt.datetime.strptime(m[1], "%Y-%m-%d %H:%M:%S.%f").replace(tzinfo=dt.timezone.utc).timestamp() - t0
            if m[2] == "h2s_submit":
                sub[int(m[3])] = (t, int(m[4]))
            else:
                done[int(m[3])] = t
    lat = collections.defaultdict(list)
    for op, (t, tok) in sub.items():
        if op in done:
            lat[int(t // 60)].append(done[op] - t)
    io = collections.defaultdict(list)
    for w, r_, w_, u in IO[lab.rsplit("_", 1)[1]]:
        t = w - t0
        if 0 <= t < 7300:
            io[int(t // 60)].append((r_, w_, u))
    ser = []
    for m in range(0, 121):
        b = mins.get(m, {})
        ret = [r for r in cl.get(m, []) if r["k"] > 0]
        L = sorted(lat.get(m, [])) or [float("nan")]
        x = io.get(m) or [(float("nan"),) * 3]
        ser.append(dict(m=m, live=lanes.get(m, 0), queue=b.get("queue_med", 0), sent=len(cl.get(m, [])),
                        again=sum(max(0, r["ideal_cached"] - cached(r)) for r in ret) / max(1, len(ret)),
                        busy=100 * b.get("io_ms", 0) / 6e4, rmb=st.mean(a[0] for a in x), wmb=st.mean(a[1] for a in x), util=st.mean(a[2] for a in x),
                        wb=L[len(L) // 2], l0=b.get("disp_l0", 0), disp=b.get("disp_n", 0)))
    allser[lab] = ser
json.dump(allser, open(outp, "w"))
def first(ser, test, run=3):
    for i in range(len(ser) - run + 1):
        if all(test(ser[i + j]) for j in range(run)):
            return ser[i]["m"]
    return None
def first_mean(ser, key, th, run=3):
    for i in range(len(ser) - run + 1):
        if sum(ser[i + j][key] for j in range(run)) / run >= th:
            return ser[i]["m"]
    return None
print("first minute: 128 in session | read thread >=80 % | SSD util >=95 % | write-back median >=5 s | launched=0 >=5/min | again >=2000/returning (3-min mean)")
for lab in allser:
    ser = allser[lab]
    print(f"  {lab:14s} | {first(ser, lambda r: r['live'] >= 128, 1)!s:>4s} | {first(ser, lambda r: r['busy'] >= 80)!s:>4s} | {first(ser, lambda r: r['util'] >= 95)!s:>4s} | "
          f"{first(ser, lambda r: r['wb'] >= 5)!s:>4s} | {first(ser, lambda r: r['l0'] >= 5)!s:>4s} | {first_mean(ser, 'again', 2000)!s:>4s}")
print()
print("minutes 0-110 with: SSD util >= 95 % | write-back median >= 5 s | launched=0 >= 5 | again >= 2000; max write-back median s; mean write MB/s, read MB/s over 60-110")
for lab in allser:
    ser = [r for r in allser[lab] if r["m"] < 110]
    late = [r for r in ser if r["m"] >= 60]
    print(f"  {lab:14s} | {sum(r['util'] >= 95 for r in ser):4d} | {sum(r['wb'] >= 5 for r in ser):4d} | {sum(r['l0'] >= 5 for r in ser):4d} | {sum(r['again'] >= 2000 for r in ser):4d} | "
          f"{max(r['wb'] for r in ser if r['wb'] == r['wb']):6.1f} | {st.mean(r['wmb'] for r in late):6.0f} {st.mean(r['rmb'] for r in late):6.0f}")
