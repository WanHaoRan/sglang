"""Host churn before and after the user cap binds: per arm, over minutes [a, b) of the client clock, tokens read from
SSD (s2h_io pages x 64), tokens evicted from host (evict_host), tokens evicted from GPU (evict_device), tokens copied
host->GPU (h2d) and GPU->host (d2h), and the mean pinned read tokens at dispatch. From agent_cache/, after scan_run.py:
  python3 -I -B churn.py <scan dir> <manifest> a b [a b ...]"""
import json, sys
scan, manifest = sys.argv[1], sys.argv[2]
wins = [(int(sys.argv[i]), int(sys.argv[i + 1])) for i in range(3, len(sys.argv), 2)]
rows = [l.split() for l in open(manifest) if l.strip()]
for a, b in wins:
    print(f"minutes {a}-{b}: arm | SSD read M | host evicted M | GPU evicted M | host->GPU M | GPU->host M | pinned K (mean at dispatch)")
    for lab, run, prog in rows:
        s = json.load(open(f"{scan}/{lab}.json"))
        mins = {int(k): v for k, v in s["minutes"].items()}
        g = lambda key: sum(mins.get(m, {}).get(key, 0) for m in range(a, b))
        print(f"  {lab:14s} | {g('io_pages') * 64 / 1e6:6.1f} | {g('evict_host_tok') / 1e6:6.1f} | {g('evict_dev_tok') / 1e6:6.1f} | {g('h2d_tok') / 1e6:6.1f} | {g('d2h_tok') / 1e6:6.1f} | {g('pinned_sum') / max(1, g('disp_n')) / 1e3:6.0f}")
