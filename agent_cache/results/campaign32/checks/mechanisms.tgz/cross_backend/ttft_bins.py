"""TTFT mean and requests sent by 10 minutes of send time, every run of a manifest (requests with a TTFT, phase
profile). From agent_cache/:  python3 -I -B ttft_bins.py <manifest>"""
import json, sys
rows = [l.split() for l in open(sys.argv[1]) if l.strip()]
print("arm            | " + " ".join(f"{10*k:>3d}-{10*k+10:<3d}      " for k in range(11)))
for lab, run, prog in rows:
    with open(f"results/{run}/{prog}/client.jsonl") as f:
        f.readline()
        reqs = [json.loads(l) for l in f if '"kind":"req"' in l]
    reqs = [r for r in reqs if r.get("ttft") is not None and r["phase"] == "profile"]
    cells = []
    for k in range(11):
        v = [r["ttft"] for r in reqs if 600 * k <= r["t_send"] < 600 * (k + 1)]
        cells.append(f"{(sum(v)/len(v) if v else float('nan')):6.2f} {len(v):4d}")
    print(f"{lab:14s} | " + " ".join(cells))
