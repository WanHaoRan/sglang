"""Users admitted (first request sent) by window of the client clock, every run: plays whose first profile request
falls in [0,10), [10,30), [30,60), [60,110) minutes, and in all before 6,600 s. From agent_cache/:
  python3 -I -B users_admitted.py <manifest>"""
import json, sys
rows = [l.split() for l in open(sys.argv[1]) if l.strip()]
WIN = ((0, 10), (10, 30), (30, 60), (60, 110))
print("arm            | " + " ".join(f"{a:>3d}-{b:<3d}" for a, b in WIN) + " | before 6,600 s")
for lab, run, prog in rows:
    first = {}
    with open(f"results/{run}/{prog}/client.jsonl") as f:
        f.readline()
        for l in f:
            if '"kind":"req"' not in l and '"kind": "req"' not in l:
                continue
            r = json.loads(l)
            if r["phase"] != "profile":
                continue
            p = r["play"]
            first[p] = min(first.get(p, 1e18), r["t_send"])
    cnt = [sum(1 for t in first.values() if 60 * a <= t < 60 * b) for a, b in WIN]
    print(f"{lab:14s} | " + " ".join(f"{c:7d}" for c in cnt) + f" | {sum(1 for t in first.values() if t < 6600):6d}")
