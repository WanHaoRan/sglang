"""At each storage-read dispatch (srs_dispatch), the host state: tokens of write-back ops submitted and not yet done
(their host nodes are host-locked until h2s_done), pinned read tokens and in-flight read pages (from the line), by
outcome launched=1 / launched=0, over dispatches in [from_s, to_s) of the client clock. Also short host evictions
(evict_host evicted < requested) against the write-back outstanding. From agent_cache/:
  python3 -I -B refusal_state.py <manifest> [from_s to_s] [label ...]"""
import bisect, datetime as dt, json, re, statistics as st, sys
manifest = sys.argv[1]
args = sys.argv[2:]
lo, hi = 0.0, 7300.0
if len(args) >= 2 and args[0].replace(".", "").isdigit():
    lo, hi = float(args[0]), float(args[1]); args = args[2:]
want = set(args)
rows = [l.split() for l in open(manifest) if l.strip()]
TS = re.compile(r"^\[(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d\.\d+)\] HICACHE_EVT (\S+) (.*)")
_c = {}
def stamp(s):
    b = s[:19]
    if b not in _c:
        _c.clear(); _c[b] = dt.datetime.strptime(b, "%Y-%m-%d %H:%M:%S").replace(tzinfo=dt.timezone.utc).timestamp()
    return _c[b] + float(s[19:])
def q(v, p):
    v = sorted(v)
    return v[min(len(v) - 1, int(p * (len(v) - 1) + 0.5))] if v else float("nan")
print("arm | dispatches launched=1: n, write-back outstanding K (p50 p90), pinned K p50, in-flight pages p50 | launched=0: same | short evictions: n, outstanding K p50; other evictions: outstanding K p50")
for lab, run, prog in rows:
    if want and lab not in want:
        continue
    with open(f"results/{run}/{prog}/client.jsonl") as f:
        t0 = json.loads(f.readline())["t_start"]
    out = 0
    sub = {}
    disp = {0: [], 1: []}
    ev = {True: [], False: []}
    for line in open(f"results/{run}/server.log", errors="replace"):
        if "HICACHE_EVT" not in line:
            continue
        m = TS.match(line)
        if not m:
            continue
        e, rest = m[2], m[3]
        if e == "h2s_submit":
            op = int(re.search(r"op=(\d+)", rest)[1]); tok = int(re.search(r"tokens=(\d+)", rest)[1])
            sub[op] = tok; out += tok
        elif e == "h2s_done":
            op = int(re.search(r"op=(\d+)", rest)[1])
            out -= sub.pop(op, 0)
        elif e == "srs_dispatch":
            t = stamp(m[1]) - t0
            if lo <= t < hi:
                d = re.search(r"pages=(\d+) waited_ms=\d+ inflight_pages=(\d+) pinned_tokens=(\d+) launched=(\d)", rest)
                disp[int(d[4])].append((out, int(d[3]), int(d[2])))
        elif e == "evict_host":
            t = stamp(m[1]) - t0
            if lo <= t < hi:
                d = re.search(r"tokens=(\d+) requested=(\d+)", rest)
                ev[int(d[1]) < int(d[2])].append(out)
    def summ(v):
        if not v:
            return f"{0:5d}     -      -     -     -"
        return f"{len(v):5d} {q([x[0] for x in v], .5)/1e3:6.0f} {q([x[0] for x in v], .9)/1e3:6.0f} {q([x[1] for x in v], .5)/1e3:5.0f} {q([x[2] for x in v], .5):5.0f}"
    print(f"{lab:14s} | {summ(disp[1])} | {summ(disp[0])} | {len(ev[True]):5d} {q(ev[True], .5)/1e3:6.0f} | {len(ev[False]):6d} {q(ev[False], .5)/1e3:6.0f}")
