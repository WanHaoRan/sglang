"""What the SSD writes are: per 10 minutes of the client clock, tokens submitted for write-back (h2s_submit) against
the KV the GPU computed for requests that finished in the window (prompt - cached, split into new tokens and history
computed again, plus output tokens). From agent_cache/:
  python3 -I -B write_sources.py <scan dir> results/campaign32/checks/vs_c28/manifest.txt"""
import collections, datetime as dt, json, re, sys
scan, manifest = sys.argv[1], sys.argv[2]
rows = [l.split() for l in open(manifest) if l.strip()]
def cached(r):
    d = r.get("cached_details") or {}
    return sum(int(d.get(k) or 0) for k in ("device", "host", "storage")) if d else int(r.get("cached_tokens") or 0)
for lab, run, prog in rows:
    s = json.load(open(f"{scan}/{lab}.json"))
    mins = {int(k): v for k, v in s["minutes"].items()}
    with open(f"results/{run}/{prog}/client.jsonl") as f:
        f.readline()
        reqs = [json.loads(l) for l in f if '"kind":"req"' in l]
    by = collections.defaultdict(lambda: [0, 0, 0, 0])
    for r in reqs:
        if r.get("ttft") is None or r.get("latency") is None:
            continue
        k = int((r["t_send"] + r["latency"]) // 600)
        c = cached(r)
        again = max(0, r["ideal_cached"] - c)
        new = max(0, r["prompt_tokens"] - max(c, r["ideal_cached"]))
        b = by[k]; b[0] += new; b[1] += again; b[2] += r["completion_tokens"]; b[3] += 1
    print(f"===== {lab}: 10 min | written M (h2s pages x 64) | computed M: new prompt, history again, output, sum | written / computed | requests done")
    for k in range(0, 12):
        w = sum(mins.get(m, {}).get("h2s_pages", 0) for m in range(10 * k, 10 * k + 10)) * 64
        b = by[k]
        tot = b[0] + b[1] + b[2]
        print(f"  {10*k:4d}-{10*k+10:<4d} | {w/1e6:6.2f} | {b[0]/1e6:6.2f} {b[1]/1e6:6.2f} {b[2]/1e6:6.2f} {tot/1e6:6.2f} | {w/max(1,tot):5.2f} | {b[3]:5d}")
