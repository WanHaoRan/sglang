"""GPU time on history computed again, re-priced per backend: reads gpu_work.py outputs (the 'again M' column) and
prices it at the fitted whole-history cost (prefill_cost_robust.out: FA3 0.0436 ms a token, Triton 0.1331 ms, the
30 K case of the full model). Prints the share of the window, requests a minute, and for FA3 the request rate the
share predicts relative to the arm with the smallest share. Usage:
  python3 -I -B gpu_share.py <ms per token> <window s> <gpu_work.out> [more files]"""
import re, sys
ms, win = float(sys.argv[1]), float(sys.argv[2])
for path in sys.argv[3:]:
    rows = []
    for line in open(path):
        m = re.match(r"^(\w+)\s+\|\s+(\d+)\s+([\d.]+)\s+\|\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)%", line)
        if m:
            rows.append((m[1], int(m[2]), float(m[3]), float(m[6])))
    print(f"== {path.split('/')[-1]} at {ms} ms a token over {win:.0f} s")
    hinted = [r for r in rows if r[0] != "hicache"]
    base = min(hinted, key=lambda r: r[3])
    bshare = base[3] * 1e6 * ms / 1e3 / win
    for lab, n, rpm, again in rows:
        share = again * 1e6 * ms / 1e3 / win
        pred = base[2] * (1 - share) / (1 - bshare) if share < 1 else float("nan")
        print(f"  {lab:10s} again {again:6.2f} M -> GPU {again * 1e6 * ms / 1e3:7.0f} s = {100 * share:5.1f} % | requests a minute {rpm:6.1f} | predicted from {base[0]}: {pred:6.1f}")
