"""SSD write-back queue: host nodes stay host-locked from h2s_submit to h2s_done (unified_radix_cache.py
write_backup_storage / _drain_backup). Per 10 minutes of the client clock: ops submitted, tokens submitted, median and
p90 submit-to-done time, I/O ms per op, tokens written per second of write I/O, and the tokens outstanding (submitted,
not done) sampled every 10 s (median, max). Also the read side for comparison: s2h_io reads, tokens, I/O ms.
From agent_cache/:
  python3 -I -B backup_queue.py results/campaign32/checks/vs_c28/manifest.txt [label ...]"""
import bisect, collections, datetime as dt, json, re, statistics as st, sys
rows = [l.split() for l in open(sys.argv[1]) if l.strip()]
want = set(sys.argv[2:])
TS = re.compile(r"^\[(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d\.\d+)\] HICACHE_EVT (h2s_submit|h2s_io|h2s_done|s2h_io) (.*)")
_c = {}
def stamp(s):
    b = s[:19]
    if b not in _c:
        _c.clear(); _c[b] = dt.datetime.strptime(b, "%Y-%m-%d %H:%M:%S").replace(tzinfo=dt.timezone.utc).timestamp()
    return _c[b] + float(s[19:])
for lab, run, prog in rows:
    if want and lab not in want:
        continue
    with open(f"results/{run}/{prog}/client.jsonl") as f:
        t0 = json.loads(f.readline())["t_start"]
    sub, done, io = {}, {}, {}
    reads = collections.defaultdict(lambda: [0, 0, 0])
    for line in open(f"results/{run}/server.log", errors="replace"):
        if "HICACHE_EVT" not in line:
            continue
        m = TS.match(line)
        if not m:
            continue
        t = stamp(m[1]) - t0
        ev, rest = m[2], m[3]
        if ev == "h2s_submit":
            op = int(re.search(r"op=(\d+)", rest)[1]); sub[op] = (t, int(re.search(r"tokens=(\d+)", rest)[1]))
        elif ev == "h2s_io":
            mm = re.search(r"op=(\d+) pages=(\d+) tokens=(\d+) ms=(\d+)", rest); io[int(mm[1])] = (int(mm[2]), int(mm[4]))
        elif ev == "h2s_done":
            op = int(re.search(r"op=(\d+)", rest)[1]); done[op] = t
        else:
            mm = re.search(r"pages=(\d+) tokens=\d+ ms=(\d+)", rest)
            b = reads[int(t // 600)]; b[0] += 1; b[1] += int(mm[1]) * 64; b[2] += int(mm[2])
    # outstanding tokens sampled every 10 s
    events = []
    for op, (ts, tok) in sub.items():
        events.append((ts, tok))
        if op in done:
            events.append((done[op], -tok))
    events.sort()
    samples = collections.defaultdict(list)
    cur, i = 0, 0
    for g in range(0, 7300, 10):
        while i < len(events) and events[i][0] <= g:
            cur += events[i][1]; i += 1
        samples[g // 600].append(cur)
    by = collections.defaultdict(list)
    for op, (ts, tok) in sub.items():
        by[int(ts // 600)].append((op, ts, tok))
    print(f"===== {lab}: ops {len(sub)}, done {len(done)}")
    print("  10 min | ops  tokens M | submit->done s p50  p90 | write ms/op p50 | write K tok/s of I/O | outstanding K tokens med  max | reads  read M  read K tok/s of I/O  read busy %")
    for k in sorted(set(by) | set(reads)):
        v = by.get(k, [])
        lat = sorted(done[op] - ts for op, ts, tok in v if op in done)
        ios = [io[op] for op, _, _ in v if op in io]
        wtok = sum(p * 64 for p, _ in ios); wms = sum(ms for _, ms in ios)
        r = reads.get(k, [0, 0, 0])
        smp = samples.get(k, [0])
        print(f"  {10*k:4d}-{10*k+10:<4d} | {len(v):5d} {sum(t for _, _, t in v)/1e6:6.2f} | {(lat[len(lat)//2] if lat else float('nan')):7.2f} {(lat[int(len(lat)*0.9)] if lat else float('nan')):7.2f} | "
              f"{(st.median(ms for _, ms in ios) if ios else float('nan')):6.0f} | {(wtok/wms if wms else float('nan')):7.1f} | {st.median(smp)/1e3:7.0f} {max(smp)/1e3:6.0f} | "
              f"{r[0]:5d} {r[1]/1e6:6.2f} {(r[1]/r[2] if r[2] else float('nan')):7.1f} {100*r[2]/1e3/600:6.1f}")
