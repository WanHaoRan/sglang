"""Host room over the run: the ec arms' ec_price lines (room, held, staged, idle, refused) by 10 minutes of the client
clock, and for every arm the evict_host lines (requested vs evicted: short evictions) and srs_dispatch launched=0 with
the pinned tokens and in-flight pages at that moment. From agent_cache/:
  python3 -I -B host_room.py results/campaign32/checks/vs_c28/manifest.txt [label ...]"""
import collections, datetime as dt, json, re, statistics as st, sys
rows = [l.split() for l in open(sys.argv[1]) if l.strip()]
want = set(sys.argv[2:])
TS = re.compile(r"^\[(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d\.\d+)\] ")
PRICE = re.compile(r"ec_price price=(\S+) refused=(\d+) idle=(\d+) excess=(\S+) room=(\d+) held=(\d+) staged=(\d+) harm_ms=(\d+)")
EH = re.compile(r"evict_host tokens=(\d+) requested=(\d+)")
DISP = re.compile(r"srs_dispatch rid=\S+ pages=(\d+) waited_ms=\d+ inflight_pages=(\d+) pinned_tokens=(\d+) launched=(\d)")
def stamp(s):
    return dt.datetime.strptime(s, "%Y-%m-%d %H:%M:%S.%f").replace(tzinfo=dt.timezone.utc).timestamp()
for lab, run, prog in rows:
    if want and lab not in want:
        continue
    with open(f"results/{run}/{prog}/client.jsonl") as f:
        t0 = json.loads(f.readline())["t_start"]
    price = collections.defaultdict(list)
    eh = collections.defaultdict(lambda: [0, 0, 0, 0])
    disp = collections.defaultdict(lambda: [0, 0, [], [], []])
    for line in open(f"results/{run}/server.log", errors="replace"):
        if "HICACHE_EVT" not in line:
            continue
        m = TS.match(line)
        if not m:
            continue
        if "ec_price" in line and (p := PRICE.search(line)):
            t = stamp(m[1]) - t0
            price[int(t // 600)].append(tuple(float(x) for x in p.groups()))
        elif "evict_host" in line and (e := EH.search(line)):
            t = stamp(m[1]) - t0
            b = eh[int(t // 600)]
            got, req = int(e[1]), int(e[2])
            b[0] += 1; b[1] += got < req; b[2] += got; b[3] += req
        elif "srs_dispatch" in line and (d := DISP.search(line)):
            t = stamp(m[1]) - t0
            b = disp[int(t // 600)]
            b[0] += 1
            if d[4] == "0":
                b[1] += 1; b[2].append(int(d[3])); b[3].append(int(d[2])); b[4].append(int(d[1]))
    print(f"===== {lab}")
    if price:
        print("  ec_price by 10 min (medians): room K, held K, staged K, idle K, refused (sum of the counter's max-min), price")
        for k in sorted(price):
            v = price[k]
            print(f"   {10*k:4d}-{10*k+10:<4d} room {st.median(x[4] for x in v)/1e3:7.0f} held {st.median(x[5] for x in v)/1e3:6.0f} staged {st.median(x[6] for x in v)/1e3:6.0f} "
                  f"idle {st.median(x[2] for x in v)/1e3:7.0f} refused {max(x[1] for x in v)-min(x[1] for x in v):5.0f} price {st.median(x[0] for x in v):.2e}")
    print("  by 10 min: evict_host lines, of them short (evicted < requested), evicted M, requested M | dispatches, launched=0, at those: pinned K median, in-flight pages median, read pages median")
    for k in sorted(set(eh) | set(disp)):
        a, b = eh[k], disp[k]
        print(f"   {10*k:4d}-{10*k+10:<4d} {a[0]:6d} {a[1]:6d} {a[2]/1e6:7.2f} {a[3]/1e6:7.2f} | {b[0]:5d} {b[1]:5d} "
              f"{(st.median(b[2])/1e3 if b[2] else float('nan')):7.0f} {(st.median(b[3]) if b[3] else float('nan')):6.0f} {(st.median(b[4]) if b[4] else float('nan')):6.0f}")
