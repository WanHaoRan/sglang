"""GPU cost of prefill on each backend, from the server logs. From agent_cache/:
  python3 -I -B prefill_cost.py <manifest> <label suffix, e.g. _fa3> [label ...]
(1) Decode-log intervals (40 decode steps each) in [60, 6600) s of the client clock: least squares
    wall = 40 * (c0 + cB * running + cT * K tokens in use) + a * prefilled tokens + b * prefill batches
             + c * prefilled tokens x (cached + new/2) K   [attention over the prefix]
    over all intervals of the listed arms; prints the coefficients and the cost of a whole 20 K and 30 K history.
(2) Cold first requests (k = 0, nothing cached) sent while the server had no queue and at most 4 running:
    TTFT by prompt size (medians), which includes the chunked prefill's interleaved decode steps."""
import bisect, collections, datetime as dt, json, re, statistics as st, sys
manifest, suffix = sys.argv[1], sys.argv[2]
want = set(sys.argv[3:])
rows = [l.split() for l in open(manifest) if l.strip() and l.split()[0].endswith(suffix)]
LINE = re.compile(r"^\[(.{23})\] (Prefill|Decode) batch")
DEC = re.compile(r"#running-req: (\d+), #token: (\d+), token usage: ([\d.]+),.*#queue-req: (\d+)")
PRE = re.compile(r"#new-seq: (\d+), #new-token: (\d+), #cached-token: (\d+)")
X, y = [], []
cold = []
for lab, run, prog in rows:
    if want and lab not in want:
        continue
    with open(f"results/{run}/{prog}/client.jsonl") as f:
        t0 = json.loads(f.readline())["t_start"]
        reqs = [json.loads(l) for l in f if '"kind":"req"' in l]
    prev, pre = None, []
    qstate = []  # (t, running, queue)
    for line in open(f"results/{run}/server.log", errors="replace"):
        if " batch" not in line or not (m := LINE.match(line)):
            continue
        t = dt.datetime.strptime(m[1], "%Y-%m-%d %H:%M:%S.%f").replace(tzinfo=dt.timezone.utc).timestamp() - t0
        if m[2] == "Prefill":
            p = PRE.search(line)
            pre.append((int(p[2]), int(p[3])))
            continue
        d = DEC.search(line)
        if not d:
            continue
        B, T, Q = int(d[1]), int(d[2]), int(d[4])
        qstate.append((t, B, Q))
        if prev is not None and 60 <= t < 6600 and t > prev:
            new = sum(a for a, _ in pre)
            att = sum(a * (c + a / 2) for a, c in pre) / 1e3
            X.append((40.0, 40.0 * B, 40.0 * T / 1e3, new, len(pre), att / 1e3))
            y.append((t - prev) * 1e3)
        prev, pre = t, []
    ts = [q[0] for q in qstate]
    for r in reqs:
        if r["k"] == 0 and r.get("ttft") is not None and int(r.get("cached_tokens") or 0) == 0 and r["prompt_tokens"] >= 2000:
            i = bisect.bisect_right(ts, r["t_send"]) - 1
            if i >= 0 and qstate[i][2] == 0 and qstate[i][1] <= 4 and r["t_send"] - qstate[i][0] < 5:
                cold.append((r["prompt_tokens"], r["ttft"]))
def solve(X, y):
    k = len(X[0])
    A = [[sum(r[i] * r[j] for r in X) for j in range(k)] for i in range(k)]
    b = [sum(r[i] * v for r, v in zip(X, y)) for i in range(k)]
    for i in range(k):
        p = A[i][i]
        A[i] = [a / p for a in A[i]]; b[i] /= p
        for j in range(k):
            if j != i:
                f = A[j][i]
                A[j] = [a - f * c for a, c in zip(A[j], A[i])]; b[j] -= f * b[i]
    return b
c = solve(X, y)
my = sum(y) / len(y)
r2 = 1 - sum((v - sum(a * b for a, b in zip(r, c))) ** 2 for r, v in zip(X, y)) / sum((v - my) ** 2 for v in y)
print(f"{suffix}: {len(y)} decode-log intervals; ms per step = {c[0]:.2f} + {c[1]:.3f} x running + {c[2]:.4f} x K tokens in use; "
      f"prefill: {c[3]*1e3:.4f} ms per K tokens... per token {c[3]:.5f} ms, {c[4]:.2f} ms a batch, {c[5]:.5f} ms per token x K prefix; R2 {r2:.3f}")
tot_new = sum(r[3] for r in X)
pre_ms = sum(c[3] * r[3] + c[4] * r[4] + c[5] * r[5] for r in X)
print(f"  prefill share of the wall time by the fit: {pre_ms / sum(y) * 100:.1f} %; prefilled {tot_new / 1e6:.1f} M tokens; mean cost {pre_ms / tot_new:.4f} ms a token")
for n in (20000, 30000):
    chunks = [(min(8192, n - s), s) for s in range(0, n, 8192)]
    ms = sum(c[3] * a + c[4] + c[5] * a * (s + a / 2) / 1e3 / 1e3 for a, s in chunks)
    print(f"  a whole {n // 1000} K history computed again (chunks of 8,192): {ms / 1e3:.3f} s, {ms / n:.4f} ms a token")
print(f"  cold first requests with no queue and <= 4 running: {len(cold)}")
for lo_, hi_ in ((2000, 8000), (8000, 14000), (14000, 20000), (20000, 26000), (26000, 40000), (40000, 70000)):
    v = [t for n, t in cold if lo_ <= n < hi_]
    nn = [n for n, t in cold if lo_ <= n < hi_]
    if v:
        print(f"    prompt {lo_ // 1000:2d}-{hi_ // 1000:<2d} K: {len(v):4d} requests, median prompt {st.median(nn) / 1e3:5.1f} K, TTFT median {st.median(v):6.3f} s, {1e3 * st.median(v) / st.median(nn):.4f} ms a token")
