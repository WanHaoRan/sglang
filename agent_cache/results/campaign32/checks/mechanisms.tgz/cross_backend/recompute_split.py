"""Where the history computed again comes from, per arm: returning requests sent before the cut, split by what the
server log shows for them: a storage read refused at dispatch for host room ("srs_dispatch ... launched=0"), the
arrival gate's refusal at its cap ("ntp_gate ... decision=capped") without such a refusal, or neither. For each
group: requests, those that got under 95 % of their history, tokens computed again and their share, TTFT mean.
From agent_cache/, after scan_run.py:
  python3 -I -B recompute_split.py <scan dir> <manifest> [cut_s]"""
import json, sys
scan, manifest = sys.argv[1], sys.argv[2]
cut = float(sys.argv[3]) if len(sys.argv) > 3 else 6600.0
rows = [l.split() for l in open(manifest) if l.strip()]
def cached(r):
    d = r.get("cached_details") or {}
    return sum(int(d.get(k) or 0) for k in ("device", "host", "storage")) if d else int(r.get("cached_tokens") or 0)
print(f"returning requests sent before {cut:.0f} s; groups: A = a read refused for host room (launched=0); B = refused at the gate's cap, no A; C = the rest")
print(f"{'arm':14s} | {'returning':>9s} {'again M':>8s} {'again %':>7s} | A: n  short  again M  share  TTFT | B: n  short  again M  share  TTFT | C: n  short  again M  share  TTFT")
for lab, run, prog in rows:
    s = json.load(open(f"{scan}/{lab}.json"))
    R = s["req"]
    with open(f"results/{run}/{prog}/client.jsonl") as f:
        f.readline()
        reqs = [json.loads(l) for l in f if '"kind":"req"' in l]
    back = [r for r in reqs if r["t_send"] < cut and r["k"] > 0 and r["ideal_cached"] > 0 and r.get("ttft") is not None]
    ideal = sum(r["ideal_cached"] for r in back)
    again = {r["rid"]: max(0, r["ideal_cached"] - cached(r)) for r in back}
    tot = sum(again.values())
    groups = {"A": [], "B": [], "C": []}
    for r in back:
        q = R.get(r["rid"], {})
        if q.get("l0", 0) > 0:
            groups["A"].append(r)
        elif "capped" in q.get("gate", []):
            groups["B"].append(r)
        else:
            groups["C"].append(r)
    out = []
    for g in "ABC":
        v = groups[g]
        a = sum(again[r["rid"]] for r in v)
        short = sum(1 for r in v if cached(r) < 0.95 * r["ideal_cached"])
        ttft = sum(r["ttft"] for r in v) / len(v) if v else float("nan")
        out.append(f"{len(v):5d} {short:5d} {a / 1e6:7.2f} {100 * a / max(1, tot):5.1f}% {ttft:5.1f}")
    print(f"{lab:14s} | {len(back):9d} {tot / 1e6:8.2f} {100 * tot / ideal:6.2f}% | " + " | ".join(out))
