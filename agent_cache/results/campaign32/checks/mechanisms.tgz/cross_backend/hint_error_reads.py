"""Do hint errors put histories on the SSD? Returning requests sent in [from_s, to_s): the arrival error against the
plan's predicted arrival ("ntp_arrive ... arr_err_ms", actual minus predicted), bucketed, and per bucket the share
that read from SSD, history computed again per request and TTFT. From agent_cache/:
  python3 -I -B hint_error_reads.py <manifest> from_s to_s [label ...]"""
import json, re, sys
manifest, lo, hi = sys.argv[1], float(sys.argv[2]), float(sys.argv[3])
want = set(sys.argv[4:])
rows = [l.split() for l in open(manifest) if l.strip()]
ARR = re.compile(r"HICACHE_EVT ntp_arrive rid=(\S+) arr_err_ms=(-?\d+)")
def cached(r):
    d = r.get("cached_details") or {}
    return sum(int(d.get(k) or 0) for k in ("device", "host", "storage")) if d else int(r.get("cached_tokens") or 0)
B = ((-1e12, -60000, "arrived > 60 s early"), (-60000, -10000, "10-60 s early"), (-10000, 10000, "within 10 s"),
     (10000, 60000, "10-60 s late"), (60000, 1e12, "> 60 s late (overdue)"))
for lab, run, prog in rows:
    if want and lab not in want:
        continue
    err = {}
    for line in open(f"results/{run}/server.log", errors="replace"):
        if "ntp_arrive" in line and (m := ARR.search(line)):
            err[m[1]] = int(m[2])
    with open(f"results/{run}/{prog}/client.jsonl") as f:
        f.readline()
        reqs = [json.loads(l) for l in f if '"kind":"req"' in l]
    back = [r for r in reqs if lo <= r["t_send"] < hi and r["k"] > 0 and r.get("ttft") is not None]
    print(f"===== {lab}: {len(back)} returning requests in [{lo:.0f}, {hi:.0f}); with a plan's arrival error: {sum(r['rid'] in err for r in back)}")
    for a, b, name in B:
        v = [r for r in back if r["rid"] in err and a <= err[r["rid"]] < b]
        if not v:
            continue
        ssd = sum(int((r.get("cached_details") or {}).get("storage") or 0) > 0 for r in v)
        again = sum(max(0, r["ideal_cached"] - cached(r)) for r in v)
        print(f"  {name:24s} {len(v):5d} ({100*len(v)/len(back):4.1f}%) | read SSD {100*ssd/len(v):5.1f}% ({ssd:4d}) | again/request {again/len(v):7.0f} | TTFT {sum(r['ttft'] for r in v)/len(v):6.2f}")
    v = [r for r in back if r["rid"] not in err]
    if v:
        ssd = sum(int((r.get("cached_details") or {}).get("storage") or 0) > 0 for r in v)
        print(f"  {'no plan':24s} {len(v):5d} ({100*len(v)/len(back):4.1f}%) | read SSD {100*ssd/len(v):5.1f}% ({ssd:4d}) | TTFT {sum(r['ttft'] for r in v)/len(v):6.2f}")
