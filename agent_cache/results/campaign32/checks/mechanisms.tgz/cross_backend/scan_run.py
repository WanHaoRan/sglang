"""One pass over a run's server.log and client.jsonl; writes a JSON summary per minute of the client clock and per
request. From agent_cache/:
  python3 -I -B scan_run.py <label> results/<run> <programs dir> <out.json>
Per minute: decode lines (running, queued, pool use), prefill lines (batches, new and cached tokens), storage reads
(s2h_io: reads, pages, I/O ms), dispatches (srs_dispatch: count, launched=0, waited ms), lookups (s2h_query: count,
with hits, hit tokens), gate decisions, re-evictions (ntp_reevict, capped=1), read starts (ntp_due case 1/2), holds,
host evictions (evict_host tokens), SSD writes (h2s_io pages, ms), device->host and host->device tokens, ec_start
decisions, retractions, cleaner passes. Per request: ReqTimeStats (entry, queue, forward, input, cached), ntp_arrive
pos/qlen, launched=0 dispatches, capped reevicts, gate decisions, storage hit tokens found. Stdlib only."""
import collections, datetime as dt, json, re, sys
label, run, programs, out = sys.argv[1:5]
with open(f"{run}/{programs}/client.jsonl") as f:
    t0 = json.loads(f.readline())["t_start"]
TS = re.compile(r"^\[(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d\.\d+)\] (.*)")
DEC = re.compile(r"Decode batch, #running-req: (\d+), #token: (\d+), token usage: ([\d.]+),.*gen throughput \(token/s\): ([\d.]+), #queue-req: (\d+)")
PRE = re.compile(r"Prefill batch, #new-seq: (\d+), #new-token: (\d+), #cached-token: (\d+), token usage: ([\d.]+), #running-req: (\d+), #queue-req: (\d+)")
RTS = re.compile(r"ReqTimeStats\(rid=(\S+?), input_len=(\d+), cached_input_len=(\d+), output_len=(\d+).*queue_duration=([\d.]+)ms, forward_duration=([\d.]+)ms, entry_time=([\d.]+)")
EVT = re.compile(r"HICACHE_EVT (\S+) (.*)")
KV = re.compile(r"(\w+)=(\S+)")
_cache = {}
def stamp(s):
    # "YYYY-mm-dd HH:MM:SS.fff" -> epoch, cached by second
    base = s[:19]
    e = _cache.get(base)
    if e is None:
        e = dt.datetime.strptime(base, "%Y-%m-%d %H:%M:%S").replace(tzinfo=dt.timezone.utc).timestamp()
        _cache.clear(); _cache[base] = e
    return e + float(s[19:])
M = lambda: collections.defaultdict(float)
minute = collections.defaultdict(M)
dec = collections.defaultdict(list)
req = collections.defaultdict(dict)
gate_ct = collections.Counter()
cleanups = []
retracts = []
for line in open(f"{run}/server.log", errors="replace"):
    m = TS.match(line)
    if not m:
        continue
    body = m[2]
    t = stamp(m[1]) - t0
    mi = int(t // 60) if t >= 0 else -1
    if body.startswith("Decode batch"):
        d = DEC.match(body)
        if d:
            dec[mi].append((int(d[1]), int(d[5]), float(d[3]), int(d[2])))
        continue
    if body.startswith("Prefill batch"):
        p = PRE.match(body)
        if p:
            b = minute[mi]
            b["pre_batches"] += 1; b["pre_seq"] += int(p[1]); b["pre_new"] += int(p[2]); b["pre_cached"] += int(p[3])
        continue
    if body.startswith("ReqTimeStats"):
        r = RTS.match(body)
        if r:
            q = req[r[1]]
            q.update(input=int(r[2]), cached=int(r[3]), out=int(r[4]), queue_s=float(r[5]) / 1e3, fwd_s=float(r[6]) / 1e3,
                     entry=float(r[7]) - t0, done=t)
        continue
    if body.startswith("NIXL L3 cleanup"):
        cleanups.append((round(t, 1), body[:160]))
        continue
    if body.startswith("KV cache pool is full. Retract"):
        retracts.append(round(t, 1))
        continue
    e = EVT.match(body)
    if not e:
        continue
    ev, rest = e[1], e[2]
    b = minute[mi]
    if ev in ("s2h_io", "srs_dispatch", "s2h_query", "ntp_gate", "ntp_reevict", "ntp_due", "ntp_hold", "ntp_arrive", "ntp_admit", "ec_start", "ntp_stage", "ntp_expire", "srs_pin_skipped", "ntp_refetch", "srs_unpin"):
        kv = dict(KV.findall(rest))
        rid = kv.get("rid")
    else:
        kv, rid = None, None
    if ev == "s2h_io":
        b["io_n"] += 1; b["io_pages"] += int(kv["pages"]); b["io_ms"] += int(kv["ms"])
        q = req[rid]; q["io_n"] = q.get("io_n", 0) + 1; q["io_pages"] = q.get("io_pages", 0) + int(kv["pages"])
        q.setdefault("io_ends", []).append(round(t, 2))
    elif ev == "srs_dispatch":
        b["disp_n"] += 1; b["disp_wait_ms"] += int(kv["waited_ms"])
        if kv["launched"] == "0":
            b["disp_l0"] += 1; b["disp_l0_pages"] += int(kv["pages"])
            q = req[rid]; q["l0"] = q.get("l0", 0) + 1
        else:
            q = req[rid]; q["l1"] = q.get("l1", 0) + 1
        b["pinned_sum"] += int(kv["pinned_tokens"]); b["inflight_sum"] += int(kv["inflight_pages"])
    elif ev == "s2h_query":
        b["q_n"] += 1
        h = int(kv["storage_hit"])
        if h > 0:
            b["q_hit"] += 1; b["q_hit_tok"] += h
        q = req[rid]; q["q_n"] = q.get("q_n", 0) + 1; q["q_hit"] = q.get("q_hit", 0) + (h > 0); q["q_hit_tok_max"] = max(q.get("q_hit_tok_max", 0), h)
    elif ev == "ntp_gate":
        dcs = kv["decision"]
        b["gate_" + dcs] += 1; gate_ct[dcs] += 1
        q = req[rid]; q.setdefault("gate", []).append(dcs)
    elif ev == "ntp_reevict":
        b["reevict"] += 1
        if kv.get("capped") == "1":
            b["reevict_capped"] += 1
            req[rid]["capped_at"] = round(t, 2)
        req[rid]["reevict_n"] = req[rid].get("reevict_n", 0) + 1
    elif ev == "ntp_due":
        b["due_case" + kv["case"]] += 1
        req[rid].setdefault("due", []).append((kv["case"], round(t, 2), int(kv.get("load_ms", 0)), int(kv.get("wait_ms", 0)), int(kv.get("backlog_pages", 0))))
    elif ev == "ntp_hold":
        b["hold"] += 1; b["hold_ms"] += int(kv.get("hold_ms", 0))
    elif ev == "ntp_arrive":
        q = req[rid]; q["arr"] = round(t, 3); q["pos"] = int(kv["pos"]); q["qlen"] = int(kv["qlen"])
    elif ev == "ntp_admit":
        q = req[rid]; q["adm_wait_ms"] = int(kv["wait_ms"]); q["adm_case"] = kv.get("case")
    elif ev == "ec_start":
        b["ec_" + kv["decision"]] += 1
    elif ev == "ntp_stage":
        b["stage"] += 1
    elif ev == "ntp_expire":
        b["expire"] += 1
    elif ev == "srs_pin_skipped":
        b["pin_skipped"] += 1
    elif ev == "ntp_refetch":
        b["refetch"] += 1
    elif ev == "srs_unpin":
        b["unpin_" + kv.get("reason", "?")] += 1
    elif ev == "evict_host":
        b["evict_host_tok"] += int(re.search(r"tokens=(\d+)", rest)[1])
    elif ev == "evict_device":
        b["evict_dev_tok"] += int(re.search(r"tokens=(\d+)", rest)[1])
    elif ev == "h2s_io":
        mm = re.search(r"pages=(\d+) tokens=(\d+) ms=(\d+)", rest)
        b["h2s_n"] += 1; b["h2s_pages"] += int(mm[1]); b["h2s_ms"] += int(mm[3])
    elif ev == "d2h_done":
        b["d2h_tok"] += int(re.search(r"tokens=(\d+)", rest)[1])
    elif ev == "h2d_done":
        b["h2d_tok"] += int(re.search(r"tokens=(\d+)", rest)[1])
    elif ev == "load_back_init":
        b["loadback_n"] += 1
mins = {}
import statistics as st
for mi in sorted(set(minute) | set(dec)):
    row = dict(minute.get(mi, {}))
    v = dec.get(mi)
    if v:
        row["running_med"] = st.median(x[0] for x in v); row["queue_med"] = st.median(x[1] for x in v)
        row["running_mean"] = st.mean(x[0] for x in v); row["queue_mean"] = st.mean(x[1] for x in v)
        row["usage_med"] = st.median(x[2] for x in v); row["dec_lines"] = len(v)
    mins[mi] = row
json.dump({"label": label, "run": run, "programs": programs, "t0": t0, "minutes": mins, "req": req, "gate": gate_ct,
           "cleanups": cleanups, "retracts": retracts}, open(out, "w"))
print(label, "minutes", len(mins), "reqs", len(req), "gate", dict(gate_ct), "cleanups", [c[0] for c in cleanups], "retracts", len(retracts))
