"""Per arm and backend, by window of send minutes: queue, running, sends, queue wait, users, reads, recompute,
refusals. From agent_cache/, after scan_run.py:
  python3 -I -B windows.py <scan dir> results/campaign32/checks/vs_c28/manifest.txt"""
import collections, json, os, statistics as st, sys
scan, manifest = sys.argv[1], sys.argv[2]
rows = [l.split() for l in open(manifest) if l.strip()]
WIN = ((0, 10), (10, 30), (30, 60), (60, 110))
ORDER = ["hicache", "oracle_v2", "jit_p50", "jit_exact", "ec_full", "ec_exact"]
def cached(r):
    d = r.get("cached_details") or {}
    return sum(int(d.get(k) or 0) for k in ("device", "host", "storage")) if d else int(r.get("cached_tokens") or 0)
data = {}
for lab, run, prog in rows:
    s = json.load(open(os.path.join(scan, lab + ".json")))
    with open(f"results/{run}/{prog}/client.jsonl") as f:
        f.readline()
        recs = [json.loads(l) for l in f]
    data[lab] = (s, recs)
def mean(v):
    v = list(v)
    return sum(v) / len(v) if v else float("nan")
print("A. by send window: queued and running (mean of per-minute medians of the decode lines), requests sent a minute, "
      "queue wait from ReqTimeStats (mean s, requests entering the queue in the window), users started in the window, in session (lanes, mean)")
hdr = f"{'arm':14s} | " + " | ".join(f"{a:>3d}-{b:<3d} q  run  sent  qwait  users live" for a, b in WIN)
print(hdr)
for base in ORDER:
    for be in ("tri", "fa3"):
        lab = f"{base}_{be}"
        s, recs = data[lab]
        mins = {int(k): v for k, v in s["minutes"].items()}
        lanes = {int(r["t"] // 60) - 1: r["live"] for r in recs if r["kind"] == "lanes"}
        reqs = [r for r in recs if r["kind"] == "req" and r["phase"] == "profile"]
        plays = [r for r in recs if r["kind"] == "play"]
        out = []
        for a, b in WIN:
            q = mean(mins[m]["queue_med"] for m in range(a, b) if m in mins and "queue_med" in mins[m])
            ru = mean(mins[m]["running_med"] for m in range(a, b) if m in mins and "running_med" in mins[m])
            sent = sum(1 for r in reqs if a * 60 <= r["t_send"] < b * 60) / (b - a)
            qw = mean(v["queue_s"] for v in s["req"].values() if "queue_s" in v and a * 60 <= v["entry"] < b * 60)
            us = sum(1 for p in plays if a * 60 <= p["start"] < b * 60)
            lv = mean(lanes[m] for m in range(a, b) if m in lanes)
            out.append(f"{q:5.1f} {ru:4.1f} {sent:5.1f} {qw:6.2f} {us:5d} {lv:4.0f}")
        print(f"{lab:14s} | " + " | ".join(out))
print()
print("B. saturation: first minute with the decode-line queue median >= 10 for 3 minutes running; >= 40 for 3 minutes; first minute 128 users in session;"
      " minutes 0-110 with queue median >= 10; users started before 6,600 s; plays started by 7,200 s")
for base in ORDER:
    for be in ("tri", "fa3"):
        lab = f"{base}_{be}"
        s, recs = data[lab]
        mins = {int(k): v for k, v in s["minutes"].items()}
        qm = [mins.get(m, {}).get("queue_med", 0) for m in range(0, 122)]
        def first(th):
            for m in range(0, 118):
                if all(qm[m + i] >= th for i in range(3)):
                    return m
            return None
        lanes = sorted((int(r["t"] // 60) - 1, r["live"]) for r in recs if r["kind"] == "lanes")
        cap = next((m for m, l in lanes if l >= 128), None)
        plays = [r for r in recs if r["kind"] == "play"]
        print(f"{lab:14s} | q>=10 from {first(10)!s:>4s} | q>=40 from {first(40)!s:>4s} | 128 in session from {cap!s:>4s} | minutes with q>=10: {sum(1 for m in range(110) if qm[m] >= 10):3d} | "
              f"users started <6600 s: {sum(1 for p in plays if p['start'] < 6600):4d} | all plays {len(plays):4d}")
print()
print("C. returning requests (k > 0) by send window: count, mean history recomputed (ideal - cached, tokens), share reading SSD, "
      "SSD reads done (s2h_io lines in the window, server clock) per returning request sent")
for base in ORDER:
    for be in ("tri", "fa3"):
        lab = f"{base}_{be}"
        s, recs = data[lab]
        mins = {int(k): v for k, v in s["minutes"].items()}
        reqs = [r for r in recs if r["kind"] == "req" and r["phase"] == "profile" and r.get("ttft") is not None]
        out = []
        for a, b in WIN:
            ret = [r for r in reqs if r["k"] > 0 and a * 60 <= r["t_send"] < b * 60]
            again = mean(max(0, r["ideal_cached"] - cached(r)) for r in ret)
            ssd = mean(int((r.get("cached_details") or {}).get("storage") or 0) > 0 for r in ret)
            io = sum(mins.get(m, {}).get("io_n", 0) for m in range(a, b))
            out.append(f"{len(ret):5d} {again:6.0f} {100 * ssd:5.1f}% {io / max(1, len(ret)):5.2f}")
        print(f"{lab:14s} | " + " | ".join(out))
print()
print("D. per window (server clock minutes): dispatches, of them launched=0 (no host room / terminated), capped re-evictions, "
      "SSD lookups with hits, host evictions M tokens, SSD writes M tokens, read thread busy %")
for base in ORDER:
    for be in ("tri", "fa3"):
        lab = f"{base}_{be}"
        s, recs = data[lab]
        mins = {int(k): v for k, v in s["minutes"].items()}
        out = []
        for a, b in WIN:
            g = lambda key: sum(mins.get(m, {}).get(key, 0) for m in range(a, b))
            out.append(f"{g('disp_n'):5.0f} {g('disp_l0'):5.0f} {g('reevict_capped'):4.0f} {g('q_hit'):5.0f} {g('evict_host_tok') / 1e6:6.1f} {g('h2s_pages') * 64 / 1e6:6.1f} {100 * g('io_ms') / 1e3 / (60 * (b - a)):5.1f}")
        print(f"{lab:14s} | " + " | ".join(out))
