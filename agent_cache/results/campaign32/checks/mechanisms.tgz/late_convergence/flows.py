"""Host-pool and SSD flows per arm, by 10-minute window of the client's clock (t = 0 at the client's t_start).
Run from agent_cache/ on the host:
  python3 -I -B <this> results/campaign32 [label ...] > <scratch>/flows_c32.out
Columns per window:
  pre M     : tokens prefilled ("Prefill batch ... #new-token")
  d2h M     : GPU -> host backups (d2h_submit tokens)
  h2s M     : host -> SSD writes submitted (h2s_submit tokens); wr busy: share of the window the write thread spent
              in h2s_io; wr K/s: its speed while busy
  backlog   : tokens submitted for SSD write and not yet acked (h2s_done), mean and max over the window's events, M
              (each such node holds a host lock until its write is acked: unevictable)
  s2h M     : SSD -> host reads landed (s2h_io tokens); rd busy, rd K/s as for writes
  evH M     : host evictions (evict_host tokens); evD M: device evictions (evict_device tokens)
  disp0/1   : read dispatches not launched / launched (srs_dispatch launched=0/1)
  pin K     : tokens pinned for landed reads (srs_pin/srs_unpin running total), mean
  queue     : waiting requests (Prefill batch #queue-req), mean; run: running requests, mean
Stdlib only."""
import calendar
import collections
import json
import re
import sys

cdir = sys.argv[1]
want = sys.argv[2:]
_sec = {}


def stamp(line):
    s = line[1:20]
    e = _sec.get(s)
    if e is None:
        e = calendar.timegm((int(s[0:4]), int(s[5:7]), int(s[8:10]), int(s[11:13]), int(s[14:16]), int(s[17:19]), 0, 0, 0))
        _sec[s] = e
    return e + int(line[21:24]) / 1000.0


N = lambda pat: re.compile(pat)
H2S_SUB = N(r"h2s_submit op=(\d+) node=\d+ tokens=(\d+)")
H2S_IO = N(r"h2s_io op=(\d+) pages=(\d+) tokens=(\d+) ms=(\d+)")
H2S_DONE = N(r"h2s_done op=(\d+) tokens=(\d+)")
S2H_IO = N(r"s2h_io rid=\S+ pages=(\d+) tokens=(\d+) ms=(\d+)")
D2H = N(r"d2h_submit nodes=\d+ tokens=(\d+)")
EVH = N(r"evict_host tokens=(\d+)")
EVD = N(r"evict_device tokens=(\d+)")
DISP = N(r"srs_dispatch .*launched=(\d)")
PIN = N(r"srs_(?:un)?pin rid=\S+ tokens=\d+ .*pinned=(\d+)")
PRE = N(r"Prefill batch, #new-seq: (\d+), #new-token: (\d+), #cached-token: (\d+), token usage: ([\d.]+), #running-req: (\d+), #queue-req: (\d+)")
H2D = N(r"h2d_submit nodes=\d+ tokens=(\d+)")

for row in open(f"{cdir}/manifest.txt"):
    label, run, programs = row.split()
    if want and label not in want:
        continue
    with open(f"results/{run}/{programs}/client.jsonl") as f:
        t0 = json.loads(f.readline())["t_start"]
    W = collections.defaultdict(collections.Counter)
    L = collections.defaultdict(lambda: collections.defaultdict(list))
    pending = {}
    backlog = 0
    pinned = 0
    with open(f"results/{run}/server.log", errors="replace") as f:
        for line in f:
            if line[0] != "[":
                continue
            if "HICACHE_EVT" not in line and "Prefill batch" not in line:
                continue
            t = stamp(line) - t0
            w = int(t // 600) if t >= 0 else -1
            c = W[w]
            if "h2s_submit" in line:
                m = H2S_SUB.search(line)
                pending[m[1]] = int(m[2])
                backlog += int(m[2])
                c["h2s"] += int(m[2])
                L[w]["backlog"].append(backlog)
            elif "h2s_io" in line:
                m = H2S_IO.search(line)
                c["h2s_io_tok"] += int(m[3])
                c["h2s_io_ms"] += int(m[4])
            elif "h2s_done" in line:
                m = H2S_DONE.search(line)
                backlog -= pending.pop(m[1], 0)
                L[w]["backlog"].append(backlog)
            elif "s2h_io" in line:
                m = S2H_IO.search(line)
                c["s2h_tok"] += int(m[1]) * 64
                c["s2h_ms"] += int(m[3])
            elif "d2h_submit" in line:
                c["d2h"] += int(D2H.search(line)[1])
            elif "evict_host" in line:
                c["evh"] += int(EVH.search(line)[1])
            elif "evict_device" in line:
                c["evd"] += int(EVD.search(line)[1])
            elif "srs_dispatch" in line:
                c["disp" + DISP.search(line)[1]] += 1
            elif "srs_pin " in line or "srs_unpin " in line:
                m = PIN.search(line)
                if m:
                    pinned = int(m[1])
                    L[w]["pin"].append(pinned)
            elif "h2d_submit" in line:
                c["h2d"] += int(H2D.search(line)[1])
            elif "Prefill batch" in line:
                m = PRE.search(line)
                if m:
                    c["pre"] += int(m[2])
                    L[w]["queue"].append(int(m[6]))
                    L[w]["run"].append(int(m[5]))
                    L[w]["usage"].append(float(m[4]))
    mean = lambda v: sum(v) / len(v) if v else float("nan")
    print(f"{label} ({run}): by 10-minute window of the client's clock")
    print(f"  {'window':>8s} {'pre M':>6s} {'d2h M':>6s} {'h2s M':>6s} {'wr busy':>7s} {'wr K/s':>6s} {'backlog mean/max M':>18s} | {'s2h M':>6s} {'rd busy':>7s} {'rd K/s':>6s} | "
          f"{'evH M':>6s} {'evD M':>6s} {'h2d M':>6s} | {'disp0':>5s} {'disp1':>5s} {'pin K':>6s} | {'queue':>5s} {'run':>5s} {'usage':>5s}")
    for w in sorted(W):
        if w < 0:
            continue
        c, l = W[w], L[w]
        print(f"  {10 * w:3d}-{10 * w + 10:<4d} {c['pre'] / 1e6:6.2f} {c['d2h'] / 1e6:6.2f} {c['h2s'] / 1e6:6.2f} {100 * c['h2s_io_ms'] / 600e3:6.1f}% "
              f"{c['h2s_io_tok'] / max(1, c['h2s_io_ms']):6.1f} {mean(l['backlog']) / 1e6:8.2f} /{max(l['backlog'], default=0) / 1e6:6.2f}    | "
              f"{c['s2h_tok'] / 1e6:6.2f} {100 * c['s2h_ms'] / 600e3:6.1f}% {c['s2h_tok'] / max(1, c['s2h_ms']):6.1f} | "
              f"{c['evh'] / 1e6:6.2f} {c['evd'] / 1e6:6.2f} {c['h2d'] / 1e6:6.2f} | {c['disp0']:5d} {c['disp1']:5d} {mean(l['pin']) / 1e3:6.0f} | "
              f"{mean(l['queue']):5.1f} {mean(l['run']):5.1f} {mean(l['usage']):5.2f}")
    print(flush=True)
