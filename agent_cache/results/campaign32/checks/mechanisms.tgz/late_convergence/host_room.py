"""Host-pool room as the pricing arms log it ("ec_price ... room= held= idle= refused="; room = host pool minus the GPU
mirror, held = read buffers in flight + pinned landed reads) and the host evictions that freed less than asked
("evict_host tokens=X requested=Y", X < Y; an eviction that frees nothing is not logged), per arm and 10-minute window
of the client's clock. Run from agent_cache/ on the host:
  python3 -I -B <this> results/campaign32 [label ...]      (ec_price exists only in ec_full and ec_exact)
Stdlib only."""
import calendar, collections, json, re, sys
cdir, want = sys.argv[1], sys.argv[2:]
def stamp(line):
    s = line[1:20]
    return calendar.timegm((int(s[0:4]), int(s[5:7]), int(s[8:10]), int(s[11:13]), int(s[14:16]), int(s[17:19]), 0, 0, 0)) + int(line[21:24]) / 1000
for row in open(f"{cdir}/manifest.txt"):
    lab, run, prog = row.split()
    if want and lab not in want:
        continue
    t0 = json.loads(open(f"results/{run}/{prog}/client.jsonl").readline())["t_start"]
    P, E = collections.defaultdict(list), collections.defaultdict(lambda: [0, 0])
    with open(f"results/{run}/server.log", errors="replace") as f:
        for line in f:
            if "ec_price" in line:
                m = re.search(r"refused=(\d+) idle=(\d+) excess=\S+ room=(\d+) held=(\d+)", line)
                P[int((stamp(line) - t0) // 600)].append(tuple(int(x) for x in m.groups()))
            elif "evict_host tokens" in line:
                m = re.search(r"tokens=(\d+) requested=(\d+)", line)
                e = E[int((stamp(line) - t0) // 600)]
                e[0] += 1
                e[1] += int(m[1]) < int(m[2])
    print(f"{lab}: window | ec_price n, refused K a step, idle K, room K, held K (means) | evict_host calls, of them short of the request")
    for w in sorted(set(P) | set(E)):
        if w < 0:
            continue
        v = P[w]
        mean = lambda i: sum(x[i] for x in v) / len(v) / 1e3 if v else float("nan")
        print(f"  {10 * w:3d}-{10 * w + 10:<4d} | {len(v):4d} {mean(0):8.0f} {mean(1):7.0f} {mean(2):7.0f} {mean(3):6.0f} | {E[w][0]:5d} {E[w][1]:5d}")
