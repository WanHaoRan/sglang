"""Requests in flight (client "lanes" records, one a minute: live users and requests in flight) around each arm's flip,
and their history (mean ideal_cached of returning requests sent within 5 minutes of the flip) against the host pool.
Run from agent_cache/ on the host:  python3 -I -B <this> results/campaign32
The flip minutes are read off transition_<label>.out (first minute with sustained refused dispatches and recompute
over 20 %): hicache 41, jit_p50 68, oracle_v2 71, ec_exact 80, jit_exact 80, ec_full 86. Stdlib only."""
import json, sys
cdir = sys.argv[1]
FLIP = {"hicache": 41, "jit_p50": 68, "oracle_v2": 71, "ec_exact": 80, "jit_exact": 80, "ec_full": 86}
for row in open(f"{cdir}/manifest.txt"):
    lab, run, prog = row.split()
    lanes, hist = {}, []
    with open(f"results/{run}/{prog}/client.jsonl") as f:
        for line in f:
            r = json.loads(line)
            if r.get("kind") == "lanes":
                lanes[int(r["t"] // 60)] = (r["live"], r["in_flight"])
            elif r.get("kind") == "req" and r["k"] > 0:
                hist.append((r["t_send"], r["ideal_cached"]))
    fm = FLIP[lab]
    v = [h for t, h in hist if (fm - 5) * 60 <= t < (fm + 5) * 60]
    mh = sum(v) / len(v)
    print(f"{lab:9s} flip ~min {fm}: in_flight(live) " + " ".join(f"{m}:{lanes.get(m, (0, 0))[1]}({lanes.get(m, (0, 0))[0]})" for m in range(fm - 20, fm + 6, 3))
          + f" | mean history {mh / 1e3:.1f} K; in-flight history at flip-3 / flip: {lanes.get(fm - 3, (0, 0))[1] * mh / 1e6:.2f} / {lanes.get(fm, (0, 0))[1] * mh / 1e6:.2f} M tokens (host pool 1.63 M)")
