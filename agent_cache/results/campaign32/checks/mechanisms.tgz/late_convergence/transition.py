"""Minute by minute through an arm's transition: the SSD device, the two storage threads, the write backlog, the
read dispatches refused, and the history computed again. Run from agent_cache/ on the host:
  python3 -I -B <this> results/campaign32 <label> [from_min to_min] > <scratch>/transition_<label>.out
Columns per minute of the client's clock:
  rdMB wrMB util wawait : iostat_vdc.log means (MB = 1000 kB of iostat), %util, w_await ms
  wr%   : write thread busy (h2s_io ms); bklgK: pending SSD writes, tokens (h2s_submit not yet h2s_done), mean K
  rdK/s : tokens a second the read thread landed (s2h_io pages x 64)
  d0 d1 : read dispatches refused (launched=0) / launched
  preK/s: tokens prefilled a second; newK/s: new KV of requests completed this minute (prompt - ideal_cached +
          completion tokens) a second; d2hK/s: GPU -> host backups a second (each is written to the SSD after)
  queue : waiting requests (Prefill batch #queue-req), mean
  adm   : returning requests admitted this minute (admission = t_send + ttft, approx.); again% : their history
          computed again, share of history
Stdlib only."""
import calendar
import collections
import json
import re
import sys

cdir, label = sys.argv[1], sys.argv[2]
lo, hi = (int(sys.argv[3]), int(sys.argv[4])) if len(sys.argv) > 4 else (0, 121)
_sec = {}


def stamp(line):
    s = line[1:20]
    e = _sec.get(s)
    if e is None:
        e = calendar.timegm((int(s[0:4]), int(s[5:7]), int(s[8:10]), int(s[11:13]), int(s[14:16]), int(s[17:19]), 0, 0, 0))
        _sec[s] = e
    return e + int(line[21:24]) / 1000.0


for row in open(f"{cdir}/manifest.txt"):
    lab, run, programs = row.split()
    if lab == label:
        break
reqs = []
with open(f"results/{run}/{programs}/client.jsonl") as f:
    t0 = json.loads(f.readline())["t_start"]
    for line in f:
        if '"kind": "req"' in line or '"kind":"req"' in line:
            reqs.append(json.loads(line))

M = collections.defaultdict(collections.Counter)
Q = collections.defaultdict(list)
B = collections.defaultdict(list)
pending, backlog = {}, 0
H2S_SUB = re.compile(r"h2s_submit op=(\d+) node=\d+ tokens=(\d+)")
with open(f"results/{run}/server.log", errors="replace") as f:
    for line in f:
        if line[0] != "[" or ("HICACHE_EVT" not in line and "Prefill batch" not in line):
            continue
        m_ = int((stamp(line) - t0) // 60)
        c = M[m_]
        if "h2s_submit" in line:
            g = H2S_SUB.search(line)
            pending[g[1]] = int(g[2])
            backlog += int(g[2])
            B[m_].append(backlog)
        elif "h2s_done" in line:
            backlog -= pending.pop(re.search(r"op=(\d+)", line)[1], 0)
            B[m_].append(backlog)
        elif "h2s_io" in line:
            c["wr_ms"] += int(re.search(r"ms=(\d+)", line)[1])
        elif "s2h_io" in line:
            c["rd_tok"] += int(re.search(r"pages=(\d+)", line)[1]) * 64
        elif "srs_dispatch" in line:
            c["d" + re.search(r"launched=(\d)", line)[1]] += 1
        elif "d2h_submit" in line:
            c["d2h"] += int(re.search(r"tokens=(\d+)", line)[1])
        elif "Prefill batch" in line:
            g = re.search(r"#new-token: (\d+).*#queue-req: (\d+)", line)
            if g:
                c["pre"] += int(g[1])
                Q[m_].append(int(g[2]))

io = collections.defaultdict(list)
hdr, t = None, None
with open(f"{cdir}/iostat_vdc.log", errors="replace") as f:
    for line in f:
        p = line.split()
        if len(p) == 3 and p[0].count("/") == 2 and p[2] in ("AM", "PM"):
            mo, d, y = (int(x) for x in p[0].split("/"))
            hh, mm, ss = (int(x) for x in p[1].split(":"))
            hh = (hh % 12) + (12 if p[2] == "PM" else 0)
            t = calendar.timegm((y, mo, d, hh, mm, ss, 0, 0, 0))
        elif p and p[0] == "Device":
            hdr = p[1:]
        elif p and p[0] == "vdc" and hdr and t is not None and t0 <= t < t0 + 7300:
            io[int((t - t0) // 60)].append(dict(zip(hdr, (float(x) for x in p[1:]))))

for r in reqs:
    if r.get("ttft") is None:
        continue
    done = int((r["t_send"] + (r.get("latency") or r["ttft"])) // 60)
    M[done]["new"] += max(0, r["prompt_tokens"] - r["ideal_cached"]) + (r.get("completion_tokens") or 0)
    if r["k"] > 0 and r["ideal_cached"] > 0:
        a = int((r["t_send"] + r["ttft"]) // 60)
        d = r.get("cached_details") or {}
        got = sum(int(d.get(x) or 0) for x in ("device", "host", "storage")) if d else int(r.get("cached_tokens") or 0)
        M[a]["adm"] += 1
        M[a]["hist"] += r["ideal_cached"]
        M[a]["again"] += max(0, r["ideal_cached"] - got)

mean = lambda v: sum(v) / len(v) if v else float("nan")
print(f"{label} ({run}): per minute of the client's clock")
print(f"  {'min':>4s} {'rdMB':>5s} {'wrMB':>5s} {'util':>5s} {'wawait':>6s} | {'wr%':>4s} {'bklgK':>6s} {'rdK/s':>6s} {'d0':>3s} {'d1':>3s} | "
      f"{'preK/s':>6s} {'newK/s':>6s} {'d2hK/s':>6s} | {'queue':>5s} {'adm':>4s} {'again%':>6s}")
for m_ in range(lo, hi):
    c, v = M[m_], io[m_]
    g = lambda k: mean([s.get(k, 0.0) for s in v])
    print(f"  {m_:4d} {g('rkB/s') / 1e3:5.0f} {g('wkB/s') / 1e3:5.0f} {g('%util'):5.1f} {g('w_await'):6.1f} | {100 * c['wr_ms'] / 60e3:4.0f} "
          f"{mean(B[m_]) / 1e3:6.0f} {c['rd_tok'] / 60e3:6.1f} {c['d0']:3d} {c['d1']:3d} | {c['pre'] / 60e3:6.1f} {c['new'] / 60e3:6.1f} {c['d2h'] / 60e3:6.1f} | "
          f"{mean(Q[m_]):5.1f} {c['adm']:4d} {100 * c['again'] / max(1, c['hist']):6.1f}")
