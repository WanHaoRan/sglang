"""Host-pool state at each storage-read dispatch: was a refused dispatch (launched=0) made with more host memory held
by pending SSD writes than a launched one? Run from agent_cache/ on the host:
  python3 -I -B <this> results/campaign32 [label ...] > <scratch>/dispatch_state_c32.out
For each srs_dispatch line: the write backlog at that moment (tokens of h2s_submit not yet h2s_done; each such node
holds a host lock until acked, and its ancestors are not host leaves), the tokens pinned for landed reads
(pinned_tokens) and the read pages in flight (inflight_pages x 64), and the shortfall of the last host eviction
logged before it in the same millisecond window (evict_host tokens < requested). Grouped by 10-minute window of the
client's clock and by launched; medians and the share of dispatches made with a backlog over 200 K tokens.
Also, per window, dispatches by backlog band (< 50 K, 50-200 K, 200-400 K, >= 400 K) with the refused share.
Stdlib only."""
import calendar
import collections
import json
import re
import sys

cdir = sys.argv[1]
want = sys.argv[2:]
_sec = {}


def stamp(line):
    s = line[1:20]
    e = _sec.get(s)
    if e is None:
        e = calendar.timegm((int(s[0:4]), int(s[5:7]), int(s[8:10]), int(s[11:13]), int(s[14:16]), int(s[17:19]), 0, 0, 0))
        _sec[s] = e
    return e + int(line[21:24]) / 1000.0


def med(v):
    v = sorted(v)
    return v[len(v) // 2] if v else float("nan")


BANDS = ((0, 50e3), (50e3, 200e3), (200e3, 400e3), (400e3, 1e12))
for row in open(f"{cdir}/manifest.txt"):
    label, run, programs = row.split()
    if want and label not in want:
        continue
    with open(f"results/{run}/{programs}/client.jsonl") as f:
        t0 = json.loads(f.readline())["t_start"]
    pending, backlog = {}, 0
    D = collections.defaultdict(lambda: collections.defaultdict(list))
    band = collections.defaultdict(lambda: collections.defaultdict(collections.Counter))
    with open(f"results/{run}/server.log", errors="replace") as f:
        for line in f:
            if line[0] != "[" or "HICACHE_EVT" not in line:
                continue
            if "h2s_submit" in line:
                m = re.search(r"op=(\d+) node=\d+ tokens=(\d+)", line)
                pending[m[1]] = int(m[2])
                backlog += int(m[2])
            elif "h2s_done" in line:
                backlog -= pending.pop(re.search(r"op=(\d+)", line)[1], 0)
            elif "srs_dispatch" in line:
                m = re.search(r"inflight_pages=(\d+) pinned_tokens=(\d+) launched=(\d)", line)
                w = int((stamp(line) - t0) // 600)
                d = D[w][m[3]]
                d.append((backlog, int(m[2]), int(m[1]) * 64))
                for i, (a, b) in enumerate(BANDS):
                    if a <= backlog < b:
                        band[w][i][m[3]] += 1
    print(f"{label} ({run}): read dispatches by window; backlog = tokens pending SSD write at the dispatch")
    print(f"  {'window':>8s} | {'refused':>7s} {'bklg med K':>10s} {'>200K':>6s} {'pin med K':>9s} {'infl med K':>10s} | {'launched':>8s} {'bklg med K':>10s} {'>200K':>6s} {'pin med K':>9s} {'infl med K':>10s} | "
          + " ".join(f"{f'{int(a / 1e3)}-{int(b / 1e3) if b < 1e11 else 'inf'}K: refused/all':>22s}" for a, b in BANDS))
    for w in sorted(D):
        r, l = D[w]["0"], D[w]["1"]
        f = lambda v, i: med([x[i] for x in v]) / 1e3
        g = lambda v: 100 * sum(x[0] > 200e3 for x in v) / len(v) if v else float("nan")
        print(f"  {10 * w:3d}-{10 * w + 10:<4d} | {len(r):7d} {f(r, 0):10.0f} {g(r):5.0f}% {f(r, 1):9.0f} {f(r, 2):10.0f} | {len(l):8d} {f(l, 0):10.0f} {g(l):5.0f}% {f(l, 1):9.0f} {f(l, 2):10.0f} | "
              + " ".join(f"{band[w][i]['0']:>12d}/{band[w][i]['0'] + band[w][i]['1']:<9d}" for i in range(len(BANDS))))
    tot = collections.defaultdict(collections.Counter)
    for w in band:
        for i in band[w]:
            tot[i].update(band[w][i])
    print("  whole run, refused share by backlog band: " + ", ".join(
        f"{int(a / 1e3)}-{int(b / 1e3) if b < 1e11 else 'inf'} K: {tot[i]['0']} of {tot[i]['0'] + tot[i]['1']} ({100 * tot[i]['0'] / max(1, tot[i]['0'] + tot[i]['1']):.0f} %)"
        for i, (a, b) in enumerate(BANDS)))
    print(flush=True)
