"""History delivery shares of returning requests by send-time band, and SSD writes against the SSD's size.
Run from agent_cache/ on the host:  python3 -I -B <this> results/campaign32 <flows output>
Shares of the history (ideal_cached) delivered from GPU, host, SSD and computed again, for returning requests sent in
minutes 30-60, 60-90 and 90-110; returning requests a minute; mean history. Then the total of h2s_submit tokens of the
run (from the flows output), in bytes (98,304 B a token, the d2h_submit lines' bytes / tokens), against the volume
(2,398,538,480 1K-blocks by df of /mnt/ssd, ext4) and its 90 % cleaner mark, and the cleaner passes (235.84 GiB each)."""
import json, re, sys
cdir, flows = sys.argv[1], sys.argv[2]
BANDS = ((30, 60), (60, 90), (90, 110))
h2s, cur = {}, None
for line in open(flows):
    m = re.match(r"^(\w+) \(", line)
    if m:
        cur = m[1]; h2s[cur] = 0.0; continue
    p = line.split()
    if cur and len(p) > 5 and re.match(r"^\d+-\d+$", p[0]):
        h2s[cur] += float(p[3]) * 1e6
VOL = 2398538480 * 1024
TOK = 98304
for row in open(f"{cdir}/manifest.txt"):
    lab, run, prog = row.split()
    acc = {b: [0, 0, 0, 0, 0, 0] for b in BANDS}
    with open(f"results/{run}/{prog}/client.jsonl") as f:
        for line in f:
            if '"kind": "req"' not in line and '"kind":"req"' not in line:
                continue
            r = json.loads(line)
            if r["k"] <= 0 or r["ideal_cached"] <= 0 or r.get("ttft") is None:
                continue
            mnt = r["t_send"] / 60
            for b in BANDS:
                if b[0] <= mnt < b[1]:
                    d = r.get("cached_details") or {}
                    dev, host, ssd = (int(d.get(x) or 0) for x in ("device", "host", "storage"))
                    if not d:
                        dev = int(r.get("cached_tokens") or 0)
                    a = acc[b]
                    a[0] += 1; a[1] += r["ideal_cached"]; a[2] += min(dev, r["ideal_cached"]); a[3] += host; a[4] += ssd
                    a[5] += max(0, r["ideal_cached"] - dev - host - ssd)
    out = []
    for b in BANDS:
        n, H, dv, ho, ss, ag = acc[b]
        out.append(f"min {b[0]}-{b[1]}: {n / (b[1] - b[0]):.0f}/min, hist {H / max(1, n) / 1e3:.1f} K, GPU/host/SSD/again {100 * dv / H:.0f}/{100 * ho / H:.0f}/{100 * ss / H:.0f}/{100 * ag / H:.0f} %")
    print(f"{lab:9s} " + " | ".join(out))
    w = h2s.get(lab, 0.0)
    print(f"          SSD writes of the run: {w / 1e6:.1f} M tokens = {w * TOK / 1e12:.2f} TB; volume {VOL / 1e12:.2f} TB, 90 % = {0.9 * VOL / TOK / 1e6:.1f} M tokens; "
          f"writes / volume = {w * TOK / VOL:.2f}")
