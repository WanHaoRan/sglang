"""The SSD (vdc) as iostat saw it, per arm and 10-minute window of the client's clock.
Run from agent_cache/ on the host:
  python3 -I -B <this> results/campaign32 > <scratch>/iostat_c32.out
iostat_vdc.log holds 10 s samples ("iostat -dxt vdc 10"); its clock is the container's, UTC (checked against the run
folders' names). Each sample is assigned to the arm whose client ran then (t_start to t_start + 7,230 s).
Columns: read MB/s, write MB/s, sum, discard MB/s, reads/s, read size KB, r_await ms, w_await ms, queue depth (aqu-sz),
%util; means over the window's samples; 'sum GB/s max' is the largest 10 s sample of read + write. Stdlib only."""
import calendar
import collections
import json
import sys

cdir = sys.argv[1]
arms = []
for row in open(f"{cdir}/manifest.txt"):
    label, run, programs = row.split()
    with open(f"results/{run}/{programs}/client.jsonl") as f:
        arms.append((label, json.loads(f.readline())["t_start"]))

samples = []
hdr = None
t = None
with open(f"{cdir}/iostat_vdc.log", errors="replace") as f:
    for line in f:
        p = line.split()
        if len(p) == 3 and p[0].count("/") == 2 and p[2] in ("AM", "PM"):
            mo, d, y = (int(x) for x in p[0].split("/"))
            hh, mm, ss = (int(x) for x in p[1].split(":"))
            if p[2] == "PM" and hh != 12:
                hh += 12
            if p[2] == "AM" and hh == 12:
                hh = 0
            t = calendar.timegm((y, mo, d, hh, mm, ss, 0, 0, 0))
        elif p and p[0] == "Device":
            hdr = p[1:]
        elif p and p[0] == "vdc" and hdr and t is not None:
            samples.append((t, dict(zip(hdr, (float(x) for x in p[1:])))))

for label, t0 in arms:
    W = collections.defaultdict(list)
    for t, s in samples:
        if t0 <= t < t0 + 7230:
            W[int((t - t0) // 600)].append(s)
    print(f"{label}: {sum(len(v) for v in W.values())} samples")
    print(f"  {'window':>8s} {'rd MB/s':>8s} {'wr MB/s':>8s} {'sum':>7s} {'max':>7s} {'disc MB/s':>9s} {'r/s':>6s} {'rq KB':>6s} {'r_await':>7s} {'w_await':>7s} {'aqu':>5s} {'%util':>6s}")
    for w in sorted(W):
        v = W[w]
        m = lambda k: sum(s.get(k, 0.0) for s in v) / len(v)
        mx = max((s.get("rkB/s", 0) + s.get("wkB/s", 0)) for s in v) / 1e3
        print(f"  {10 * w:3d}-{10 * w + 10:<4d} {m('rkB/s') / 1e3:8.0f} {m('wkB/s') / 1e3:8.0f} {(m('rkB/s') + m('wkB/s')) / 1e3:7.0f} {mx:7.0f} {m('dkB/s') / 1e3:9.1f} "
              f"{m('r/s'):6.0f} {m('rareq-sz'):6.0f} {m('r_await'):7.1f} {m('w_await'):7.1f} {m('aqu-sz'):5.1f} {m('%util'):6.1f}")
    print()
