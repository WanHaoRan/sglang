"""Campaign 32 (or 28): what became of the SSD history of returning requests that computed history again.
Run from agent_cache/ on the host:
  python3 -I -B <this> results/campaign32 [label ...] > <scratch>/req_fate_c32.out
Per arm and 10-minute window of send time: returning requests (k > 0, ideal_cached > 0, answered), those that
computed history again ("comp": ideal_cached - delivered >= 1,024 tokens and >= 5 % of the history), and for those
the state, at admission, of the newest read whose lookup found pages on the SSD (s2h_query storage_hit > 0):
  no_hit   : no lookup of the request found pages (no_look: of them, no lookup at all)
  found    : found, no park line before admission (hicache: no read scheduler, so found = not landed by admission)
  parked   : parked, not dispatched by admission
  refused  : dispatched with launched=0 (host allocation failed or the operation was terminated), nothing after
  inflight : dispatched with launched=1, no s2h_io line by admission
  landed   : s2h_io before admission, so the read landed and its pages were gone or short at admission
'capped' counts requests whose last gate decision before admission was "capped" (allowance used up); 'shrank' those
with a "device prefix shrank before admission" line; 'l_any' those where any read landed before admission.
Server times are UTC; admission = ReqTimeStats entry_time + queue_duration. Also, minutes 60-110: tokens computed again by state, and how many of them the request's own lookup had found
on the SSD (min(storage_hit, computed again)). Stdlib only."""
import calendar
import collections
import json
import re
import sys

cdir = sys.argv[1]
want = sys.argv[2:]
MIN_RECOMP = 1024
MIN_SHARE = 0.05
_sec = {}


def stamp(line):
    s = line[1:20]
    e = _sec.get(s)
    if e is None:
        e = calendar.timegm((int(s[0:4]), int(s[5:7]), int(s[8:10]), int(s[11:13]), int(s[14:16]), int(s[17:19]), 0, 0, 0))
        _sec[s] = e
    return e + int(line[21:24]) / 1000.0


RID = re.compile(r"(?:rid|req)=([A-Za-z0-9_]+-c\d+-t\d+)")
KV = re.compile(r"(\w+)=([^\s,)]+)")
RTS = re.compile(r"ReqTimeStats\(rid=(\S+), input_len=(\d+), cached_input_len=(\d+).*queue_duration=([\d.]+)ms.*entry_time=([\d.]+)")
KINDS = ("s2h_query", "srs_park", "srs_dispatch", "s2h_io", "ntp_gate")


def parse(run):
    ev = collections.defaultdict(list)
    rts = {}
    with open(f"results/{run}/server.log", errors="replace") as f:
        for line in f:
            if line[0] != "[":
                continue
            if "ReqTimeStats(" in line:
                m = RTS.search(line)
                if m:
                    rts[m[1]] = (int(m[2]), int(m[3]), float(m[5]) + float(m[4]) / 1e3, float(m[5]))
                continue
            if "HICACHE_EVT" in line:
                i = line.find("HICACHE_EVT ") + 12
                kind = line[i:line.find(" ", i)]
                if kind not in KINDS:
                    continue
            elif "device prefix shrank" in line:
                kind = "shrank"
            else:
                continue
            m = RID.search(line)
            if m:
                ev[m[1]].append((stamp(line), kind, dict(KV.findall(line[line.find("]") + 1:]))))
    return ev, rts


def fate(events, t_adm):
    newest, landed_any, last_gate, lookups, shrank, found = None, False, None, 0, False, 0
    for t, kind, kv in events:
        if t > t_adm + 0.002:
            break
        if kind == "ntp_gate":
            last_gate = kv.get("decision")
        elif kind == "shrank":
            shrank = True
        elif kind == "s2h_query":
            lookups += 1
            if int(kv.get("storage_hit", 0)) > 0:
                newest = "found"
                found = max(found, int(kv["storage_hit"]))
        elif newest is None:
            continue
        elif kind == "srs_park":
            newest = "parked"
        elif kind == "srs_dispatch":
            newest = "inflight" if kv.get("launched") == "1" else "refused"
        elif kind == "s2h_io":
            newest, landed_any = "landed", True
    return newest or "no_hit", landed_any, last_gate, lookups, shrank, found


STATES = ("no_hit", "found", "parked", "refused", "inflight", "landed")
for row in open(f"{cdir}/manifest.txt"):
    label, run, programs = row.split()
    if want and label not in want:
        continue
    ev, rts = parse(run)
    for k in ev:
        ev[k].sort(key=lambda e: e[0])
    reqs = []
    with open(f"results/{run}/{programs}/client.jsonl") as f:
        for line in f:
            if '"kind": "req"' in line or '"kind":"req"' in line:
                reqs.append(json.loads(line))
    win = collections.defaultdict(collections.Counter)
    tok = collections.defaultdict(collections.Counter)
    for r in reqs:
        if r["k"] <= 0 or r["ideal_cached"] <= 0 or r.get("ttft") is None:
            continue
        w = int(r["t_send"] // 600)
        d = r.get("cached_details") or {}
        got = sum(int(d.get(x) or 0) for x in ("device", "host", "storage")) if d else int(r.get("cached_tokens") or 0)
        again = max(0, r["ideal_cached"] - got)
        c, t = win[w], tok[w]
        c["returning"] += 1
        t["history"] += r["ideal_cached"]
        t["again"] += again
        if again < MIN_RECOMP or again < MIN_SHARE * r["ideal_cached"]:
            continue
        c["computed"] += 1
        rid = r["rid"]
        if rid not in rts:
            c["no_stats"] += 1
            continue
        st, landed_any, last_gate, lookups, shrank, found = fate(ev.get(rid, []), rts[rid][2])
        t["found_" + st] += min(found, again)
        c[st] += 1
        t[st] += again
        c["capped"] += last_gate == "capped"
        c["shrank"] += shrank
        c["l_any"] += landed_any
        c["no_look"] += st == "no_hit" and lookups == 0
        c[f"{st}|capped"] += last_gate == "capped"
    print(f"{label} ({run}): returning requests by 10-minute window of send time; comp = computed history again "
          f"(>= {MIN_RECOMP} tokens and >= {100 * MIN_SHARE:.0f} % of it), split by its newest found read's state at admission")
    print(f"  {'window':>8s} {'return':>6s} {'again%':>6s} {'comp':>5s} | " + " ".join(f"{s:>8s}" for s in STATES)
          + f" | {'no_look':>7s} {'capped':>6s} {'shrank':>6s} {'l_any':>5s} | again M tokens: " + " ".join(f"{s:>7s}" for s in STATES))
    for w in sorted(win):
        c, t = win[w], tok[w]
        print(f"  {10 * w:3d}-{10 * w + 10:<4d} {c['returning']:6d} {100 * t['again'] / max(1, t['history']):6.1f} {c['computed']:5d} | "
              + " ".join(f"{c[s]:8d}" for s in STATES)
              + f" | {c['no_look']:7d} {c['capped']:6d} {c['shrank']:6d} {c['l_any']:5d} | " + " ".join(f"{t[s] / 1e6:7.2f}" for s in STATES))
    tot = collections.Counter()
    for w in win:
        if 6 <= w < 11:
            tot.update(win[w])
    ft = collections.Counter()
    for w in tok:
        if 6 <= w < 11:
            ft.update(tok[w])
    print("  minutes 60-110, M tokens computed again / of them found on the SSD by the request's own lookup: "
          + ", ".join(f"{s} {ft[s] / 1e6:.2f} / {ft['found_' + s] / 1e6:.2f}" for s in STATES))
    print(f"  minutes 60-110: computed {tot['computed']} of {tot['returning']} returning; " + ", ".join(f"{s} {tot[s]} (capped {tot[s + '|capped']})" for s in STATES)
          + f"; no stats {tot['no_stats']}")
    print(flush=True)
