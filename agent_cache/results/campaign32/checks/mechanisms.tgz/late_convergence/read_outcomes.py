"""What the launched SSD reads delivered, per arm and 10-minute window of the client's clock.
Run from agent_cache/ on the host:
  python3 -I -B <this> results/campaign32 [label ...] > <scratch>/read_outcomes_c32.out
For each read that reached the read thread (s2h_io line): pages read against the pages its lookup found (the last
srs_park of the request before it: shortened = the host allocation gave fewer pages, the memory-pressure fallback),
and tokens completed against pages x 64 (short = pages the SSD no longer had, e.g. after a cleaner pass; NIXL logs
"failed to retrieve page"). Also the cleaner passes ("NIXL L3 cleanup") on the client's clock.
hicache has no read scheduler (no srs_park), so only the completed share is shown for it. Stdlib only."""
import calendar
import collections
import json
import re
import sys

cdir = sys.argv[1]
want = sys.argv[2:]
_sec = {}


def stamp(line):
    s = line[1:20]
    e = _sec.get(s)
    if e is None:
        e = calendar.timegm((int(s[0:4]), int(s[5:7]), int(s[8:10]), int(s[11:13]), int(s[14:16]), int(s[17:19]), 0, 0, 0))
        _sec[s] = e
    return e + int(line[21:24]) / 1000.0


for row in open(f"{cdir}/manifest.txt"):
    label, run, programs = row.split()
    if want and label not in want:
        continue
    with open(f"results/{run}/{programs}/client.jsonl") as f:
        t0 = json.loads(f.readline())["t_start"]
    park = {}
    W = collections.defaultdict(collections.Counter)
    cleaner = []
    failed = collections.Counter()
    with open(f"results/{run}/server.log", errors="replace") as f:
        for line in f:
            if line[0] != "[":
                continue
            if "NIXL L3 cleanup" in line:
                cleaner.append(round(stamp(line) - t0))
                continue
            if "failed to retrieve page" in line:
                failed[int((stamp(line) - t0) // 600)] += 1
                continue
            if "HICACHE_EVT" not in line:
                continue
            if " srs_park " in line:
                m = re.search(r"rid=(\S+) pages=(\d+)", line)
                park[m[1]] = int(m[2])
            elif " s2h_io " in line:
                m = re.search(r"rid=(\S+) pages=(\d+) tokens=(\d+)", line)
                w = int((stamp(line) - t0) // 600)
                c = W[w]
                pages, done = int(m[2]), int(m[3])
                c["reads"] += 1
                c["pages"] += pages
                c["done_tok"] += done
                if done < pages * 64:
                    c["short_done"] += 1
                    c["missing_tok"] += pages * 64 - done
                found = park.pop(m[1], None)
                if found is not None:
                    c["with_park"] += 1
                    c["found_pages"] += found
                    if pages < found:
                        c["shortened"] += 1
                        c["cut_tok"] += (found - pages) * 64
    print(f"{label} ({run}): cleaner passes at {cleaner} s of the client's clock")
    print(f"  {'window':>8s} {'reads':>6s} {'read M':>7s} | {'short done':>10s} {'missing M':>9s} {'fail lines':>10s} | {'parked':>6s} {'shortened':>9s} {'cut M':>6s}")
    for w in sorted(W):
        c = W[w]
        print(f"  {10 * w:3d}-{10 * w + 10:<4d} {c['reads']:6d} {c['pages'] * 64 / 1e6:7.2f} | {c['short_done']:10d} {c['missing_tok'] / 1e6:9.2f} {failed[w]:10d} | "
              f"{c['with_park']:6d} {c['shortened']:9d} {c['cut_tok'] / 1e6:6.2f}")
    print(flush=True)
