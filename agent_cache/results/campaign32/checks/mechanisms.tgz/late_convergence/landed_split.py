"""Requests that computed history again although their newest read landed before admission: was that read cut
short by the host allocation (pages read < pages its park asked for, the memory-pressure fallback), and how much of
the computed-again history the cut explains. Run from agent_cache/ on the host:
  python3 -I -B <this> results/campaign32 [label ...]
Returning requests sent in minutes 60-110; computed again = >= 1,024 tokens and >= 5 % of the history. Stdlib only."""
import calendar, collections, json, re, sys
cdir, want = sys.argv[1], sys.argv[2:]
_sec = {}
def stamp(line):
    s = line[1:20]
    e = _sec.get(s)
    if e is None:
        e = calendar.timegm((int(s[0:4]), int(s[5:7]), int(s[8:10]), int(s[11:13]), int(s[14:16]), int(s[17:19]), 0, 0, 0)); _sec[s] = e
    return e + int(line[21:24]) / 1000.0
RID = re.compile(r"(?:rid|req)=([A-Za-z0-9_]+-c\d+-t\d+)")
RTS = re.compile(r"ReqTimeStats\(rid=(\S+), input_len=(\d+), cached_input_len=(\d+).*queue_duration=([\d.]+)ms.*entry_time=([\d.]+)")
for row in open(f"{cdir}/manifest.txt"):
    lab, run, prog = row.split()
    if want and lab not in want:
        continue
    ev, adm = collections.defaultdict(list), {}
    with open(f"results/{run}/server.log", errors="replace") as f:
        for line in f:
            if line[0] != "[":
                continue
            if "ReqTimeStats(" in line:
                m = RTS.search(line)
                if m:
                    adm[m[1]] = float(m[5]) + float(m[4]) / 1e3
                continue
            if "HICACHE_EVT" not in line:
                continue
            for k in ("srs_park", "srs_dispatch", "s2h_query", "s2h_io"):
                if f" {k} " in line:
                    m = RID.search(line)
                    if m:
                        ev[m[1]].append((stamp(line), k, line))
                    break
    c = collections.Counter()
    with open(f"results/{run}/{prog}/client.jsonl") as f:
        for line in f:
            if '"kind": "req"' not in line and '"kind":"req"' not in line:
                continue
            r = json.loads(line)
            if r["k"] <= 0 or r["ideal_cached"] <= 0 or r.get("ttft") is None or not (3600 <= r["t_send"] < 6600):
                continue
            d = r.get("cached_details") or {}
            got = sum(int(d.get(x) or 0) for x in ("device", "host", "storage")) if d else int(r.get("cached_tokens") or 0)
            again = r["ideal_cached"] - got
            if again < 1024 or again < 0.05 * r["ideal_cached"] or r["rid"] not in adm:
                continue
            es = sorted(e for e in ev.get(r["rid"], []) if e[0] <= adm[r["rid"]] + 0.002)
            newest, park_pages, cut = None, None, 0
            for t, k, l in es:
                if k == "s2h_query" and "storage_hit=0" not in l:
                    newest, park_pages = "found", None
                elif k == "srs_park" and newest:
                    newest, park_pages = "parked", int(re.search(r"pages=(\d+)", l)[1])
                elif k == "srs_dispatch" and newest:
                    newest = "inflight" if "launched=1" in l else "refused"
                elif k == "s2h_io" and newest:
                    pages = int(re.search(r"pages=(\d+)", l)[1])
                    newest = "landed"
                    cut = max(0, (park_pages - pages) * 64) if park_pages is not None else 0
            if newest != "landed":
                continue
            c["landed"] += 1
            c["again"] += again
            if cut > 0:
                c["cut_reads"] += 1
                c["cut_explains"] += min(cut, again)
    print(f"{lab}: {c['landed']} computed requests with their newest read landed (sent 60-110 min), {c['again'] / 1e6:.2f} M tokens computed again; "
          f"newest read cut short by the host allocation: {c['cut_reads']} ({100 * c['cut_reads'] / max(1, c['landed']):.0f} %), "
          f"the cut covers {c['cut_explains'] / 1e6:.2f} M ({100 * c['cut_explains'] / max(1, c['again']):.0f} %) of their computed-again history; the rest was gone from memory by admission")
