"""Requests whose newest found read was refused at dispatch (launched=0) and that computed history again: how many
refused dispatches each had, how long before admission the last refusal came, and what the gate said after it.
Run from agent_cache/ on the host:  python3 -I -B <this> results/campaign32 [label ...]
Returning requests sent in minutes 60-110; computed again = >= 1,024 tokens and >= 5 % of the history (as
req_fate.py). Admission = ReqTimeStats entry_time + queue_duration. Stdlib only."""
import calendar, collections, json, re, sys
cdir, want = sys.argv[1], sys.argv[2:]
_sec = {}
def stamp(line):
    s = line[1:20]
    e = _sec.get(s)
    if e is None:
        e = calendar.timegm((int(s[0:4]), int(s[5:7]), int(s[8:10]), int(s[11:13]), int(s[14:16]), int(s[17:19]), 0, 0, 0)); _sec[s] = e
    return e + int(line[21:24]) / 1000.0
RID = re.compile(r"(?:rid|req)=([A-Za-z0-9_]+-c\d+-t\d+)")
RTS = re.compile(r"ReqTimeStats\(rid=(\S+), input_len=(\d+), cached_input_len=(\d+).*queue_duration=([\d.]+)ms.*entry_time=([\d.]+)")
def q(v, p):
    v = sorted(v); return v[min(len(v) - 1, int(p * len(v)))] if v else float("nan")
for row in open(f"{cdir}/manifest.txt"):
    lab, run, prog = row.split()
    if want and lab not in want:
        continue
    ev, adm = collections.defaultdict(list), {}
    with open(f"results/{run}/server.log", errors="replace") as f:
        for line in f:
            if line[0] != "[":
                continue
            if "ReqTimeStats(" in line:
                m = RTS.search(line)
                if m:
                    adm[m[1]] = float(m[5]) + float(m[4]) / 1e3
                continue
            if "HICACHE_EVT" not in line:
                continue
            for k in ("srs_dispatch", "s2h_query", "ntp_gate", "s2h_io"):
                if f" {k} " in line:
                    m = RID.search(line)
                    if m:
                        ev[m[1]].append((stamp(line), k, line))
                    break
    n_ref, last_gap, gate_after, waited = collections.Counter(), [], collections.Counter(), []
    tot = 0
    with open(f"results/{run}/{prog}/client.jsonl") as f:
        for line in f:
            if '"kind": "req"' not in line and '"kind":"req"' not in line:
                continue
            r = json.loads(line)
            if r["k"] <= 0 or r["ideal_cached"] <= 0 or r.get("ttft") is None or not (3600 <= r["t_send"] < 6600):
                continue
            d = r.get("cached_details") or {}
            got = sum(int(d.get(x) or 0) for x in ("device", "host", "storage")) if d else int(r.get("cached_tokens") or 0)
            again = r["ideal_cached"] - got
            if again < 1024 or again < 0.05 * r["ideal_cached"] or r["rid"] not in adm:
                continue
            t_adm = adm[r["rid"]]
            es = sorted(e for e in ev.get(r["rid"], []) if e[0] <= t_adm + 0.002)
            newest, refusals, t_last = None, 0, None
            for t, k, line in es:
                if k == "s2h_query" and "storage_hit=0" not in line:
                    newest = "found"
                elif k == "srs_dispatch" and newest:
                    if "launched=0" in line:
                        newest, refusals, t_last = "refused", refusals + 1, t
                    else:
                        newest = "inflight"
                elif k == "s2h_io" and newest:
                    newest = "landed"
            if newest != "refused":
                continue
            tot += 1
            n_ref[min(refusals, 4)] += 1
            last_gap.append(t_adm - t_last)
            after = [re.search(r"decision=(\w+)", l)[1] for t, k, l in es if k == "ntp_gate" and t > t_last]
            gate_after[after[-1] if after else "none"] += 1
    print(f"{lab}: {tot} requests computed with their newest read refused (sent 60-110 min); refused dispatches each "
          f"{dict(sorted(n_ref.items()))} (4 = 4 or more); last refusal to admission: median {q(last_gap, 0.5):.1f} s, p10 {q(last_gap, 0.1):.1f}, p90 {q(last_gap, 0.9):.1f}; "
          f"last gate decision after the last refusal: {dict(gate_after)}")
