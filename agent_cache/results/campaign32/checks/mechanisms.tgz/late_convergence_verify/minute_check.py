"""Reviewer's minute-by-minute series. Usage (from agent_cache/): python3 -I -B minute_check.py <campaign dir> <pkl> <from_min> <to_min>
Per minute of the client's clock: iostat (rd, wr in 1,000 kB/s, %util, w_await, r_await), pending SSD-write tokens (time-weighted
mean, max), read dispatches launched/refused, read-thread busy share (s2h_io ms), write-thread busy share, prefill new tokens/s,
d2h tokens/s, returning requests ADMITTED that minute (by ReqTimeStats admission) and the share of their history recomputed,
queue (Prefill batch #queue-req, mean), running (Decode batch, mean), GPU usage."""
import calendar
import collections
import json
import pickle
import sys

cdir, path, m0, m1 = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4])
d = pickle.load(open(path, "rb"))
t0 = d["t0"]
# iostat
io = collections.defaultdict(list)
hdr = None
t = None
for line in open(f"{cdir}/iostat_vdc.log", errors="replace"):
    p = line.split()
    if len(p) == 3 and p[0].count("/") == 2 and p[2] in ("AM", "PM"):
        mo, dd, y = map(int, p[0].split("/"))
        hh, mm, ss = map(int, p[1].split(":"))
        hh = hh % 12 + (12 if p[2] == "PM" else 0)
        t = calendar.timegm((y, mo, dd, hh, mm, ss, 0, 0, 0))
    elif p and p[0] == "Device":
        hdr = p[1:]
    elif p and p[0] == "vdc" and hdr and t is not None:
        rel = t - 5 - t0
        if 0 <= rel < 7300:
            io[int(rel // 60)].append(dict(zip(hdr, map(float, p[1:]))))
M = collections.defaultdict(collections.Counter)
L = collections.defaultdict(lambda: collections.defaultdict(list))
pending, backlog, last = {}, 0, None
area = collections.Counter()
bmax = collections.Counter()
for t, kind, kv in d["ev"]:
    if t < 0:
        continue
    if last is not None:
        a = last
        while a < t:
            mm_ = int(a // 60)
            b = min(t, (mm_ + 1) * 60)
            area[mm_] += backlog * (b - a)
            a = b
    last = t
    m = int(t // 60)
    c = M[m]
    if kind == "h2s_submit":
        pending[kv["op"]] = kv["tokens"]
        backlog += kv["tokens"]
    elif kind == "h2s_done":
        backlog -= pending.pop(kv["op"], 0)
    elif kind == "h2s_io":
        c["wr_ms"] += kv["ms"]
    elif kind == "s2h_io":
        c["rd_ms"] += kv["ms"]
        c["rd_tok"] += kv["pages"] * 64
    elif kind == "srs_dispatch":
        c["d1" if kv.get("launched") == 1 else "d0"] += 1
    elif kind == "PRE":
        c["pre"] += kv["new"]
        L[m]["queue"].append(kv["queue"])
    elif kind == "DEC":
        L[m]["run"].append(kv["run"])
        L[m]["usage"].append(kv["usage"])
    elif kind == "d2h_submit":
        c["d2h"] += kv["tokens"]
    bmax[m] = max(bmax[m], backlog)
# admissions from client + ReqTimeStats
rts = d["rts"]
with open(f"results/{d['run']}/{d['programs']}/client.jsonl") as f:
    f.readline()
    for line in f:
        r = json.loads(line)
        if r.get("kind") != "req" or r["k"] <= 0 or r["ideal_cached"] <= 0 or r.get("ttft") is None:
            continue
        s = rts.get(r["rid"])
        if not s:
            continue
        m = int((s["entry"] + s["queue_s"]) // 60)
        cd = r.get("cached_details") or {}
        got = sum(int(cd.get(x) or 0) for x in ("device", "host", "storage")) if cd else int(r.get("cached_tokens") or 0)
        M[m]["adm"] += 1
        M[m]["hist"] += r["ideal_cached"]
        M[m]["again"] += max(0, r["ideal_cached"] - got)
mean = lambda v: sum(v) / len(v) if v else float("nan")
print(f"{d['label']} ({d['run']}) minutes {m0}-{m1}")
print(f"  {'min':>3s} {'rd':>5s} {'wr':>5s} {'util':>5s} {'w_aw':>5s} | {'pendK':>5s} {'pmaxK':>5s} | {'d1':>3s} {'d0':>3s} {'rdbz':>4s} {'wrbz':>4s} | {'preK/s':>6s} {'d2hK/s':>6s} | {'adm':>4s} {'again%':>6s} | {'queue':>5s} {'run':>5s} {'usage':>5s}")
for m in range(m0, m1):
    v = io.get(m, [])
    g = lambda k: mean([s[k] for s in v])
    c, l = M[m], L[m]
    print(f"  {m:3d} {g('rkB/s') / 1e3:5.0f} {g('wkB/s') / 1e3:5.0f} {g('%util'):5.1f} {g('w_await'):5.1f} | {area[m] / 60 / 1e3:5.0f} {bmax[m] / 1e3:5.0f} | {c['d1']:3d} {c['d0']:3d} "
          f"{100 * c['rd_ms'] / 60e3:3.0f}% {100 * c['wr_ms'] / 60e3:3.0f}% | {c['pre'] / 60e3:6.1f} {c['d2h'] / 60e3:6.1f} | {c['adm']:4d} {100 * c['again'] / max(1, c['hist']):6.1f} | "
          f"{mean(l['queue']):5.1f} {mean(l['run']):5.1f} {mean(l['usage']):5.2f}")
