"""Reviewer's flow check from the extracted pickles. Usage: python3 -I -B flows_check.py <pkl> [win_s]
Per window of the client's clock: prefill new tokens (Prefill batch #new-token), d2h tokens, h2s submitted, h2s_io tokens and
busy share (sum of ms / window), h2s backlog time-weighted mean and max (submitted - done, keyed by op), s2h landed tokens
(pages x 64 from s2h_io and, separately, 'prefetch success completed'), read busy share, dispatches launched 0/1,
evict_host requested vs freed and how many fell short, running/queue from Prefill/Decode lines (means)."""
import collections
import pickle
import sys

d = pickle.load(open(sys.argv[1], "rb"))
win = int(sys.argv[2]) if len(sys.argv) > 2 else 600
W = collections.defaultdict(collections.Counter)
L = collections.defaultdict(lambda: collections.defaultdict(list))
pending = {}
backlog = 0
last_t = None
bl_area = collections.Counter()
bl_max = collections.Counter()
for t, kind, kv in d["ev"]:
    if t < 0:
        continue
    w = int(t // win)
    # time-weighted backlog
    if last_t is not None:
        t_a = last_t
        while t_a < t:
            wa = int(t_a // win)
            t_b = min(t, (wa + 1) * win)
            bl_area[wa] += backlog * (t_b - t_a)
            t_a = t_b
    last_t = t
    c = W[w]
    if kind == "h2s_submit":
        pending[kv["op"]] = kv["tokens"]
        backlog += kv["tokens"]
        c["h2s_sub"] += kv["tokens"]
    elif kind == "h2s_io":
        c["h2s_io_tok"] += kv["tokens"]
        c["h2s_io_ms"] += kv["ms"]
    elif kind == "h2s_done":
        backlog -= pending.pop(kv["op"], 0)
        c["h2s_done"] += kv["tokens"]
    elif kind == "s2h_io":
        c["s2h_tok"] += kv["pages"] * 64
        c["s2h_ms"] += kv["ms"]
        c["s2h_n"] += 1
    elif kind == "succ":
        c["succ_tok"] += kv["g"][1]
    elif kind == "d2h_submit":
        c["d2h"] += kv["tokens"]
    elif kind == "h2d_submit":
        c["h2d"] += kv["tokens"]
    elif kind == "evict_host":
        c["evh_req"] += kv["requested"]
        c["evh_tok"] += kv["tokens"]
        c["evh_n"] += 1
        c["evh_short"] += kv["tokens"] < kv["requested"]
    elif kind == "srs_dispatch":
        c[f"disp{kv['launched']}"] += 1
    elif kind == "PRE":
        c["pre_new"] += kv["new"]
        c["pre_cached"] += kv["cached"]
        L[w]["queue"].append(kv["queue"])
        L[w]["run"].append(kv["run"])
        L[w]["usage"].append(kv["usage"])
    elif kind == "DEC":
        L[w]["drun"].append(kv["run"])
        L[w]["dusage"].append(kv["usage"])
        L[w]["dqueue"].append(kv["queue"])
    bl_max[w] = max(bl_max[w], backlog)
mean = lambda v: sum(v) / len(v) if v else float("nan")
print(f"{d['label']} ({d['run']}), window {win} s; tokens in M unless noted")
print(f"  {'win':>7s} {'preM':>5s} {'d2hM':>5s} {'h2sM':>5s} {'wrbusy':>6s} {'wrK/s':>5s} {'blogM':>5s} {'blmax':>5s} | {'s2hM':>5s} {'succM':>5s} {'rdbusy':>6s} {'rdK/s':>5s} | "
      f"{'d0':>4s} {'d1':>4s} | {'evhReqM':>7s} {'evhM':>5s} {'short':>5s}/{'n':<5s} | {'queue':>5s} {'run':>5s} {'usage':>5s} {'drun':>5s} {'dusg':>5s}")
for w in sorted(W):
    c, l = W[w], L[w]
    print(f"  {w * win / 60:3.0f}-{(w + 1) * win / 60:<3.0f} {c['pre_new'] / 1e6:5.2f} {c['d2h'] / 1e6:5.2f} {c['h2s_sub'] / 1e6:5.2f} {100 * c['h2s_io_ms'] / (win * 1e3):5.1f}% "
          f"{c['h2s_io_tok'] / max(1, c['h2s_io_ms']):5.1f} {bl_area[w] / win / 1e6:5.2f} {bl_max[w] / 1e6:5.2f} | {c['s2h_tok'] / 1e6:5.2f} {c['succ_tok'] / 1e6:5.2f} "
          f"{100 * c['s2h_ms'] / (win * 1e3):5.1f}% {c['s2h_tok'] / max(1, c['s2h_ms']):5.1f} | {c['disp0']:4d} {c['disp1']:4d} | {c['evh_req'] / 1e6:7.2f} {c['evh_tok'] / 1e6:5.2f} "
          f"{c['evh_short']:5d}/{c['evh_n']:<5d} | {mean(l['queue']):5.1f} {mean(l['run']):5.1f} {mean(l['usage']):5.2f} {mean(l['drun']):5.1f} {mean(l['dusage']):5.2f}")
tot = collections.Counter()
for w in W:
    tot.update(W[w])
print(f"  total: h2s submitted {tot['h2s_sub'] / 1e6:.1f} M tokens ({tot['h2s_sub'] * 98304 / 1e12:.2f} TB), h2s_io {tot['h2s_io_tok'] / 1e6:.1f} M, d2h {tot['d2h'] / 1e6:.1f} M, prefill {tot['pre_new'] / 1e6:.1f} M, "
      f"s2h {tot['s2h_tok'] / 1e6:.1f} M, succ {tot['succ_tok'] / 1e6:.1f} M, pending at end {backlog / 1e6:.3f} M ({len(pending)} ops)")
print()
