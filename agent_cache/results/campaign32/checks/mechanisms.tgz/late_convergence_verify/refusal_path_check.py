"""Reviewer's refusal-path check. Usage (from agent_cache/): python3 -I -B refusal_path_check.py <pkl> [...]
Returning requests sent 60-110 min that recomputed >= 1,024 tokens and >= 5 % of history and whose last read attempt before
admission was a refused dispatch (srs_dispatch launched=0 with nothing landed after it): number of refused dispatches before
admission, time from the last refusal to admission (p50, p90), the last gate decision after the last refusal, and how many of
them had another lookup (s2h_query) after their last refusal."""
import collections
import json
import pickle
import sys


def q(v, p):
    v = sorted(v)
    return v[min(len(v) - 1, int(p * len(v)))] if v else float("nan")


for path in sys.argv[1:]:
    d = pickle.load(open(path, "rb"))
    per = collections.defaultdict(list)
    for t, kind, kv in d["ev"]:
        if kind in ("s2h_query", "srs_park", "srs_dispatch", "s2h_io", "ntp_gate"):
            rid = kv.get("rid")
            if isinstance(rid, str) and "-c" in rid:
                per[rid].append((t, kind, kv))
    nref = collections.Counter()
    gaps, after_gate = [], collections.Counter()
    lookups_after = 0
    n = 0
    with open(f"results/{d['run']}/{d['programs']}/client.jsonl") as f:
        f.readline()
        for line in f:
            r = json.loads(line)
            if r.get("kind") != "req" or r["k"] <= 0 or r["ideal_cached"] <= 0 or r.get("ttft") is None or not (3600 <= r["t_send"] < 6600):
                continue
            s = d["rts"].get(r["rid"])
            if not s:
                continue
            cd = r.get("cached_details") or {}
            got = sum(int(cd.get(x) or 0) for x in ("device", "host", "storage"))
            again = r["ideal_cached"] - got
            if again < 1024 or again < 0.05 * r["ideal_cached"]:
                continue
            t_adm = s["entry"] + s["queue_s"]
            evs = [e for e in sorted(per.get(r["rid"], []), key=lambda e: e[0]) if e[0] <= t_adm + 0.005]
            state, refusals, last_ref = None, 0, None
            for t, kind, kv in evs:
                if kind == "s2h_query" and kv.get("storage_hit", 0) > 0:
                    state = "found"
                elif kind == "srs_dispatch" and state:
                    if kv.get("launched") == 1:
                        state = "inflight"
                    else:
                        state, refusals, last_ref = "refused", refusals + 1, t
                elif kind == "s2h_io" and state:
                    state = "landed"
            if state != "refused":
                continue
            n += 1
            nref[min(refusals, 4)] += 1
            gaps.append(t_adm - last_ref)
            g = [kv.get("decision") for t, kind, kv in evs if kind == "ntp_gate" and t > last_ref]
            after_gate[g[-1] if g else "none"] += 1
            lookups_after += any(kind == "s2h_query" and t > last_ref for t, kind, kv in evs)
    print(f"{d['label']}: {n} refused requests (sent 60-110); refused dispatches each: " + ", ".join(f"{k}{'+' if k == 4 else ''}: {v}" for k, v in sorted(nref.items()))
          + f"; last refusal to admission p50 {q(gaps, .5):.1f} s, p90 {q(gaps, .9):.1f} s; last gate decision after the last refusal: {dict(after_gate)}; with a lookup after the last refusal: {lookups_after}")
