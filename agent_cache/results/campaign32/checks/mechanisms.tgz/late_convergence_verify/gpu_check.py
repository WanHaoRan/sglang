"""Reviewer's GPU time split. Usage: python3 -I -B gpu_check.py <pkl> <from_min> <to_min> [...]
Decode log lines come every 40 decode forwards (decode_log_interval = 40). Between two consecutive Decode lines:
if no Prefill line lies inside, the interval / 40 is the time of a decode step (pure); otherwise the excess over 40 pure
steps (median pure step of intervals with the same running count, +-2) is time spent in prefill forwards.
Reports: share of the window covered by Decode intervals (the GPU always had a running batch), the median pure step,
decode share and prefill share of the window, prefill tokens and ms per prefilled token, mean running, output tok/s."""
import bisect, collections, pickle, sys
args = sys.argv[1:]
while args:
    path, m0, m1 = args[0], int(args[1]), int(args[2]); args = args[3:]
    d = pickle.load(open(path, "rb"))
    a, b = m0 * 60, m1 * 60
    dec = [(t, kv) for t, k, kv in d["ev"] if k == "DEC" and a <= t < b]
    pre = [(t, kv) for t, k, kv in d["ev"] if k == "PRE" and a <= t < b]
    pt = [t for t, _ in pre]
    pure = collections.defaultdict(list)
    ivs = []
    for (t1, k1), (t2, k2) in zip(dec, dec[1:]):
        i, j = bisect.bisect_left(pt, t1), bisect.bisect_left(pt, t2)
        dur = t2 - t1
        run = k2["run"]
        ivs.append((dur, run, j - i, sum(pre[x][1]["new"] for x in range(i, j))))
        if j == i:
            pure[run].append(dur / 40)
    def step(run):
        v = sorted(x for r in range(run - 2, run + 3) for x in pure.get(r, []))
        return v[len(v) // 2] if v else None
    cov = sum(x[0] for x in ivs)
    dect = pref = 0.0
    ptok = 0
    for dur, run, npre, tok in ivs:
        s = step(run)
        if s is None:
            continue
        dt = min(dur, 40 * s)
        dect += dt
        pref += dur - dt
        ptok += tok
    allp = sorted(x for v in pure.values() for x in v)
    W = b - a
    meanrun = sum(x[1] for x in ivs) / max(1, len(ivs))
    print(f"{d['label']} ({d['run'][:15]}) min {m0}-{m1}: decode intervals cover {100 * cov / W:.0f} % of the window; pure intervals {sum(len(v) for v in pure.values())}, median step {1e3 * allp[len(allp) // 2]:.1f} ms; "
          f"decode {100 * dect / W:.0f} %, prefill {100 * pref / W:.0f} % of the window; prefill tokens in those intervals {ptok / 1e6:.2f} M = {ptok / W / 1e3:.1f} K/s, "
          f"{1e3 * pref / max(1, ptok):.3f} ms a token; mean running {meanrun:.1f}; decode steps {40 * len(ivs) / W:.1f}/s -> about {40 * len(ivs) * meanrun / W:.0f} output tok/s")
