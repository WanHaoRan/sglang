"""Reviewer's iostat check. Usage (from agent_cache/): python3 -I -B io_check.py <campaign dir> [win_s]
Assigns each 10 s sample of iostat_vdc.log (host clock = UTC) to the arm whose client ran then (t0 .. t0 + 7,200 s).
Per window: read kB/s, write kB/s, sum (all in units of 1,000 kB/s = 1.024 MB/s, as iostat's kB is 1,024 B),
share of samples whose sum is at least 1,950, max and p90 of sample sums, %util mean, r_await, w_await, aqu-sz, discard.
Stdlib only."""
import calendar
import collections
import json
import sys

cdir = sys.argv[1]
win = int(sys.argv[2]) if len(sys.argv) > 2 else 600
arms = []
for row in open(f"{cdir}/manifest.txt"):
    label, run, programs = row.split()
    with open(f"results/{run}/{programs}/client.jsonl") as f:
        arms.append((label, json.loads(f.readline())["t_start"]))
samples = []
hdr = None
t = None
for line in open(f"{cdir}/iostat_vdc.log", errors="replace"):
    p = line.split()
    if len(p) == 3 and p[0].count("/") == 2 and p[2] in ("AM", "PM"):
        mo, d, y = map(int, p[0].split("/"))
        hh, mm, ss = map(int, p[1].split(":"))
        hh = hh % 12 + (12 if p[2] == "PM" else 0)
        t = calendar.timegm((y, mo, d, hh, mm, ss, 0, 0, 0))
    elif p and p[0] == "Device":
        hdr = p[1:]
    elif p and p[0] == "vdc" and hdr and t is not None:
        samples.append((t, dict(zip(hdr, map(float, p[1:])))))
samples.sort(key=lambda s: s[0])
# gaps in sampling
gaps = [(samples[i][0] - samples[i - 1][0]) for i in range(1, len(samples))]
print(f"{len(samples)} samples; spacing counts:", collections.Counter(gaps).most_common(5))


def pct(v, q):
    v = sorted(v)
    return v[min(len(v) - 1, int(q * len(v)))] if v else float('nan')


for label, t0 in arms:
    W = collections.defaultdict(list)
    for ts, s in samples:
        # iostat stamps the END of its 10 s interval
        if t0 <= ts - 5 < t0 + 7200:
            W[int((ts - 5 - t0) // win)].append(s)
    print(f"{label}: {sum(len(v) for v in W.values())} samples")
    print(f"  {'window':>9s} {'n':>3s} {'rd':>6s} {'wr':>6s} {'sum':>6s} {'>=1950':>6s} {'p90':>6s} {'max':>6s} {'util':>5s} {'r_aw':>5s} {'w_aw':>6s} {'aqu':>5s} {'disc':>5s} {'rqKB':>5s} {'wqKB':>5s}")
    for w in sorted(W):
        v = W[w]
        m = lambda k: sum(s[k] for s in v) / len(v)
        sums = [(s["rkB/s"] + s["wkB/s"]) / 1e3 for s in v]
        print(f"  {w * win / 60:4.0f}-{(w + 1) * win / 60:<4.0f} {len(v):3d} {m('rkB/s') / 1e3:6.0f} {m('wkB/s') / 1e3:6.0f} {sum(sums) / len(sums):6.0f} "
              f"{100 * sum(x >= 1950 for x in sums) / len(sums):5.0f}% {pct(sums, 0.9):6.0f} {max(sums):6.0f} {m('%util'):5.1f} {m('r_await'):5.1f} {m('w_await'):6.1f} {m('aqu-sz'):5.1f} {m('dkB/s') / 1e3:5.1f} {m('rareq-sz'):5.0f} {m('wareq-sz'):5.0f}")
    print()
