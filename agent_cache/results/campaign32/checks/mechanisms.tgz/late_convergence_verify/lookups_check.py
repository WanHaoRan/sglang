"""Reviewer's check: for refused requests (sent 60-110 min, recomputed >= 1,024 and >= 5 %, last read attempt refused), the number
of lookups (s2h_query) and of ntp_refetch issued=1 before admission, and ntp_reevict capped=1 lines. Usage: python3 -I -B lookups_check.py <pkl> [...]"""
import collections, json, pickle, sys
for path in sys.argv[1:]:
    d = pickle.load(open(path, "rb"))
    per = collections.defaultdict(list)
    for t, k, kv in d["ev"]:
        if k in ("s2h_query", "srs_dispatch", "s2h_io", "ntp_refetch", "ntp_reevict"):
            rid = kv.get("rid")
            if isinstance(rid, str):
                per[rid].append((t, k, kv))
    L = collections.Counter(); R = collections.Counter(); C = collections.Counter(); byref = collections.defaultdict(collections.Counter)
    with open(f"results/{d['run']}/{d['programs']}/client.jsonl") as f:
        f.readline()
        for line in f:
            r = json.loads(line)
            if r.get("kind") != "req" or r["k"] <= 0 or r["ideal_cached"] <= 0 or r.get("ttft") is None or not (3600 <= r["t_send"] < 6600):
                continue
            s = d["rts"].get(r["rid"])
            if not s:
                continue
            cd = r.get("cached_details") or {}
            again = r["ideal_cached"] - sum(int(cd.get(x) or 0) for x in ("device", "host", "storage"))
            if again < 1024 or again < 0.05 * r["ideal_cached"]:
                continue
            ta = s["entry"] + s["queue_s"]
            evs = sorted((e for e in per.get(r["rid"], []) if e[0] <= ta + 0.005), key=lambda e: e[0])
            state = None; nref = 0
            for t, k, kv in evs:
                if k == "s2h_query" and kv.get("storage_hit", 0) > 0: state = "f"
                elif k == "srs_dispatch" and state: state = "i" if kv.get("launched") == 1 else "r"; nref += kv.get("launched") != 1
                elif k == "s2h_io" and state: state = "l"
            if state != "r":
                continue
            nl = sum(k == "s2h_query" for t, k, kv in evs)
            L[min(nl, 5)] += 1
            R[sum(k == "ntp_refetch" and kv.get("issued") == 1 for t, k, kv in evs)] += 1
            C[any(k == "ntp_reevict" and kv.get("capped") == 1 for t, k, kv in evs)] += 1
            byref[nref][min(nl, 5)] += 1
    print(f"{d['label']}: refused requests by lookups before admission {dict(sorted(L.items()))}; by refetches issued {dict(sorted(R.items()))}; with ntp_reevict capped=1: {C[True]}; "
          + "; ".join(f"{k} refusals -> lookups {dict(sorted(v.items()))}" for k, v in sorted(byref.items())))
