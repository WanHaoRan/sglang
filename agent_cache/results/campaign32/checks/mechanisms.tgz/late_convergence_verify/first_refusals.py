"""Reviewer's check of the first refusals of each arm: for the first N refused dispatches (srs_dispatch launched=0), the
pending SSD-write tokens, in-flight read tokens (launched, not landed), pinned tokens, and the latest ec_price room/held,
at that moment; and the same quantities for the launched dispatches in the same minutes. Usage: python3 -I -B first_refusals.py N <pkl> [...]"""
import pickle, sys
N = int(sys.argv[1])
def q(v, p):
    v = sorted(v); return v[min(len(v) - 1, int(p * len(v)))] if v else float("nan")
for path in sys.argv[2:]:
    d = pickle.load(open(path, "rb"))
    pending, backlog, pinned, inflight, itok = {}, 0, 0, {}, 0
    refs, oks = [], []
    for t, k, kv in d["ev"]:
        if k == "h2s_submit":
            pending[kv["op"]] = kv["tokens"]; backlog += kv["tokens"]
        elif k == "h2s_done":
            backlog -= pending.pop(kv["op"], 0)
        elif k in ("srs_pin", "srs_unpin"):
            pinned = kv.get("pinned", pinned)
        elif k == "srs_dispatch":
            row = (t, backlog, itok, pinned)
            if kv.get("launched") == 1:
                inflight[kv["rid"]] = kv["pages"] * 64; itok += kv["pages"] * 64
                oks.append(row)
            else:
                refs.append(row)
        elif k == "s2h_io":
            itok -= inflight.pop(kv["rid"], 0)
    first = refs[:N]
    if not first:
        print(d["label"], "no refusals"); continue
    t_a, t_b = first[0][0], first[-1][0]
    ok = [r for r in oks if t_a - 120 <= r[0] <= t_b]
    f = lambda rows, i: f"{q([r[i] for r in rows], .1) / 1e3:.0f}/{q([r[i] for r in rows], .5) / 1e3:.0f}/{q([r[i] for r in rows], .9) / 1e3:.0f}"
    print(f"{d['label']}: first {len(first)} refusals at {t_a / 60:.1f}-{t_b / 60:.1f} min: pending p10/p50/p90 {f(first, 1)} K, in-flight {f(first, 2)} K, pinned {f(first, 3)} K, "
          f"in-flight+pinned p50 {q([r[2] + r[3] for r in first], .5) / 1e3:.0f} K | launched dispatches from 2 min before to then ({len(ok)}): pending {f(ok, 1)} K, in-flight {f(ok, 2)} K, pinned {f(ok, 3)} K")
