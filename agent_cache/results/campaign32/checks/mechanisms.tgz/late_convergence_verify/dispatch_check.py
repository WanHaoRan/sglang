"""Reviewer's dispatch check. Usage: python3 -I -B dispatch_check.py <pkl> [...]
For every srs_dispatch: pending SSD-write tokens at that moment (h2s_submit - h2s_done by op), reads launched and not yet
landed (in-flight tokens), pinned tokens (srs_pin/unpin running total), and the latest ec_price room/held (if logged).
Refused share by pending-write bin and by in-flight+pinned bin; and, for refused dispatches, whether an evict_host line in
the same 5 ms fell short (tokens < requested). Also: sum of ec_price 'refused' tokens vs sum of refused dispatch pages x 64
(+ cut tokens of launched dispatches: park pages - s2h_io pages)."""
import bisect
import collections
import pickle
import sys

BINS = [(0, 50e3), (50e3, 200e3), (200e3, 400e3), (400e3, 1e12)]
BINS2 = [(0, 100e3), (100e3, 200e3), (200e3, 300e3), (300e3, 1e12)]
for path in sys.argv[1:]:
    d = pickle.load(open(path, "rb"))
    pending = {}
    backlog = 0
    pinned = 0
    inflight = {}  # rid -> tokens launched not landed
    inflight_tok = 0
    price = None
    park_pages = {}
    evh_times = []
    rows = []
    price_refused = 0
    cut_tok = 0
    refused_tok = 0
    disp_launched = {}
    for t, kind, kv in d["ev"]:
        if kind == "h2s_submit":
            pending[kv["op"]] = kv["tokens"]
            backlog += kv["tokens"]
        elif kind == "h2s_done":
            backlog -= pending.pop(kv["op"], 0)
        elif kind in ("srs_pin", "srs_unpin"):
            pinned = kv.get("pinned", pinned)
        elif kind == "ec_price":
            price = (kv.get("room"), kv.get("held"))
            price_refused += kv.get("refused", 0)
        elif kind == "evict_host":
            evh_times.append((t, kv["tokens"], kv["requested"]))
        elif kind == "srs_park":
            park_pages[kv["rid"]] = kv["pages"]
        elif kind == "srs_dispatch":
            rid = kv["rid"]
            launched = kv.get("launched")
            rows.append((t, launched, backlog, inflight_tok, pinned, price, kv["pages"]))
            if launched == 1:
                tok = kv["pages"] * 64
                inflight[rid] = tok
                inflight_tok += tok
                disp_launched[rid] = kv["pages"]
            else:
                refused_tok += kv["pages"] * 64
        elif kind == "s2h_io":
            rid = kv["rid"]
            tok = inflight.pop(rid, 0)
            inflight_tok -= tok
            if rid in disp_launched:
                cut_tok += max(0, disp_launched.pop(rid) - kv["pages"]) * 64
    evt = [e[0] for e in evh_times]

    def short_near(t):
        i = bisect.bisect_left(evt, t - 0.005)
        out = []
        while i < len(evt) and evt[i] <= t + 0.001:
            out.append(evh_times[i])
            i += 1
        return out

    print(f"{d['label']} ({d['run']}): {len(rows)} dispatches, {sum(r[1] != 1 for r in rows)} refused")
    for name, idx, bins in (("pending writes", 2, BINS), ("in-flight+pinned reads", None, BINS2)):
        parts = []
        for lo, hi in bins:
            sel = [r for r in rows if lo <= (r[idx] if idx is not None else r[3] + r[4]) < hi]
            n0 = sum(r[1] != 1 for r in sel)
            parts.append(f"[{lo / 1e3:.0f}K,{hi / 1e3 if hi < 1e11 else float('inf'):.0f}K) {n0}/{len(sel)} ({100 * n0 / max(1, len(sel)):.0f} %)")
        print(f"  refused/dispatches by {name}: " + "; ".join(parts))
    # joint: pending < 50K, by in-flight+pinned
    sel = [r for r in rows if r[2] < 50e3]
    parts = []
    for lo, hi in BINS2:
        s2 = [r for r in sel if lo <= r[3] + r[4] < hi]
        n0 = sum(r[1] != 1 for r in s2)
        parts.append(f"[{lo / 1e3:.0f}K,{hi / 1e3 if hi < 1e11 else float('inf'):.0f}K) {n0}/{len(s2)}")
    print("  with pending < 50K, refused/dispatches by in-flight+pinned: " + "; ".join(parts))
    sel = [r for r in rows if r[2] >= 200e3]
    parts = []
    for lo, hi in BINS2:
        s2 = [r for r in sel if lo <= r[3] + r[4] < hi]
        n0 = sum(r[1] != 1 for r in s2)
        parts.append(f"[{lo / 1e3:.0f}K,{hi / 1e3 if hi < 1e11 else float('inf'):.0f}K) {n0}/{len(s2)}")
    print("  with pending >= 200K, refused/dispatches by in-flight+pinned: " + "; ".join(parts))
    ref = [r for r in rows if r[1] != 1]
    if ref:
        n_short = sum(any(e[1] < e[2] for e in short_near(r[0])) for r in ref)
        n_any = sum(bool(short_near(r[0])) for r in ref)
        print(f"  refused dispatches with an evict_host line within 5 ms before: {n_any} ({n_short} of them short of the request)")
        if ref[0][5] is not None:
            rooms = sorted(r[5][0] for r in ref if r[5])
            helds = sorted(r[5][1] for r in ref if r[5])
            print(f"  at refused dispatches, latest ec_price room p10/p50/p90 {rooms[len(rooms) // 10] / 1e3:.0f}/{rooms[len(rooms) // 2] / 1e3:.0f}/{rooms[9 * len(rooms) // 10] / 1e3:.0f} K, "
                  f"held {helds[len(helds) // 10] / 1e3:.0f}/{helds[len(helds) // 2] / 1e3:.0f}/{helds[9 * len(helds) // 10] / 1e3:.0f} K")
        pend = sorted(r[2] for r in ref)
        infl = sorted(r[3] + r[4] for r in ref)
        print(f"  at refused dispatches: pending writes p10/p50/p90 {pend[len(pend) // 10] / 1e3:.0f}/{pend[len(pend) // 2] / 1e3:.0f}/{pend[9 * len(pend) // 10] / 1e3:.0f} K; "
              f"in-flight+pinned {infl[len(infl) // 10] / 1e3:.0f}/{infl[len(infl) // 2] / 1e3:.0f}/{infl[9 * len(infl) // 10] / 1e3:.0f} K")
    print(f"  ec_price refused tokens summed {price_refused / 1e6:.2f} M vs refused dispatch pages x 64 {refused_tok / 1e6:.2f} M + cut {cut_tok / 1e6:.2f} M = {(refused_tok + cut_tok) / 1e6:.2f} M")
    print()
