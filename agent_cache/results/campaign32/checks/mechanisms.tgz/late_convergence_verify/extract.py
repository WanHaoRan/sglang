"""Reviewer's own extraction: scan one arm's server.log once and save the events the checks need as a pickle.
Usage (from agent_cache/): python3 -I -B extract.py <campaign dir> <label> <out.pkl>
Times are seconds on the client's clock (server UTC stamp minus the client's t_start). Stdlib only."""
import calendar
import json
import pickle
import re
import sys

cdir, want, out = sys.argv[1:4]
run = programs = None
for row in open(f"{cdir}/manifest.txt"):
    label, r, p = row.split()
    if label == want:
        run, programs = r, p
assert run, want
with open(f"results/{run}/{programs}/client.jsonl") as f:
    t0 = json.loads(f.readline())["t_start"]

_sec = {}


def stamp(line):
    s = line[1:20]
    e = _sec.get(s)
    if e is None:
        e = calendar.timegm((int(s[0:4]), int(s[5:7]), int(s[8:10]), int(s[11:13]), int(s[14:16]), int(s[17:19]), 0, 0, 0))
        _sec[s] = e
    return e + int(line[21:24]) / 1000.0


KV = re.compile(r"([A-Za-z_#\-]+)=([^\s,)]+)")
RTS = re.compile(r"ReqTimeStats\(rid=([^,]+), input_len=(\d+), cached_input_len=(\d+), output_len=(\d+), attempts=(\d+).*?queue_duration=([\d.]+)ms, forward_duration=([\d.]+)ms, entry_time=([\d.]+)")
PRE = re.compile(r"Prefill batch, #new-seq: (\d+), #new-token: (\d+), #cached-token: (\d+), token usage: ([\d.]+), #running-req: (\d+), #queue-req: (\d+)")
DEC = re.compile(r"Decode batch, #running-req: (\d+), #token: (\d+), token usage: ([\d.]+),.*gen throughput \(token/s\): ([\d.]+), #queue-req: (\d+)")
SUCC = re.compile(r"HiCache prefetch success req=(\S+) completed=(\d+) matched=(\d+) loaded=(\d+) occupied=(\d+)")
REPL = re.compile(r"Replacing unresolved storage-hit accounting req=(\S+) old=(\d+) new=(\d+)")
SHRANK = re.compile(r"device prefix shrank before admission req=(\S+) lookup_match=(\d+) current_match=(\d+)")
CAP = re.compile(r"reissue cap reached req=(\S+) attempts=(\d+)")
FAILP = re.compile(r"Prefetch operation (\S+) failed to retrieve page")
CLEAN = re.compile(r"NIXL L3 cleanup: deleted (\d+) groups / (\d+) files \(([\d.]+) GiB\)")


def conv(v):
    try:
        return int(v)
    except ValueError:
        try:
            return float(v)
        except ValueError:
            return v


ev = []
rts = {}
other = []
n = 0
with open(f"results/{run}/server.log", errors="replace") as f:
    for line in f:
        if len(line) < 26 or line[0] != "[" or line[24] != "]":
            if "failed to retrieve page" in line or "NIXL L3 cleanup" in line:
                other.append((None, "raw", line.strip()[:300]))
            continue
        t = stamp(line) - t0
        i = line.find("HICACHE_EVT ")
        if i >= 0:
            j = line.find(" ", i + 12)
            kind = line[i + 12:j] if j > 0 else line[i + 12:].strip()
            kv = {k: conv(v) for k, v in KV.findall(line[j:])} if j > 0 else {}
            ev.append((t, kind, kv))
            continue
        if "ReqTimeStats(" in line:
            m = RTS.search(line)
            if m:
                rts[m[1]] = dict(t_log=t, input_len=int(m[2]), cached=int(m[3]), out=int(m[4]), attempts=int(m[5]),
                                 queue_s=float(m[6]) / 1e3, fwd_s=float(m[7]) / 1e3, entry=float(m[8]) - t0)
            continue
        if "Prefill batch" in line:
            m = PRE.search(line)
            if m:
                ev.append((t, "PRE", dict(seq=int(m[1]), new=int(m[2]), cached=int(m[3]), usage=float(m[4]), run=int(m[5]), queue=int(m[6]))))
            continue
        if "Decode batch" in line:
            m = DEC.search(line)
            if m:
                ev.append((t, "DEC", dict(run=int(m[1]), tok=int(m[2]), usage=float(m[3]), gen=float(m[4]), queue=int(m[5]))))
            continue
        for pat, kind in ((SUCC, "succ"), (REPL, "repl"), (SHRANK, "shrank"), (CAP, "capreached"), (FAILP, "failpage"), (CLEAN, "cleanup")):
            m = pat.search(line)
            if m:
                ev.append((t, kind, {"g": [conv(x) for x in m.groups()]}))
                break
ev.sort(key=lambda e: e[0])
with open(out, "wb") as f:
    pickle.dump(dict(label=want, run=run, programs=programs, t0=t0, ev=ev, rts=rts, other=other), f, protocol=4)
print(want, run, len(ev), "events", len(rts), "ReqTimeStats", len(other), "raw")
