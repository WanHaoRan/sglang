"""Reviewer's client-side check. Usage (from agent_cache/): python3 -I -B client_check.py <campaign dir> [label ...]
1. Requests in flight (client 'lanes' records) by 10-minute window: mean in_flight and live, and the history they carry,
   computed exactly: for each lanes record at time t, sum of ideal_cached (prompt history) of the requests sent before t
   and not yet answered (t_send <= t < t_send + latency).
2. Returning requests (k > 0, ideal_cached > 0, answered) by send band 30-60, 60-90, 90-110: per minute, mean history,
   GPU/host/SSD/recomputed shares of history; and new KV per request (prompt_tokens - ideal_cached + completion_tokens).
3. TTFT mean by send band 0-10, 10-30, 30-60, 60-110 (all answered requests)."""
import collections
import json
import sys

cdir = sys.argv[1]
want = sys.argv[2:]
for row in open(f"{cdir}/manifest.txt"):
    label, run, programs = row.split()
    if want and label not in want:
        continue
    reqs, lanes = [], []
    with open(f"results/{run}/{programs}/client.jsonl") as f:
        f.readline()
        for line in f:
            r = json.loads(line)
            if r.get("kind") == "req":
                reqs.append(r)
            elif r.get("kind") == "lanes":
                lanes.append(r)
    spans = sorted((r["t_send"], r["t_send"] + (r.get("latency") or 1e9), r["ideal_cached"], r["prompt_tokens"]) for r in reqs)
    W = collections.defaultdict(list)
    for ln in lanes:
        t = ln["t"]
        inf = [s for s in spans if s[0] <= t < s[1]]
        W[int(t // 600)].append((ln["in_flight"], ln["live"], len(inf), sum(s[2] for s in inf), sum(s[3] for s in inf)))
    print(f"{label} ({run})")
    print("  window: lanes in_flight / live (means); exact in flight count, their history M, their prompt M (means)")
    print("   " + " | ".join(f"{10 * w}-{10 * w + 10}: {sum(x[0] for x in v) / len(v):.0f}/{sum(x[1] for x in v) / len(v):.0f} {sum(x[2] for x in v) / len(v):.0f} {sum(x[3] for x in v) / len(v) / 1e6:.2f} {sum(x[4] for x in v) / len(v) / 1e6:.2f}"
                       for w, v in sorted(W.items()) if w < 12))
    for lo, hi in ((30, 60), (60, 90), (90, 110)):
        n = H = dv = ho = ss = ag = newkv = 0
        for r in reqs:
            if r["k"] <= 0 or r["ideal_cached"] <= 0 or r.get("ttft") is None or not (lo * 60 <= r["t_send"] < hi * 60):
                continue
            cd = r.get("cached_details") or {}
            dev, host, ssd = (int(cd.get(x) or 0) for x in ("device", "host", "storage"))
            n += 1
            H += r["ideal_cached"]
            dv += min(dev, r["ideal_cached"])
            ho += host
            ss += ssd
            ag += max(0, r["ideal_cached"] - dev - host - ssd)
            newkv += r["prompt_tokens"] - r["ideal_cached"] + (r.get("completion_tokens") or 0)
        print(f"  returning sent {lo}-{hi}: {n / (hi - lo):.1f}/min, history {H / max(1, n) / 1e3:.1f} K, GPU/host/SSD/recomp {100 * dv / H:.1f}/{100 * ho / H:.1f}/{100 * ss / H:.1f}/{100 * ag / H:.1f} %, "
              f"recomputed {ag / max(1, n) / 1e3:.1f} K per request, SSD+recomp {(ss + ag) / max(1, n) / 1e3:.1f} K, new KV {newkv / max(1, n) / 1e3:.2f} K per request")
    for lo, hi in ((0, 10), (10, 30), (30, 60), (60, 110)):
        v = [r["ttft"] for r in reqs if r.get("ttft") is not None and lo * 60 <= r["t_send"] < hi * 60]
        print(f"  TTFT sent {lo}-{hi}: mean {sum(v) / len(v):.2f} s (n {len(v)})", end=";")
    v = [r for r in reqs if r.get("ttft") is not None and r["t_send"] < 6600]
    print(f"  all sent < 6600 s: n {len(v)}, mean TTFT {sum(r['ttft'] for r in v) / len(v):.2f}")
    print()
