"""Reviewer's misc counts. Usage: python3 -I -B misc_check.py <pkl> [...]
Per arm: cleaner passes (time, GiB), failed page reads per 10-minute window, ntp_gate decision counts, ec_start decision counts,
other ec_* event counts (releases/bumps), price values seen, 'capreached' lines (hicache), write-queue delay (h2s_submit -> h2s_done)
by 10-minute window (p50/p90), evict_device tokens per window."""
import collections
import pickle
import sys


def q(v, p):
    v = sorted(v)
    return v[min(len(v) - 1, int(p * len(v)))] if v else float("nan")


for path in sys.argv[1:]:
    d = pickle.load(open(path, "rb"))
    kinds = collections.Counter(k for _, k, _ in d["ev"])
    clean = [(t, kv["g"][2]) for t, k, kv in d["ev"] if k == "cleanup"]
    fail = collections.Counter(int(t // 600) for t, k, kv in d["ev"] if k == "failpage")
    gate = collections.Counter(kv.get("decision") for t, k, kv in d["ev"] if k == "ntp_gate")
    ecs = collections.Counter(kv.get("decision") for t, k, kv in d["ev"] if k == "ec_start")
    prices = collections.Counter(kv.get("price") for t, k, kv in d["ev"] if k == "ec_price")
    sub = {}
    delay = collections.defaultdict(list)
    evd = collections.Counter()
    for t, k, kv in d["ev"]:
        if k == "h2s_submit":
            sub[kv["op"]] = t
        elif k == "h2s_done" and kv["op"] in sub:
            delay[int(t // 600)].append(t - sub.pop(kv["op"]))
        elif k == "evict_device":
            evd[int(t // 600)] += kv["tokens"]
    print(f"{d['label']} ({d['run']})")
    print("  cleaner passes: " + ", ".join(f"{t:.0f} s ({t / 60:.1f} min) {g} GiB" for t, g in clean) if clean else "  cleaner passes: none")
    print("  failed page reads by window: " + (", ".join(f"{10 * w}-{10 * w + 10}: {n}" for w, n in sorted(fail.items())) or "none"))
    print(f"  ntp_gate decisions: {dict(gate)}")
    print(f"  ec_start decisions: {dict(ecs)}; ec_* kinds: " + ", ".join(f"{k} {n}" for k, n in sorted(kinds.items()) if k.startswith("ec_")))
    print(f"  ec_price values: {dict(prices)}")
    print(f"  capreached lines {kinds.get('capreached', 0)}; shrank {kinds.get('shrank', 0)}; repl {kinds.get('repl', 0)}; ntp_reevict {kinds.get('ntp_reevict', 0)}; ntp_refetch {kinds.get('ntp_refetch', 0)}")
    print("  write delay submit->done p50/p90 s by window: " + " | ".join(f"{10 * w}-{10 * w + 10}: {q(v, .5):.1f}/{q(v, .9):.1f}" for w, v in sorted(delay.items())))
    print("  evict_device M by window: " + " ".join(f"{10 * w}:{n / 1e6:.2f}" for w, n in sorted(evd.items())))
    print()
