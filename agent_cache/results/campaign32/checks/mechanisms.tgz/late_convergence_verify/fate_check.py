"""Reviewer's own per-request fate check (independent of the analyst's req_fate.py / landed_split.py).
Usage (from agent_cache/): python3 -I -B fate_check.py <pkl> [<pkl> ...]
For each returning request (k > 0, ideal_cached > 0, answered): history recomputed = ideal_cached - (device + host + storage).
'computed' = recomputed >= 1,024 tokens and >= 5 % of the history (the analyst's threshold, kept for comparison).
Admission = ReqTimeStats entry_time + queue_duration (checked against ntp_admit where it exists).
For every request with a launched read (srs_dispatch launched=1), checks whether its s2h_io / prefetch success came after its
admission (= admitted before the read landed). The state of the LAST read attempt before admission:
  nohit     no lookup before admission found pages on the SSD
  found     a lookup found pages, nothing after it (no park / dispatch / landing) before admission
  parked    parked, not dispatched by admission
  refused   last dispatch launched=0, nothing landed after it
  inflight  last dispatch launched=1, no landing before admission
  land_cut  landed, fewer pages than the park asked for (host allocation cut it)
  land_full landed in full (history lost after landing, or the landed span did not cover it)
Tokens: recomputed tokens by state, and 'foundtok' = min(largest storage_hit of the request's lookups, recomputed)."""
import collections
import json
import pickle
import sys

TOL = 0.005
for path in sys.argv[1:]:
    d = pickle.load(open(path, "rb"))
    label, run, programs, rts = d["label"], d["run"], d["programs"], d["rts"]
    per = collections.defaultdict(list)
    adm_ntp = {}
    for t, kind, kv in d["ev"]:
        if kind in ("s2h_query", "srs_park", "srs_dispatch", "s2h_io", "ntp_gate", "srs_pin", "srs_unpin", "ntp_refetch", "ntp_reevict"):
            rid = kv.get("rid")
            if isinstance(rid, str) and "-c" in rid:
                per[rid].append((t, kind, kv))
        elif kind in ("succ", "shrank", "repl", "capreached", "failpage"):
            rid = kv["g"][0]
            per[rid].append((t, kind, kv))
        elif kind == "ntp_admit":
            adm_ntp[kv["rid"]] = t
    reqs = []
    with open(f"results/{run}/{programs}/client.jsonl") as f:
        f.readline()
        for line in f:
            r = json.loads(line)
            if r.get("kind") == "req":
                reqs.append(r)
    # admission check against ntp_admit
    diffs = []
    for rid, t in adm_ntp.items():
        s = rts.get(rid)
        if s:
            diffs.append(t - (s["entry"] + s["queue_s"]))
    diffs.sort()
    W = collections.defaultdict(collections.Counter)
    T = collections.defaultdict(collections.Counter)
    late_land = collections.Counter()
    attempts_ne0 = 0
    for r in reqs:
        if r["k"] <= 0 or r["ideal_cached"] <= 0 or r.get("ttft") is None:
            continue
        rid = r["rid"]
        s = rts.get(rid)
        w = int(r["t_send"] // 600)
        cd = r.get("cached_details") or {}
        got = sum(int(cd.get(x) or 0) for x in ("device", "host", "storage")) if cd else int(r.get("cached_tokens") or 0)
        again = max(0, r["ideal_cached"] - got)
        c, tk = W[w], T[w]
        c["ret"] += 1
        tk["hist"] += r["ideal_cached"]
        tk["again"] += again
        if s is None:
            c["nostats"] += 1
            continue
        if s["attempts"]:
            attempts_ne0 += 1
        t_adm = s["entry"] + s["queue_s"]
        evs = sorted(per.get(rid, []), key=lambda e: e[0])
        # any launched read landing after admission?
        launched_open = False
        for t, kind, kv in evs:
            if kind == "srs_dispatch" and kv.get("launched") == 1:
                launched_open = t
            elif kind in ("s2h_io", "succ") and launched_open is not False:
                if launched_open <= t_adm + TOL < t:
                    late_land["landed_after_admission"] += 1
                launched_open = False
        if launched_open is not False and launched_open <= t_adm:
            late_land["launched_never_landed"] += 1
        if again < 1024 or again < 0.05 * r["ideal_cached"]:
            continue
        c["comp"] += 1
        state, park_pages, maxhit, last_gate = "nohit", None, 0, None
        for t, kind, kv in evs:
            if t > t_adm + TOL:
                break
            if kind == "ntp_gate":
                last_gate = kv.get("decision")
            elif kind == "s2h_query":
                if kv.get("storage_hit", 0) > 0:
                    state, park_pages = "found", None
                    maxhit = max(maxhit, kv["storage_hit"])
            elif state == "nohit":
                continue
            elif kind == "srs_park":
                state, park_pages = "parked", kv["pages"]
            elif kind == "srs_dispatch":
                state = "inflight" if kv.get("launched") == 1 else "refused"
            elif kind == "s2h_io":
                cut = park_pages is not None and kv["pages"] < park_pages
                state = "land_cut" if cut else "land_full"
        c[state] += 1
        tk[state] += again
        tk["foundtok"] += min(maxhit, again)
        tk["found_" + state] += min(maxhit, again)
        c["capped"] += last_gate == "capped"
        c[state + "|capped"] += last_gate == "capped"
    print(f"{label} ({run})")
    if diffs:
        n = len(diffs)
        print(f"  ntp_admit minus (entry + queue): n={n} p1 {diffs[n // 100]:+.3f} p50 {diffs[n // 2]:+.3f} p99 {diffs[99 * n // 100]:+.3f} s")
    print(f"  requests with ReqTimeStats attempts != 0: {attempts_ne0}; launched reads landing after their request's admission: {late_land['landed_after_admission']}; "
          f"launched before admission and never landed: {late_land['launched_never_landed']}")
    S = ("nohit", "found", "parked", "refused", "inflight", "land_cut", "land_full")
    print(f"  {'win':>7s} {'ret':>5s} {'again%':>6s} {'comp':>5s} | " + " ".join(f"{x:>9s}" for x in S) + f" | {'capped':>6s} | M again: " + " ".join(f"{x[:6]:>6s}" for x in S))
    for w in sorted(W):
        c, tk = W[w], T[w]
        print(f"  {10 * w:3d}-{10 * w + 10:<3d} {c['ret']:5d} {100 * tk['again'] / max(1, tk['hist']):6.1f} {c['comp']:5d} | " + " ".join(f"{c[x]:9d}" for x in S)
              + f" | {c['capped']:6d} | " + " ".join(f"{tk[x] / 1e6:6.2f}" for x in S))
    for lo, hi in ((6, 11), (9, 11)):
        cc, tt = collections.Counter(), collections.Counter()
        for w in range(lo, hi):
            cc.update(W[w])
            tt.update(T[w])
        tot = sum(tt[x] for x in S)
        print(f"  minutes {10 * lo}-{10 * hi}: computed {cc['comp']} of {cc['ret']} returning; " + ", ".join(f"{x} {cc[x]} ({100 * cc[x] / max(1, cc['comp']):.0f} %)" for x in S)
              + f"; capped {cc['capped']} (nohit|capped {cc['nohit|capped']})")
        print(f"     recomputed tokens {tot / 1e6:.2f} M: " + ", ".join(f"{x} {100 * tt[x] / max(1, tot):.1f} %" for x in S)
              + f"; refused+land_cut {100 * (tt['refused'] + tt['land_cut']) / max(1, tot):.1f} %; found on SSD by own lookup {100 * tt['foundtok'] / max(1, tot):.1f} %")
    print()
