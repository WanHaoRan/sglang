"""Reviewer's check: (1) new KV per minute (prompt_tokens - ideal_cached at admission + completion_tokens at completion,
all requests) vs d2h per minute; (2) shortened reads (launched dispatch whose s2h_io pages < dispatch pages) per 10-minute
window and the tokens cut. Usage: python3 -I -B newkv_cut_check.py <pkl> <from_min> <to_min>"""
import collections, json, pickle, sys
d = pickle.load(open(sys.argv[1], "rb")); m0, m1 = int(sys.argv[2]), int(sys.argv[3])
new = collections.Counter(); d2h = collections.Counter()
for t, k, kv in d["ev"]:
    if k == "d2h_submit":
        d2h[int(t // 60)] += kv["tokens"]
with open(f"results/{d['run']}/{d['programs']}/client.jsonl") as f:
    f.readline()
    for line in f:
        r = json.loads(line)
        if r.get("kind") != "req" or r.get("ttft") is None:
            continue
        s = d["rts"].get(r["rid"])
        if not s:
            continue
        ta = s["entry"] + s["queue_s"]
        new[int(ta // 60)] += r["prompt_tokens"] - r["ideal_cached"]
        new[int((r["t_send"] + r["latency"]) // 60)] += r.get("completion_tokens") or 0
print(d["label"], "minute: new KV K/s, d2h K/s, share of d2h beyond new KV")
print("  " + " ".join(f"{m}:{new[m] / 60e3:.1f}/{d2h[m] / 60e3:.1f}/{100 * (1 - new[m] / max(1, d2h[m])):.0f}%" for m in range(m0, m1)))
disp = {}
W = collections.defaultdict(lambda: [0, 0])
for t, k, kv in d["ev"]:
    if k == "srs_dispatch" and kv.get("launched") == 1:
        disp[kv["rid"]] = kv["pages"]
    elif k == "s2h_io" and kv["rid"] in disp:
        p = disp.pop(kv["rid"])
        if kv["pages"] < p:
            w = W[int(t // 600)]
            w[0] += 1
            w[1] += (p - kv["pages"]) * 64
print("  shortened reads per 10-min window (count, M tokens cut): " + " ".join(f"{10 * w}:{c}/{x / 1e6:.2f}" for w, (c, x) in sorted(W.items())))
