import re, datetime as dt
def iostat(path):
    out, when, hdr = [], None, None
    for line in open(path):
        line = line.rstrip()
        m = re.match(r"^(\d\d)/(\d\d)/(\d{4}) (\d\d):(\d\d):(\d\d) (AM|PM)$", line)
        if m:
            mo, d, y, H, M, S, ap = m.groups()
            H = int(H) % 12 + (12 if ap == "PM" else 0)
            when = dt.datetime(int(y), int(mo), int(d), H, int(M), int(S), tzinfo=dt.timezone.utc).timestamp()
            continue
        if line.startswith("Device"):
            hdr = line.split()
            continue
        if line.startswith("vdc") and hdr and when is not None:
            v = dict(zip(hdr, line.split()))
            out.append((when, float(v["rkB/s"]) / 1e3, float(v["wkB/s"]) / 1e3, float(v["%util"]), float(v["r_await"]), float(v["w_await"])))
    return out[1:]
