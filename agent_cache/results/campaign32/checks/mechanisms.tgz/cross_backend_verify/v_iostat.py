"""SSD (vdc) by 10 minutes of each arm's client clock: read and write MB/s, %util, r_await and w_await (ms), from both
campaigns' iostat_vdc.log (10 s samples, stamps read as UTC; the first sample, since boot, is dropped).
Also the s2h_io read thread: tokens read (pages x 64) per 10 min, busy share (sum ms / window) and K tokens/s while busy.
usage: v_iostat.py <AC dir>"""
import sys, os, re, datetime as dt
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v_lib import *

AC = sys.argv[1]


def iostat(path):
    out, when, hdr = [], None, None
    for line in open(path):
        line = line.rstrip()
        m = re.match(r"^(\d\d)/(\d\d)/(\d{4}) (\d\d):(\d\d):(\d\d) (AM|PM)$", line)
        if m:
            mo, d, y, H, M, S, ap = m.groups()
            H = int(H) % 12 + (12 if ap == "PM" else 0)
            when = dt.datetime(int(y), int(mo), int(d), H, int(M), int(S), tzinfo=dt.timezone.utc).timestamp()
            continue
        if line.startswith("Device"):
            hdr = line.split()
            continue
        if line.startswith("vdc") and hdr and when is not None:
            v = dict(zip(hdr, line.split()))
            out.append((when, float(v["rkB/s"]) / 1e3, float(v["wkB/s"]) / 1e3, float(v["%util"]), float(v["r_await"]), float(v["w_await"])))
    return out[1:]


IO = {"tri": iostat(f"{AC}/results/campaign28/iostat_vdc.log"), "fa3": iostat(f"{AC}/results/campaign32/iostat_vdc.log")}
for be in ("tri", "fa3"):
    for arm in ARMS:
        lab = f"{arm}_{be}"
        d = load(lab)
        t0 = d["t0"]
        io = d["ev"]["s2h_io"]
        print(f"== {lab}")
        for m0 in range(0, 120, 10):
            a, b = t0 + m0 * 60, t0 + (m0 + 10) * 60
            s = [x for x in IO[be] if a <= x[0] < b]
            rd = [x for x in io if m0 * 60 <= x[0] < (m0 + 10) * 60]
            tok = sum(x[2] for x in rd) * 64
            busy = sum(x[4] for x in rd) / 1e3
            if s:
                print(f"  {m0:3d}-{m0 + 10:<3d} n={len(s):3d} read {mean(x[1] for x in s):7.0f} MB/s write {mean(x[2] for x in s):7.0f} MB/s util {mean(x[3] for x in s):5.1f} %"
                      f" r_await {mean(x[4] for x in s):6.1f} w_await {mean(x[5] for x in s):6.1f} ms | s2h reads {len(rd):4d} {tok / 1e6:6.2f} M tok, thread busy {100 * busy / 600:5.1f} %, {tok / busy / 1e3 if busy else 0:5.1f} K tok/s busy")
            else:
                print(f"  {m0:3d}-{m0 + 10:<3d} no iostat samples | s2h reads {len(rd):4d} {tok / 1e6:6.2f} M tok, thread busy {100 * busy / 600:5.1f} %")
        drop(lab)
