"""Hint error against SSD reads: returning requests (k > 0) sent in [lo, hi): split by the engine's arrival error
(ntp_arrive arr_err_ms; 'expired' = an ntp_expire for the rid before it arrived; 'none' = no ntp_arrive), share whose
admission took tokens from storage (client cached_details.storage > 0). usage: v_hint.py lo hi"""
import sys, os, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v_lib import *
lo, hi = float(sys.argv[1]), float(sys.argv[2])
for be in ("fa3", "tri"):
    for arm in HINTED:
        lab = f"{arm}_{be}"
        d = load(lab); ev = d["ev"]
        arr = {}
        for x in ev["ntp_arrive"]:
            arr.setdefault(x[1], x[2])
        exp = {x[1] for x in ev["ntp_expire"]}
        grp = collections.defaultdict(lambda: [0, 0])
        tot = [0, 0]
        for r in reqs(d):
            if r["k"] == 0 or not (lo <= r["t_send"] < hi) or r["ttft"] is None:
                continue
            ssd = (r["storage"] or 0) > 0
            rid = r["rid"]
            if rid in exp:
                g = "expired"
            elif rid not in arr or not isinstance(arr[rid], (int, float)):
                g = "no arrive"
            else:
                e = arr[rid] / 1e3
                g = "within 10 s" if abs(e) <= 10 else ("early >10 s" if e < 0 else "late >10 s")
            grp[g][0] += 1; grp[g][1] += ssd
            tot[0] += 1; tot[1] += ssd
        cells = " | ".join(f"{g}: {n} ({100 * n / tot[0]:.1f} %) SSD {100 * s / max(1, n):.1f} %" for g, (n, s) in sorted(grp.items()))
        print(f"{lab:14s} returning {tot[0]}, SSD {tot[1]} = {100 * tot[1] / max(1, tot[0]):.1f} % || {cells}")
        drop(lab)
