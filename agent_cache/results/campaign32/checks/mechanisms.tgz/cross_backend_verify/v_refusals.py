"""Storage reads refused at dispatch (srs_dispatch launched=0) and what they carry. Per run:
 - dispatches and launched=0 by server-clock window (minutes 0-10, 10-30, 30-60, 60-110) and over the whole log
 - returning requests (k > 0) sent before 6,600 s with at least one launched=0 dispatch: count, their history computed
   again (client ideal_cached - cached) and its share of all history computed again, their mean TTFT
 - the same for requests the gate answered 'capped' with no launched=0 dispatch
usage: v_refusals.py"""
import sys, os, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v_lib import *

WIN = [(0, 10), (10, 30), (30, 60), (60, 110)]


def cached(r):
    if r["device"] is None and r["host"] is None and r["storage"] is None:
        return r["cached"] or 0
    return (r["device"] or 0) + (r["host"] or 0) + (r["storage"] or 0)


for be in ("tri", "fa3"):
    for arm in HINTED:
        lab = f"{arm}_{be}"
        d = load(lab)
        disp = d["ev"]["srs_dispatch"]  # t, rid, pages, waited, inflight, pinned, launched
        win = []
        for a, b in WIN:
            n = sum(1 for x in disp if a * 60 <= x[0] < b * 60)
            z = sum(1 for x in disp if a * 60 <= x[0] < b * 60 and x[6] == 0)
            win.append(f"{n}/{z}")
        tot0 = sum(1 for x in disp if x[6] == 0)
        refused = collections.Counter(x[1] for x in disp if x[6] == 0)
        gate_capped = {x[1] for x in d["ev"]["ntp_gate"] if x[2] == "capped"}
        rq = [r for r in reqs(d) if r["t_send"] < 6600 and r["ttft"] is not None]
        again_all = sum(max(0, r["ideal"] - cached(r)) for r in rq)
        ret = [r for r in rq if r["k"] > 0]
        ref = [r for r in ret if r["rid"] in refused]
        cap_only = [r for r in ret if r["rid"] in gate_capped and r["rid"] not in refused]
        a_ref = sum(max(0, r["ideal"] - cached(r)) for r in ref)
        a_cap = sum(max(0, r["ideal"] - cached(r)) for r in cap_only)
        print(f"{lab:14s} dispatches/launched=0 by window {' '.join(win)} | all log: {len(disp)}/{tot0} | "
              f"returning reqs with a refusal {len(ref)}: again {a_ref / 1e6:.2f} M of {again_all / 1e6:.2f} M = {100 * a_ref / max(1, again_all):.1f} %, TTFT {mean(r['ttft'] for r in ref):.1f} s"
              f" | capped, no refusal {len(cap_only)}: again {a_cap / 1e6:.2f} M = {100 * a_cap / max(1, again_all):.1f} %")
        drop(lab)
