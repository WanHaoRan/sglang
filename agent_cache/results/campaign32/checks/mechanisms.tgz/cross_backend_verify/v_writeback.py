"""Write-back (host -> SSD) backlog per run: by 10 server-clock minutes, ops submitted, tokens submitted, the submit->done
p50 and p90 (s) of ops submitted in the window, write-back tokens outstanding (submitted, not done) sampled at each
srs_dispatch and at each launched=0 dispatch (p50), short host evictions (evict_host evicted < requested) and the I/O
time share of the write thread (sum h2s_io ms / window). usage: v_writeback.py"""
import sys, os, bisect
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v_lib import *

for be in ("tri", "fa3"):
    for arm in ARMS:
        lab = f"{arm}_{be}"
        d = load(lab)
        sub = {x[1]: (x[0], x[3]) for x in d["ev"]["h2s_submit"]}  # op -> (t, tokens)
        done = {x[1]: x[0] for x in d["ev"]["h2s_done"]}
        io = d["ev"]["h2s_io"]
        # outstanding tokens as a step function: +tokens at submit, -tokens at done
        steps = [(t, tok) for op, (t, tok) in sub.items()] + [(done[op], -sub[op][1]) for op in sub if op in done]
        steps.sort()
        ts = [s[0] for s in steps]
        cum = []
        c = 0
        for s in steps:
            c += s[1]; cum.append(c)
        def outstanding(t):
            i = bisect.bisect_right(ts, t) - 1
            return cum[i] if i >= 0 else 0
        disp = d["ev"].get("srs_dispatch", [])
        eh = d["ev"]["evict_host"]
        print(f"== {lab}")
        for m0 in range(0, 120, 10):
            a, b = m0 * 60, (m0 + 10) * 60
            ops = [op for op, (t, tok) in sub.items() if a <= t < b]
            lat = [done[op] - sub[op][0] for op in ops if op in done]
            notdone = sum(1 for op in ops if op not in done)
            tok = sum(sub[op][1] for op in ops)
            o_disp = [outstanding(x[0]) for x in disp if a <= x[0] < b]
            o_ref = [outstanding(x[0]) for x in disp if a <= x[0] < b and x[6] == 0]
            short = sum(1 for x in eh if a <= x[0] < b and x[1] < x[2])
            busy = sum(x[4] for x in io if a <= x[0] < b) / 1e3 / (b - a)
            o_mid = [outstanding(a + 30 + 60 * k) for k in range(10)]
            print(f"  {m0:3d}-{m0 + 10:<3d} ops {len(ops):5d} tok {tok / 1e6:5.2f} M | submit->done p50 {med(lat):7.2f} p90 {pct(lat, 90):7.2f} s (not done {notdone})"
                  f" | outstanding K tok: per-minute samples p50 {med(o_mid) / 1e3:7.0f} max {max(o_mid) / 1e3:7.0f}; at dispatches p50 {med(o_disp) / 1e3 if o_disp else float('nan'):7.0f}"
                  f" at refusals p50 {med(o_ref) / 1e3 if o_ref else float('nan'):7.0f} (n {len(o_ref)}) | short host evictions {short:4d} | write thread I/O {100 * busy:5.1f} %")
        # [3600, 6600) summary
        a, b = 3600, 6600
        o_disp = [outstanding(x[0]) for x in disp if a <= x[0] < b]
        short = sum(1 for x in eh if a <= x[0] < b and x[1] < x[2])
        print(f"  [3600,6600): outstanding at dispatches p50 {med(o_disp) / 1e3 if o_disp else float('nan'):.0f} K (n {len(o_disp)}); short host evictions {short}")
        drop(lab)
