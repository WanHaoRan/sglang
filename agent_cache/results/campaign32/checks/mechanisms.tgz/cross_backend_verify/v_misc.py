"""Smaller checks gathered in one place (reviewer's own code, from the scans of v_scan.py). usage: v_misc.py
 A. FA3 minutes 31-109 whose median decode-line queue is under 10
 B. requests sent a minute and history computed again in [4800, 6600), [5400, 6600), [5700, 6600)
 C. ec arms: ec_start decisions, distinct prices, sum of ec_price refused tokens in minutes 70-120, releases
 D. read pins: srs_pin -> next srs_unpin of the same rid, median and mean s, by unpin reason
 E. defect 1/2 signature: first ntp_reevict capped=1 per request; 'at risk' (marked before any lookup found pages and
    >= 30 s before admission) and refused at the gate; at-risk marks 55-70 s after arrival (arrivals before 6,600 s)
 F. returning requests sent in [1800, 4200): on-time (|arr_err| <= 10 s) against off-hint (> 10 s, expired, no
    arrival record): requests, SSD-reading, SSD tokens delivered (client storage)"""
import sys, os, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v_lib import *


def cached(r):
    if r["device"] is None and r["host"] is None and r["storage"] is None:
        return r["cached"] or 0
    return (r["device"] or 0) + (r["host"] or 0) + (r["storage"] or 0)


print("A. FA3 minutes 31-109 with median queue < 10")
for arm in ARMS:
    d = load(f"{arm}_fa3")
    pm = collections.defaultdict(list)
    for x in d["dec"]:
        if x[0] >= 0:
            pm[int(x[0] // 60)].append(x[3])
    below = [m for m in range(31, 110) if med(pm.get(m, [0])) < 10]
    print(f"  {arm:10s} {len(below)} {below}")
    drop(f"{arm}_fa3")
print("B. request rates and recompute share by late window")
for lo, hi in [(4800, 6600), (5400, 6600), (5700, 6600)]:
    for be in ("tri", "fa3"):
        cells = []
        for arm in ARMS:
            d = load(f"{arm}_{be}")
            rq = [r for r in reqs(d) if lo <= r["t_send"] < hi]
            ok = [r for r in rq if r["ttft"] is not None]
            ideal = sum(r["ideal"] for r in ok); again = sum(max(0, r["ideal"] - cached(r)) for r in ok)
            cells.append(f"{arm} {60 * len(rq) / (hi - lo):5.1f}/min {100 * again / max(1, ideal):4.1f}%")
            drop(f"{arm}_{be}")
        print(f"  [{lo},{hi}) {be}: " + " | ".join(cells))
print("C. ec arms")
for lab in ["ec_full_fa3", "ec_full_tri", "ec_exact_fa3", "ec_exact_tri"]:
    d = load(lab); ev = d["ev"]
    c = collections.Counter(x[2] for x in ev["ec_start"])
    prices = sorted({x[1] for x in ev["ec_price"]})
    ref = sum(x[2] for x in ev["ec_price"] if 4200 <= x[0] < 7200)
    first = next((x[0] for x in ev["ec_price"] if x[2] > 0), None)
    print(f"  {lab}: ec_start {dict(c)}; prices {len(prices)} distinct, min {prices[0]}, max {prices[-1]}; refused tokens min 70-120 {ref / 1e6:.1f} M (first at {first}); other {d['other_evt'].get('ec_release', 0)} ec_release")
    drop(lab)
print("D. read pin durations")
for lab in ["oracle_v2_fa3", "oracle_v2_tri", "jit_p50_fa3", "jit_p50_tri", "jit_exact_fa3", "jit_exact_tri"]:
    d = load(lab); ev = d["ev"]
    pins = collections.defaultdict(list)
    for x in ev["srs_pin"]:
        pins[x[1]].append(x[0])
    unp = collections.defaultdict(list)
    for x in ev["srs_unpin"]:
        unp[x[1]].append((x[0], x[3]))
    durs, adm, reasons = [], [], collections.Counter()
    for rid, pl in pins.items():
        ul = sorted(unp.get(rid, []))
        for t in pl:
            nxt = next(((u, r) for u, r in ul if u >= t), None)
            if nxt:
                durs.append(nxt[0] - t); reasons[nxt[1]] += 1
                if nxt[1] == "admit":
                    adm.append(nxt[0] - t)
    print(f"  {lab}: {len(durs)} pins, median {med(durs):.1f} s mean {mean(durs):.1f} s; admit-only median {med(adm):.1f} mean {mean(adm):.1f}; {dict(reasons)}; pin-budget skips {len(ev.get('srs_pin_skipped', []))}")
    drop(lab)
print("E. defect 1 and 2 signature (arrivals before 6,600 s)")
for be in ("tri", "fa3"):
    for arm in ["jit_exact", "jit_p50", "ec_full", "ec_exact"]:
        lab = f"{arm}_{be}"
        d = load(lab); ev = d["ev"]
        arr, adm, mark, hit, capped = {}, {}, {}, {}, set()
        for x in ev["ntp_arrive"]:
            arr.setdefault(x[1], x[0])
        for x in ev["ntp_admit"]:
            adm[x[1]] = x[0]
        for x in ev["ntp_reevict"]:
            if x[4] == 1:
                mark.setdefault(x[1], x[0])
        for x in ev["s2h_query"]:
            if x[3] > 0:
                hit.setdefault(x[1], x[0])
        for x in ev["ntp_gate"]:
            if x[2] == "capped":
                capped.add(x[1])
        rids = [r for r in arr if arr[r] < 6600]
        marks5570 = [r for r in rids if r in mark and 55 <= mark[r] - arr[r] < 70]
        risk = [r for r in rids if r in mark and (r not in hit or hit[r] > mark[r]) and r in adm and adm[r] - mark[r] >= 30]
        r5570 = [r for r in risk if 55 <= mark[r] - arr[r] < 70]
        print(f"  {lab:14s} marks at 55-70 s {len(marks5570)} (refused {sum(r in capped for r in marks5570)}); at risk {len(risk)}, refused {sum(r in capped for r in risk)}; at-risk at 55-70 s {len(r5570)}, refused {sum(r in capped for r in r5570)}")
        drop(lab)
print("F. on-time against off-hint returning requests, [1800, 4200)")
for lab in ["jit_p50_fa3", "ec_full_fa3", "jit_exact_fa3", "ec_exact_fa3", "oracle_v2_fa3", "jit_p50_tri", "ec_full_tri"]:
    d = load(lab); ev = d["ev"]
    arr = {}
    for x in ev["ntp_arrive"]:
        arr.setdefault(x[1], x[2])
    exp = {x[1] for x in ev["ntp_expire"]}
    g = collections.defaultdict(lambda: [0, 0, 0])
    for r in reqs(d):
        if r["k"] == 0 or not (1800 <= r["t_send"] < 4200) or r["ttft"] is None:
            continue
        rid = r["rid"]
        off = rid in exp or rid not in arr or not isinstance(arr[rid], (int, float)) or abs(arr[rid]) > 10000
        k = "off-hint" if off else "on-time"
        g[k][0] += 1; g[k][1] += (r["storage"] or 0) > 0; g[k][2] += r["storage"] or 0
    print(f"  {lab:14s} " + " | ".join(f"{k}: n {v[0]}, SSD-reading {v[1]} ({100 * v[1] / max(1, v[0]):.1f} %), SSD tokens {v[2] / 1e6:.2f} M" for k, v in sorted(g.items())))
    drop(lab)
