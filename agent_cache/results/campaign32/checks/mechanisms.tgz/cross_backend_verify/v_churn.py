"""Churn over minutes [a, b) per run: SSD tokens read (s2h_io pages x 64), host evicted, GPU evicted, host->GPU, GPU->host
(M tokens), mean and median pinned read tokens at dispatches (K), and SSD read tokens delivered (client storage tokens of
requests that had an s2h_io, by send time) over [1800, 4200). usage: v_churn.py a b"""
import sys, os, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v_lib import *
a, b = int(sys.argv[1]) * 60, int(sys.argv[2]) * 60
for be in ("tri", "fa3"):
    for arm in ARMS:
        lab = f"{arm}_{be}"
        d = load(lab); ev = d["ev"]
        S = lambda name, col: sum(x[col] for x in ev[name] if a <= x[0] < b)
        ssd = S("s2h_io", 2) * 64
        disp = [x for x in ev.get("srs_dispatch", []) if a <= x[0] < b]
        pins = [x[5] for x in disp]
        # delivered over [1800, 4200) by send time
        rq = {r["rid"]: r for r in reqs(d)}
        readtok = collections.Counter()
        for x in ev["s2h_io"]:
            readtok[x[1]] += x[2] * 64
        rd = dl = 0
        for rid, tok in readtok.items():
            r = rq.get(rid)
            if r is None or not (1800 <= r["t_send"] < 4200):
                continue
            rd += tok; dl += r["storage"] or 0
        print(f"{lab:14s} SSD read {ssd / 1e6:6.1f} M | host evicted {S('evict_host', 1) / 1e6:6.1f} M | GPU evicted {S('evict_device', 1) / 1e6:6.1f} M | "
              f"host->GPU {S('h2d_done', 1) / 1e6:6.1f} M | GPU->host {S('d2h_done', 1) / 1e6:6.1f} M | pinned at dispatch mean {mean(pins) / 1e3 if pins else 0:5.0f} K median {med(pins) / 1e3 if pins else 0:5.0f} K"
              f" | [1800,4200) read {rd / 1e6:6.2f} M delivered {dl / 1e6:6.2f} M = {dl / max(1, rd):.2f}")
        drop(lab)
