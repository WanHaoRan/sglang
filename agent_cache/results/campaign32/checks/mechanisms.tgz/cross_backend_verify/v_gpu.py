"""Per arm, requests sent in [lo, hi): requests a minute, history computed again (ideal - cached, client), its share of the
history, and a GPU-time budget of the server in [lo, hi) from the reviewer's own busy-interval fit (v_cost.py, refit
here per backend over [60, 6600) s of the five hinted arms): decode time, prefill time, their sum against the wall.
usage: v_gpu.py lo hi"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v_lib import *
from v_cost_fit import fit, intervals

lo, hi = float(sys.argv[1]), float(sys.argv[2])
for be in ("tri", "fa3"):
    beta = fit(be)
    c, br, bt, bp, bn = beta
    print(f"== {be}: fit dt = {c:.4f} + {br:.5f} run + {bt:.6f} Ktok + {bp:.5f} Kprefill + {bn:.4f} batches")
    for arm in ARMS:
        d = load(f"{arm}_{be}")
        rq = [r for r in reqs(d) if lo <= r["t_send"] < hi and r["ttft"] is not None]
        def cached(r):
            if r["device"] is None and r["host"] is None and r["storage"] is None:
                return r["cached"] or 0
            return (r["device"] or 0) + (r["host"] or 0) + (r["storage"] or 0)
        ideal = sum(r["ideal"] for r in rq)
        again = sum(max(0, r["ideal"] - cached(r)) for r in rq)
        ret = [r for r in rq if r["k"] > 0]
        # server budget in [lo, hi): all decode-log intervals (no running filter), predicted parts
        dec_t = pre_t = wall = 0.0
        newtok = 0
        for (t_a, dt, run, tokk, newk, nb) in intervals(d, lo, hi, min_running=1):
            dec_t += c + br * run + bt * tokk
            pre_t += bp * newk + bn * nb
            wall += dt
            newtok += newk * 1e3
        print(f"  {arm:10s} requests {len(rq):5d} = {60 * len(rq) / (hi - lo):6.1f}/min | history again {again / 1e6:6.2f} M = {100 * again / max(1, ideal):5.2f} % of history"
              f" | prefilled {newtok / 1e6:6.2f} M | model: decode {dec_t:6.0f} s + prefill {pre_t:6.0f} s = {dec_t + pre_t:6.0f} s vs wall covered {wall:6.0f} s of {hi - lo:.0f}"
              f" | again at all-in {1e3 * pre_t / max(1, newtok):.4f} ms/tok = {again * pre_t / max(1, newtok) / (hi - lo) * 100:5.1f} % of window")
        drop(f"{arm}_{be}")
