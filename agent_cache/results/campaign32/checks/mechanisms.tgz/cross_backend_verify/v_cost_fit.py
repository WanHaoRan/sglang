"""Shared fit for v_gpu.py: busy decode-log intervals -> OLS dt = c + br run + bt Ktok + bp Kprefill + bn batches."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v_lib import *


def intervals(d, lo, hi, min_running=8):
    dec, pre = d["dec"], d["pre"]
    j = 0
    out = []
    for a, b in zip(dec, dec[1:]):
        if not (lo <= a[0] and b[0] < hi):
            continue
        dt = b[0] - a[0]
        if dt <= 0 or dt > 30 or a[1] < min_running or b[1] < min_running:
            continue
        while j < len(pre) and pre[j][0] <= a[0]:
            j += 1
        k = j
        new = 0.0
        nb = 0
        while k < len(pre) and pre[k][0] <= b[0]:
            new += pre[k][2]; nb += 1; k += 1
        out.append((a[0], dt, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2 / 1e3, new / 1e3, nb))
    return out


def ols(X, y):
    k = len(X[0])
    M = [[0.0] * (k + 1) for _ in range(k)]
    for xi, yi in zip(X, y):
        for i in range(k):
            M[i][k] += xi[i] * yi
            for j in range(k):
                M[i][j] += xi[i] * xi[j]
    for c in range(k):
        p = max(range(c, k), key=lambda r: abs(M[r][c]))
        M[c], M[p] = M[p], M[c]
        for r in range(k):
            if r != c:
                f = M[r][c] / M[c][c]
                for cc in range(c, k + 1):
                    M[r][cc] -= f * M[c][cc]
    return [M[i][k] / M[i][i] for i in range(k)]


_fit = {}


def fit(be):
    if be not in _fit:
        X, y = [], []
        for arm in HINTED:
            d = load(f"{arm}_{be}")
            for (t, dt, run, tokk, newk, nb) in intervals(d, 60, 6600):
                X.append([1.0, run, tokk, newk, nb]); y.append(dt)
            drop(f"{arm}_{be}")
        _fit[be] = ols(X, y)
    return _fit[be]
