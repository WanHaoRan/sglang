"""Helpers for the reviewer's scans (scan/<label>.json.gz written by v_scan.py)."""
import gzip, json, os, statistics as st, bisect

HERE = os.path.dirname(os.path.abspath(__file__))
ARMS = ["hicache", "oracle_v2", "jit_exact", "jit_p50", "ec_full", "ec_exact"]
HINTED = ["oracle_v2", "jit_exact", "jit_p50", "ec_full", "ec_exact"]
_cache = {}


def load(label):
    if label not in _cache:
        with gzip.open(os.path.join(HERE, "scan", label + ".json.gz"), "rt") as g:
            _cache[label] = json.load(g)
    return _cache[label]


def drop(label):
    _cache.pop(label, None)


# client req record columns (see v_scan.py)
R = dict(rid=0, play=1, k=2, gap=3, wait_s=4, t_send=5, ttft=6, latency=7, prompt=8, completion=9, cached=10,
         device=11, host=12, storage=13, ideal=14, oracle_gap=15, out_target=16, prompt_sent=17)


def reqs(d):
    """client requests as dicts"""
    out = []
    for r in d["reqs"]:
        out.append({k: r[i] for k, i in R.items()})
    return out


def mean(x):
    x = list(x)
    return sum(x) / len(x) if x else float("nan")


def med(x):
    x = list(x)
    return st.median(x) if x else float("nan")


def pct(x, p):
    x = sorted(x)
    if not x:
        return float("nan")
    i = min(len(x) - 1, max(0, int(round(p / 100 * (len(x) - 1)))))
    return x[i]


def fmt(v, n=2):
    if isinstance(v, float):
        return f"{v:.{n}f}"
    return str(v)
