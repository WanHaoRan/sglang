"""Compare client run headers between paired runs. usage: v_clientargs.py manifest"""
import sys, json
rows = [l.split() for l in open(sys.argv[1]) if l.strip()]
hdr = {}
for lab, run, prog in rows:
    with open(f"results/{run}/{prog}/client.jsonl") as f:
        hdr[lab] = json.loads(f.readline())
for lab in ["hicache","oracle_v2","jit_exact","jit_p50","ec_full","ec_exact"]:
    a, b = hdr[lab+"_tri"], hdr[lab+"_fa3"]
    da = {k: v for k, v in a["args"].items()}; db = b["args"]
    diff = [k for k in set(da)|set(db) if da.get(k) != db.get(k) and k not in ("output",)]
    print(lab, "t_start tri", a["t_start"], "fa3", b["t_start"], "diff args:", {k: (da.get(k), db.get(k)) for k in diff}, "trees", a.get("trees"), b.get("trees"), "trace_header same", a.get("trace_header") == b.get("trace_header"))
