"""For requests with an SSD read (s2h_io) and an ntp_admit: admission time minus the last read's end (s), median and
share landing before admission; also ReqTimeStats queue wait of those requests. usage: v_land.py"""
import sys, os, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v_lib import *
for be in ("tri", "fa3"):
    for arm in HINTED:
        lab = f"{arm}_{be}"
        d = load(lab); ev = d["ev"]
        last = {}
        for x in ev["s2h_io"]:
            last[x[1]] = x[0]
        adm = {}
        for x in ev["ntp_admit"]:
            adm.setdefault(x[1], x[0])
        lead = [adm[r] - last[r] for r in last if r in adm]
        lead_w = [adm[r] - last[r] for r in last if r in adm and adm[r] < 6600]
        print(f"{lab:14s} reads with admit {len(lead)}: admit - last read end p50 {med(lead):6.2f} s, p10 {pct(lead, 10):6.2f}, landed before admit {100 * sum(1 for v in lead if v >= 0) / max(1, len(lead)):5.1f} % | before 6600 s p50 {med(lead_w):6.2f}")
        drop(lab)
