"""Seconds around a tipping point: per 5 s bin, dispatches/refusals, pinned read K at dispatch, write-back submitted
K tokens and outstanding K at bin end, prefill new K tokens (server), host evictions K (evict_host) and short ones,
device evictions K. usage: v_tip2.py label t0 t1"""
import sys, os, collections, bisect
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v_lib import *
lab, a, b = sys.argv[1], float(sys.argv[2]), float(sys.argv[3])
d = load(lab); ev = d["ev"]
sub = {x[1]: (x[0], x[3]) for x in ev["h2s_submit"]}
done = {x[1]: x[0] for x in ev["h2s_done"]}
steps = sorted([(t, tok) for op, (t, tok) in sub.items()] + [(done[op], -sub[op][1]) for op in sub if op in done])
ts = [s[0] for s in steps]; cum = []; c = 0
for s in steps:
    c += s[1]; cum.append(c)
def outw(t):
    i = bisect.bisect_right(ts, t) - 1
    return cum[i] if i >= 0 else 0
B = 5.0
print(f"{lab}: t | disp ref | pinK | wsubK outK | prefillK | hostevK short | devevK | s2h reads K")
t = a
while t < b:
    u = t + B
    dd = [x for x in ev["srs_dispatch"] if t <= x[0] < u]
    ws = sum(x[3] for x in ev["h2s_submit"] if t <= x[0] < u)
    pre = sum(p[2] for p in d["pre"] if t <= p[0] < u)
    eh = [x for x in ev["evict_host"] if t <= x[0] < u]
    ed = sum(x[1] for x in ev["evict_device"] if t <= x[0] < u)
    rd = sum(x[2] * 64 for x in ev["s2h_io"] if t <= x[0] < u)
    print(f"  {t:7.0f} | {len(dd):3d} {sum(1 for x in dd if x[6] == 0):3d} | {med(x[5] for x in dd) / 1e3 if dd else 0:5.0f} | {ws / 1e3:6.0f} {outw(u) / 1e3:5.0f} | {pre / 1e3:6.0f} | {sum(x[1] for x in eh) / 1e3:6.0f} {sum(1 for x in eh if x[1] < x[2]):3d} | {ed / 1e3:6.0f} | {rd / 1e3:5.0f}")
    t = u
