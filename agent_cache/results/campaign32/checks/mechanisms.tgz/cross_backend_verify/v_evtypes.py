"""Count HICACHE_EVT event types (with an example) and other notable line types in one server.log. usage: v_evtypes.py server.log"""
import sys, collections
c = collections.Counter(); ex = {}
other = collections.Counter(); oex = {}
keys = ["NIXL L3 cleanup", "KV cache pool is full", "HiCache prefetch", "Replacing unresolved", "device prefix shrank", "Traceback", "ERROR", "WARNING", "storage", "Storage"]
with open(sys.argv[1], errors="replace") as f:
    for line in f:
        i = line.find("HICACHE_EVT ")
        if i >= 0:
            ev = line[i+12:].split(" ", 1)[0]
            c[ev] += 1
            ex.setdefault(ev, line.strip()[:300])
        else:
            for k in keys:
                if k in line:
                    other[k] += 1; oex.setdefault(k, line.strip()[:300]); break
for ev, n in sorted(c.items()):
    print(f"{n:8d} {ev:20s} {ex[ev]}")
print("---")
for k, n in other.items():
    print(f"{n:8d} {k:20s} {oex[k]}")
