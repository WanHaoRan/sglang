"""Minute series around the loop onset for FA3 runs: queue (median of decode lines), users in session, refusals
(launched=0), dispatches, write-back outstanding (K, at minute end), write-back median (s, by submit minute), SSD
read/write MB/s and util (iostat), recompute per returning request (by send minute), pinned read tokens (K, median at
dispatches). usage: v_tip.py <AC> label m0 m1"""
import sys, os, collections, bisect
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v_lib import *
import v_iostat_lib as IOL
AC, lab, m0, m1 = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4])
d = load(lab); ev = d["ev"]; t0 = d["t0"]
be = lab.rsplit("_", 1)[1]
IO = IOL.iostat(f"{AC}/results/{'campaign32' if be == 'fa3' else 'campaign28'}/iostat_vdc.log")
def cached(r):
    if r["device"] is None and r["host"] is None and r["storage"] is None:
        return r["cached"] or 0
    return (r["device"] or 0) + (r["host"] or 0) + (r["storage"] or 0)
q = collections.defaultdict(list)
for x in d["dec"]:
    q[int(x[0] // 60)].append(x[3])
disp = collections.defaultdict(list)
for x in ev["srs_dispatch"]:
    disp[int(x[0] // 60)].append(x)
sub = {x[1]: (x[0], x[3]) for x in ev["h2s_submit"]}
done = {x[1]: x[0] for x in ev["h2s_done"]}
steps = sorted([(t, tok) for op, (t, tok) in sub.items()] + [(done[op], -sub[op][1]) for op in sub if op in done])
ts = [s[0] for s in steps]; cum = []; c = 0
for s in steps:
    c += s[1]; cum.append(c)
def outw(t):
    i = bisect.bisect_right(ts, t) - 1
    return cum[i] if i >= 0 else 0
lat = collections.defaultdict(list)
for op, (t, tok) in sub.items():
    if op in done:
        lat[int(t // 60)].append(done[op] - t)
io = collections.defaultdict(list)
for x in IO:
    t = x[0] - t0
    if 0 <= t < 7300:
        io[int(t // 60)].append(x)
ag = collections.defaultdict(list)
rq = reqs(d)
for r in rq:
    if r["k"] > 0 and r["ttft"] is not None:
        ag[int(r["t_send"] // 60)].append(max(0, r["ideal"] - cached(r)))
plays = {p[0]: p for p in d["plays"]}
first = {}
for r in rq:
    first[r["play"]] = min(first.get(r["play"], 1e9), r["t_send"])
start = {p: (plays[p][2] if p in plays else first[p]) for p in first}
end = {p: (plays[p][3] if p in plays else 1e9) for p in first}
print(f"{lab}: min | queue users | disp refused | wb outK wb_p50 | SSD rMB wMB util | again/ret | pinK")
for m in range(m0, m1):
    x = io.get(m, [])
    dd = disp.get(m, [])
    users = sum(1 for p in start if start[p] <= m * 60 + 30 < end[p])
    print(f"  {m:3d} | {med(q.get(m, [0])):5.0f} {users:4d} | {len(dd):4d} {sum(1 for y in dd if y[6] == 0):4d} | {outw(m * 60 + 60) / 1e3:5.0f} {med(lat.get(m, [float('nan')])):6.1f} | "
          f"{mean(y[1] for y in x) if x else float('nan'):5.0f} {mean(y[2] for y in x) if x else float('nan'):5.0f} {mean(y[3] for y in x) if x else float('nan'):5.1f} | {mean(ag.get(m, [0])):6.0f} | {med(y[5] for y in dd) / 1e3 if dd else 0:5.0f}")
