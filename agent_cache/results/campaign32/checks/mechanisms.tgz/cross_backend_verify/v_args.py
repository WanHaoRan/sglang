"""Diff server_args.txt, l3_extra.json and run.txt between paired runs. usage: v_args.py manifest (run from AC)"""
import ast, sys, os, json
man = sys.argv[1]
rows = [l.split() for l in open(man) if l.strip()]
runs = {r[0]: r[1] for r in rows}
def args(run):
    t = open(f"results/{run}/server_args.txt").read()
    i = t.index("server_args=")
    return ast.literal_eval(t[i+len("server_args="):].strip())
def kv(path):
    d = {}
    for l in open(path):
        if "=" in l:
            k, v = l.rstrip("\n").split("=", 1); d[k] = v
    return d
for lab in ["hicache","oracle_v2","jit_exact","jit_p50","ec_full","ec_exact"]:
    a, b = runs[lab+"_tri"], runs[lab+"_fa3"]
    A, B = args(a), args(b)
    diff = sorted(k for k in set(A)|set(B) if A.get(k) != B.get(k))
    print(f"== {lab}: {len(diff)} server_args keys differ")
    for k in diff:
        print(f"   {k}: tri={A.get(k)!r} fa3={B.get(k)!r}"[:300])
    la = open(f"results/{a}/l3_extra.json").read().strip(); lb = open(f"results/{b}/l3_extra.json").read().strip()
    print("   l3_extra same:", la == lb, "" if la == lb else (la, lb))
    ra, rb = kv(f"results/{a}/run.txt"), kv(f"results/{b}/run.txt")
    for k in sorted(set(ra)|set(rb)):
        if ra.get(k) != rb.get(k) and k != "started_utc":
            print(f"   run.txt {k}: tri={ra.get(k)!r} fa3={rb.get(k)!r}")
