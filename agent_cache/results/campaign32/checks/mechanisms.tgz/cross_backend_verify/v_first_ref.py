"""Write-back state at the first refusals of the loop: for launched=0 dispatches after minute 60, split into the first
100 and the rest: median outstanding write-back K tokens at the refusal, median submit->done (s) of write ops submitted
in the 60 s before it, median pinned K, and the minute of the 100th refusal. usage: v_first_ref.py"""
import sys, os, bisect
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v_lib import *
for arm in HINTED:
    lab = f"{arm}_fa3"
    d = load(lab); ev = d["ev"]
    sub = {x[1]: (x[0], x[3]) for x in ev["h2s_submit"]}
    done = {x[1]: x[0] for x in ev["h2s_done"]}
    steps = sorted([(t, tok) for op, (t, tok) in sub.items()] + [(done[op], -sub[op][1]) for op in sub if op in done])
    ts = [s[0] for s in steps]; cum = []; c = 0
    for s in steps:
        c += s[1]; cum.append(c)
    def outw(t):
        i = bisect.bisect_right(ts, t) - 1
        return cum[i] if i >= 0 else 0
    subs = sorted((t, op) for op, (t, tok) in sub.items())
    st_ = [s[0] for s in subs]
    def lat_before(t):
        i0 = bisect.bisect_left(st_, t - 60); i1 = bisect.bisect_left(st_, t)
        v = [done[subs[i][1]] - subs[i][0] for i in range(i0, i1) if subs[i][1] in done]
        return med(v) if v else float("nan")
    ref = [x for x in ev["srs_dispatch"] if x[6] == 0 and x[0] >= 3600]
    first, rest = ref[:100], ref[100:]
    def summ(xs):
        return f"n {len(xs):4d} outstanding K p50 {med(outw(x[0]) for x in xs) / 1e3:5.0f} | write latency of prior 60 s p50 {med(lat_before(x[0]) for x in xs):5.1f} s | pinned K p50 {med(x[5] for x in xs) / 1e3:5.0f}"
    print(f"{lab:14s} first 100 loop refusals (min {first[0][0] / 60:.1f}-{first[-1][0] / 60:.1f}): {summ(first)} || rest: {summ(rest)}")
    drop(lab)
