"""Independent one-pass extractor (reviewer's own code). From agent_cache/:
  python3 -I -B v_scan.py <label> results/<run> <programs> <out.json.gz>
Stores, with t in seconds of the client clock (server UTC stamp - client t_start):
  dec  [t, running, tokens, queue]                 decode log lines
  pre  [t, new_seq, new_tok, cached_tok, running, queue]  prefill log lines
  rts  {rid: [t_done, input, cached, out, queue_ms, fwd_ms, entry_rel]}
  ev   {event: [[t, field...], ...]} for the HICACHE_EVT events listed in FIELDS
  misc cleanup times, retract times
  client: run header args, req records (subset), play records
"""
import datetime as dt, gzip, json, re, sys

label, run, programs, out = sys.argv[1:5]
hdr = None
reqs, plays = [], []
with open(f"{run}/{programs}/client.jsonl") as f:
    for i, line in enumerate(f):
        d = json.loads(line)
        k = d.get("kind")
        if k == "run":
            hdr = d
        elif k == "req":
            cd = d.get("cached_details") or {}
            reqs.append([d["rid"], d["play"], d["k"], d.get("gap"), d.get("wait_s"), d["t_send"], d.get("ttft"),
                         d.get("latency"), d.get("prompt_tokens"), d.get("completion_tokens"), d.get("cached_tokens"),
                         cd.get("device"), cd.get("host"), cd.get("storage"), d.get("ideal_cached"),
                         d.get("oracle_gap_s"), d.get("out_target"), d.get("prompt_sent")])
        elif k == "play":
            plays.append([d["play"], d.get("arrival_s"), d.get("start"), d.get("end")])
t0 = hdr["t_start"]

# event -> fields kept (in order); values parsed as int/float when possible
FIELDS = {
    "s2h_io": ["rid", "pages", "tokens", "ms"],
    "s2h_query": ["rid", "tokens_req", "storage_hit"],
    "srs_park": ["rid", "pages", "deadline_ms"],
    "srs_dispatch": ["rid", "pages", "waited_ms", "inflight_pages", "pinned_tokens", "launched"],
    "srs_pin": ["rid", "tokens", "pinned"],
    "srs_unpin": ["rid", "tokens", "reason", "pinned"],
    "srs_pin_skipped": ["rid", "tokens", "pinned", "budget"],
    "ntp_due": ["rid", "case", "l3_pages", "backlog_pages", "load_ms", "wait_ms", "lead_ms", "est"],
    "ntp_gate": ["rid", "decision", "matched", "chain", "lookups"],
    "ntp_reevict": ["rid", "evicted", "refetches", "capped"],
    "ntp_refetch": ["rid", "issued", "shrink", "pos"],
    "ntp_arrive": ["rid", "arr_err_ms", "delta_ms", "pos", "qlen"],
    "ntp_admit": ["rid", "wait_ms", "case"],
    "ntp_plan": ["rid", "gap_ms", "chain", "pred_arr_ms"],
    "ntp_expire": ["rid", "staged", "reason"],
    "ntp_hold": ["rid", "pos", "pages", "wait_ms", "load_ms", "hold_ms"],
    "ntp_stage": ["rid", "tokens"],
    "ec_start": ["rid", "decision", "tokens", "start_ms", "read_ms", "wait_ms", "price"],
    "ec_price": ["price", "refused", "idle", "room", "held", "staged", "harm_ms"],
    "evict_host": ["tokens", "requested"],
    "evict_device": ["tokens", "requested"],
    "h2s_submit": ["op", "node", "tokens"],
    "h2s_io": ["op", "pages", "tokens", "ms"],
    "h2s_done": ["op", "tokens"],
    "d2h_done": ["tokens"],
    "h2d_done": ["tokens"],
    "load_back_init": ["rid", "tokens", "host_hit"],
}
TS = re.compile(r"^\[(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)(\.\d+)\] ")
KV = re.compile(r"(\w+)=(\S+)")
DEC = re.compile(r"Decode batch, #running-req: (\d+), #token: (\d+), .*#queue-req: (\d+)")
PRE = re.compile(r"Prefill batch, #new-seq: (\d+), #new-token: (\d+), #cached-token: (\d+), .*#running-req: (\d+), #queue-req: (\d+)")
RTS = re.compile(r"ReqTimeStats\(rid=([^,]+), input_len=(\d+), cached_input_len=(\d+), output_len=(\d+).*?queue_duration=([\d.]+)ms, forward_duration=([\d.]+)ms, entry_time=([\d.]+)")


def num(v):
    try:
        return int(v)
    except ValueError:
        try:
            return float(v)
        except ValueError:
            return v


sec_cache = {}


def stamp(a, b):
    e = sec_cache.get(a)
    if e is None:
        e = dt.datetime.strptime(a, "%Y-%m-%d %H:%M:%S").replace(tzinfo=dt.timezone.utc).timestamp()
        if len(sec_cache) > 4:
            sec_cache.clear()
        sec_cache[a] = e
    return e + float(b) - t0


dec, pre, rts, cleanups, retracts = [], [], {}, [], []
ev = {k: [] for k in FIELDS}
other_evt = {}
with open(f"{run}/server.log", errors="replace") as f:
    for line in f:
        m = TS.match(line)
        if not m:
            continue
        t = round(stamp(m[1], m[2]), 3)
        body = line[m.end():]
        if body.startswith("HICACHE_EVT "):
            name, _, rest = body[12:].partition(" ")
            flds = FIELDS.get(name)
            if flds is None:
                other_evt[name] = other_evt.get(name, 0) + 1
                continue
            kv = dict(KV.findall(rest))
            ev[name].append([t] + [num(kv[x]) if x in kv else None for x in flds])
        elif body.startswith("Decode batch"):
            d = DEC.match(body)
            if d:
                dec.append([t, int(d[1]), int(d[2]), int(d[3])])
        elif body.startswith("Prefill batch"):
            p = PRE.match(body)
            if p:
                pre.append([t, int(p[1]), int(p[2]), int(p[3]), int(p[4]), int(p[5])])
        elif body.startswith("ReqTimeStats"):
            r = RTS.match(body)
            if r:
                rts[r[1]] = [t, int(r[2]), int(r[3]), int(r[4]), float(r[5]), float(r[6]), round(float(r[7]) - t0, 3)]
        elif body.startswith("NIXL L3 cleanup"):
            cleanups.append([t, body.strip()[:200]])
        elif body.startswith("KV cache pool is full"):
            retracts.append(t)
with gzip.open(out, "wt") as g:
    json.dump({"label": label, "run": run, "programs": programs, "t0": t0, "args": hdr.get("args"), "dec": dec, "pre": pre,
               "rts": rts, "ev": ev, "other_evt": other_evt, "cleanups": cleanups, "retracts": retracts,
               "reqs": reqs, "plays": plays}, g)
print(label, "dec", len(dec), "pre", len(pre), "rts", len(rts), "reqs", len(reqs), "plays", len(plays),
      {k: len(v) for k, v in ev.items() if v}, "other", other_evt, "cleanups", [c[0] for c in cleanups], "retracts", len(retracts))
