"""State at storage-read dispatches, launched=0 against launched=1, by server-clock window: read backlog (inflight_pages x 64,
K tokens), pinned read tokens (K), write-back tokens outstanding (K), and for ec arms the last ec_price room/held.
usage: v_refstate.py"""
import sys, os, bisect
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v_lib import *

WIN = [(30, 40), (40, 50), (50, 60), (60, 70), (70, 80), (80, 90), (90, 110)]
for be in ("fa3", "tri"):
    for arm in HINTED:
        lab = f"{arm}_{be}"
        d = load(lab)
        sub = {x[1]: (x[0], x[3]) for x in d["ev"]["h2s_submit"]}
        done = {x[1]: x[0] for x in d["ev"]["h2s_done"]}
        steps = sorted([(t, tok) for op, (t, tok) in sub.items()] + [(done[op], -sub[op][1]) for op in sub if op in done])
        ts = [s[0] for s in steps]
        cum, c = [], 0
        for s in steps:
            c += s[1]; cum.append(c)
        def outw(t):
            i = bisect.bisect_right(ts, t) - 1
            return cum[i] if i >= 0 else 0
        disp = d["ev"]["srs_dispatch"]
        print(f"== {lab}: cells = n | backlog K | pinned K | writes outstanding K  (medians), launched=0 ; launched=1")
        for a, b in WIN:
            cells = []
            for L in (0, 1):
                xs = [x for x in disp if a * 60 <= x[0] < b * 60 and x[6] == L]
                if xs:
                    cells.append(f"{len(xs):5d} {med(x[4] * 64 for x in xs) / 1e3:6.0f} {med(x[5] for x in xs) / 1e3:6.0f} {med(outw(x[0]) for x in xs) / 1e3:6.0f}")
                else:
                    cells.append(f"{0:5d} {'-':>6s} {'-':>6s} {'-':>6s}")
            print(f"  {a:3d}-{b:<3d} | " + " ; ".join(cells))
        drop(lab)
