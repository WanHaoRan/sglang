"""Per-minute onset series per FA3 run: launched=0 dispatches a minute (server clock), history computed again per
returning request (client, by send minute), write-back submit->done median (by submit minute), SSD util (iostat).
Reports the first minute of: >= 5 refusals a minute for 3 minutes running; 3-minute mean of again >= 2,000; write-back
median >= 5 s for 3 minutes; util >= 95 % for 3 minutes; and the count of minutes 0-110 with >= 5 refusals.
usage: v_onset.py <AC>"""
import sys, os, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v_lib import *
from v_iostat import iostat
AC = sys.argv[1]
def cached(r):
    if r["device"] is None and r["host"] is None and r["storage"] is None:
        return r["cached"] or 0
    return (r["device"] or 0) + (r["host"] or 0) + (r["storage"] or 0)
for be in ("fa3", "tri"):
    IO = iostat(f"{AC}/results/{'campaign32' if be == 'fa3' else 'campaign28'}/iostat_vdc.log")
    for arm in ARMS:
        lab = f"{arm}_{be}"
        d = load(lab); ev = d["ev"]; t0 = d["t0"]
        l0 = collections.Counter(int(x[0] // 60) for x in ev.get("srs_dispatch", []) if x[6] == 0)
        ag = collections.defaultdict(list)
        for r in reqs(d):
            if r["k"] > 0 and r["ttft"] is not None:
                ag[int(r["t_send"] // 60)].append(max(0, r["ideal"] - cached(r)))
        agm = {m: mean(v) for m, v in ag.items()}
        sub = {x[1]: x[0] for x in ev["h2s_submit"]}
        done = {x[1]: x[0] for x in ev["h2s_done"]}
        lat = collections.defaultdict(list)
        for op, t in sub.items():
            if op in done:
                lat[int(t // 60)].append(done[op] - t)
        wb = {m: med(v) for m, v in lat.items()}
        ut = collections.defaultdict(list)
        for x in IO:
            t = x[0] - t0
            if 0 <= t < 7300:
                ut[int(t // 60)].append(x[3])
        utm = {m: mean(v) for m, v in ut.items()}
        def first(f, run=3):
            for m in range(0, 118):
                if all(f(m + j) for j in range(run)):
                    return m
        def first_mean(dct, th, run=3):
            for m in range(0, 118):
                if sum(dct.get(m + j, 0) for j in range(run)) / run >= th:
                    return m
        print(f"{lab:14s} refusals>=5 x3 from m{first(lambda m: l0.get(m, 0) >= 5)} | again 3-min mean >=2000 from m{first_mean(agm, 2000)} | "
              f"write-back median >=5 s x3 from m{first(lambda m: wb.get(m, 0) >= 5)} | util >=95 x3 from m{first(lambda m: utm.get(m, 0) >= 95)} | "
              f"minutes 0-110 with >=5 refusals: {sum(1 for m in range(110) if l0.get(m, 0) >= 5)} | first refusal minute {min(l0) if l0 else None}")
        drop(lab)
