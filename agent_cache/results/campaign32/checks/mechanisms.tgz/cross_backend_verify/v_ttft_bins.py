"""Mean TTFT (client) by 10 minutes of send time, requests sent a minute in [4200, 6600), and history computed again per
returning request by 10 minutes (client ideal_cached - cached). usage: v_ttft_bins.py"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v_lib import *


def cached(r):
    if r["device"] is None and r["host"] is None and r["storage"] is None:
        return r["cached"] or 0
    return (r["device"] or 0) + (r["host"] or 0) + (r["storage"] or 0)


for be in ("tri", "fa3"):
    print(f"== {be}: mean TTFT s by send minutes 0-10 ... 100-110 | sent/min in [4200,6600) | again per returning request by 10 min")
    for arm in ARMS:
        lab = f"{arm}_{be}"
        d = load(lab)
        rq = [r for r in reqs(d) if r["ttft"] is not None]
        cells, ag = [], []
        for m0 in range(0, 110, 10):
            x = [r["ttft"] for r in rq if m0 * 60 <= r["t_send"] < (m0 + 10) * 60]
            cells.append(f"{mean(x):5.1f}")
            ret = [r for r in rq if r["k"] > 0 and m0 * 60 <= r["t_send"] < (m0 + 10) * 60]
            ag.append(f"{mean(max(0, r['ideal'] - cached(r)) for r in ret):6.0f}")
        n = sum(1 for r in reqs(d) if 4200 <= r["t_send"] < 6600)
        print(f"  {arm:10s} " + " ".join(cells) + f" | {n / 40:6.1f} | " + " ".join(ag))
        drop(lab)
