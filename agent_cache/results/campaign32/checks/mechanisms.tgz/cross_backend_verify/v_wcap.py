"""Write-thread cost per token against read load, per 10 server-clock minutes: tokens written (h2s_io pages x 64),
write-thread busy share (sum h2s_io ms / 600 s), ms of write-thread time per token, implied capacity (K tokens/s at
100 % busy), and SSD read MB/s (iostat). usage: v_wcap.py <AC>"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v_lib import *
import v_iostat_lib as IOL
AC = sys.argv[1]
for be in ("tri", "fa3"):
    IO = IOL.iostat(f"{AC}/results/{'campaign32' if be == 'fa3' else 'campaign28'}/iostat_vdc.log")
    for arm in HINTED:
        lab = f"{arm}_{be}"
        d = load(lab); t0 = d["t0"]
        cells = []
        for m0 in range(30, 110, 10):
            a, b = m0 * 60, (m0 + 10) * 60
            io = [x for x in d["ev"]["h2s_io"] if a <= x[0] < b]
            tok = sum(x[2] for x in io) * 64
            busy = sum(x[4] for x in io) / 1e3
            rd = [x[1] for x in IO if a <= x[0] - t0 < b]
            cells.append(f"{m0:3d}: w {tok / 1e6:4.1f}M {100 * busy / 600:3.0f}% {1e3 * busy / max(1, tok):5.3f}ms/t cap {tok / max(1e-9, busy) / 1e3:4.1f}K/s r {mean(rd):5.0f}MB/s")
        print(f"{lab:14s} " + " | ".join(cells))
        drop(lab)
