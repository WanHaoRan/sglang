"""Regime check: queue length (decode lines), queue wait (ReqTimeStats by client send time), requests sent a minute,
users in session, users admitted, session length, slot wait. usage: v_regime.py (from anywhere)"""
import sys, os, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v_lib import *

WIN = [(600, 1800), (1800, 3600), (3600, 6600)]
rows = {}
ended_sets = {}
sess = {}
for be in ["tri", "fa3"]:
    for arm in ARMS:
        lab = f"{arm}_{be}"
        d = load(lab)
        dec = d["dec"]
        # queue by window (mean over decode lines)
        qwin = []
        for a, b in WIN:
            v = [x[3] for x in dec if a <= x[0] < b]
            qwin.append(mean(v))
        # per-minute queue mean
        pm = collections.defaultdict(list)
        for x in dec:
            if x[0] >= 0:
                pm[int(x[0] // 60)].append(x[3])
        qmin = {m: mean(v) for m, v in pm.items()}
        def first_stay(th, last=110):
            for m in range(0, last):
                if all(qmin.get(j, 0) >= th for j in range(m, last)):
                    return m
            return None
        def first_hold(th, hold=3):
            for m in range(0, 120):
                if all(qmin.get(j, 0) >= th for j in range(m, m + hold)):
                    return m
            return None
        rq = reqs(d)
        rts = d["rts"]
        wwin, nwin = [], []
        for a, b in WIN:
            w = [rts[r["rid"]][4] / 1e3 for r in rq if a <= r["t_send"] < b and r["rid"] in rts]
            wwin.append(mean(w))
            nwin.append(sum(1 for r in rq if a <= r["t_send"] < b) / ((b - a) / 60))
        # sessions
        first = {}
        lastend = {}
        for r in rq:
            p = r["play"]
            first[p] = min(first.get(p, 1e9), r["t_send"])
        plays = {p[0]: p for p in d["plays"]}
        start = {}
        for p in set(first) | set(plays):
            if p in plays and plays[p][2] is not None:
                start[p] = plays[p][2]
            else:
                start[p] = first[p]
        end = {p: (plays[p][3] if p in plays and plays[p][3] is not None else 1e9) for p in start}
        def active(t):
            return sum(1 for p in start if start[p] <= t < end[p])
        act = {m: active(m * 60 + 30) for m in range(0, 120)}
        full = None
        for m in range(120):
            if act[m] >= 128:
                full = m; break
        adm = sum(1 for p in start if start[p] < 6600)
        adm3060 = sum(1 for p in start if 1800 <= start[p] < 3600)
        ended = {p: plays[p][3] - plays[p][2] for p in plays if plays[p][3] is not None and plays[p][2] is not None}
        ended_sets[lab] = ended
        slot = [plays[p][2] - plays[p][1] for p in plays if plays[p][1] is not None and plays[p][2] is not None]
        slot_adm = [plays[p][2] - plays[p][1] for p in plays if plays[p][1] is not None and plays[p][2] is not None and plays[p][2] < 6600]
        rows[lab] = dict(q=qwin, w=wwin, n=nwin, q10=first_stay(10), q40=first_stay(40), q10h=first_hold(10), q40h=first_hold(40),
                         full=full, adm=adm, adm3060=adm3060, slot_mean=mean(slot), slot_n=len(slot), slot_adm=mean(slot_adm),
                         nplays_drained=len(plays))
for lab, r in rows.items():
    print(f"{lab:14s} queue {'/'.join(fmt(x,1) for x in r['q'])}  wait_s {'/'.join(fmt(x,2) for x in r['w'])}  req/min {'/'.join(fmt(x,1) for x in r['n'])}"
          f"  q>=10 stays from m{r['q10']} (3-min hold m{r['q10h']})  q>=40 stays from m{r['q40']} (hold m{r['q40h']})  128 users at m{r['full']}"
          f"  admitted<6600 {r['adm']} (30-60 min {r['adm3060']})  slot wait mean {fmt(r['slot_mean'],1)} over {r['slot_n']} drained (start<6600: {fmt(r['slot_adm'],1)})")
# shared ended sessions
for group, labs in [("hinted10", [f"{a}_{b}" for a in HINTED for b in ("tri", "fa3")]), ("all12", [f"{a}_{b}" for a in ARMS for b in ("tri", "fa3")])]:
    shared = set.intersection(*[set(ended_sets[l]) for l in labs])
    print(group, "shared ended sessions", len(shared))
    for l in labs:
        print(f"   {l:14s} mean session {mean(ended_sets[l][p] for p in shared):.1f} s")
