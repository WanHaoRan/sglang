"""SSD writes against GPU-computed KV per 10 server-clock minutes: written = h2s_io pages x 64; computed = Prefill
#new-token (server) + completion tokens of requests finishing in the window (client: t_send + latency); history
computed again (client ideal - cached) of requests finishing in the window; requests finished. usage: v_writes.py"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v_lib import *
def cached(r):
    if r["device"] is None and r["host"] is None and r["storage"] is None:
        return r["cached"] or 0
    return (r["device"] or 0) + (r["host"] or 0) + (r["storage"] or 0)
for be in ("tri", "fa3"):
    for arm in ARMS:
        lab = f"{arm}_{be}"
        d = load(lab)
        rq = [r for r in reqs(d) if r["ttft"] is not None and r["latency"] is not None]
        cells = []
        for m0 in range(0, 110, 10):
            a, b = m0 * 60, (m0 + 10) * 60
            w = sum(x[2] for x in d["ev"]["h2s_io"] if a <= x[0] < b) * 64
            pre = sum(p[2] for p in d["pre"] if a <= p[0] < b)
            fin = [r for r in rq if a <= r["t_send"] + r["latency"] < b]
            out = sum(r["completion"] or 0 for r in fin)
            again = sum(max(0, r["ideal"] - cached(r)) for r in fin)
            comp = pre + out
            cells.append(f"{w / 1e6:4.1f}/{comp / 1e6:4.1f}={w / max(1, comp):4.2f} ag{again / 1e6:4.1f} n{len(fin)}")
        print(f"{lab:14s} " + " | ".join(cells))
        drop(lab)
