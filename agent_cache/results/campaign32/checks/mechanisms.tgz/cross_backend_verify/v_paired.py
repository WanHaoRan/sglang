"""Paired TTFT differences (reviewer's own code): requests keyed by (play, stream, k), both sent before 6,600 s; mean of
B - A, a 95 % interval from a user-level bootstrap (2,000 draws, seed 7) and from the cluster (user) normal
approximation. Also each arm's own mean TTFT before 6,600 s and the mean over the requests every one of the 12 runs sent.
usage: v_paired.py <AC> <manifest vs_c28>"""
import sys, json, random, math, collections
AC, man = sys.argv[1], sys.argv[2]
rows = [l.split() for l in open(man) if l.strip()]
data = {}
for lab, run, prog in rows:
    d = {}
    with open(f"{AC}/results/{run}/{prog}/client.jsonl") as f:
        f.readline()
        for line in f:
            if '"kind":"req"' not in line:
                continue
            r = json.loads(line)
            if r.get("ttft") is None or r["t_send"] >= 6600 or r.get("phase") != "profile":
                continue
            d[(r["play"], r["stream"], r["k"])] = r["ttft"]
    data[lab] = d


def paired(a, b, seed=7, draws=2000):
    A, B = data[a], data[b]
    keys = set(A) & set(B)
    per = collections.defaultdict(list)
    for k in keys:
        per[k[0]].append(B[k] - A[k])
    users = list(per)
    tot = sum(sum(v) for v in per.values()); n = sum(len(v) for v in per.values())
    m = tot / n
    rng = random.Random(seed)
    sums = {u: (sum(per[u]), len(per[u])) for u in users}
    bs = []
    for _ in range(draws):
        s = c = 0
        for _ in users:
            u = users[rng.randrange(len(users))]
            s += sums[u][0]; c += sums[u][1]
        bs.append(s / c)
    bs.sort()
    lo, hi = bs[int(0.025 * draws)], bs[int(0.975 * draws) - 1]
    # cluster normal approximation for a ratio estimator
    G = len(users)
    var = sum((sums[u][0] - m * sums[u][1]) ** 2 for u in users) * G / (G - 1) / n ** 2
    se = math.sqrt(var)
    return n, G, m, lo, hi, m - 1.96 * se, m + 1.96 * se


for lab in data:
    v = list(data[lab].values())
    print(f"{lab:14s} own mean before 6600: {sum(v) / len(v):7.2f} s over {len(v)} requests")
common = set.intersection(*[set(d) for d in data.values()])
print(f"requests every run sent: {len(common)} of {len({k[0] for k in common})} users")
for lab in data:
    print(f"   {lab:14s} {sum(data[lab][k] for k in common) / len(common):7.2f}")
pairs = [(f"{a}_tri", f"{a}_fa3") for a in ["oracle_v2", "jit_p50", "ec_full", "ec_exact", "jit_exact", "hicache"]]
pairs += [("jit_p50_tri", "jit_exact_tri"), ("jit_exact_tri", "oracle_v2_tri"), ("ec_full_tri", "jit_p50_tri"),
          ("jit_p50_fa3", "jit_exact_fa3"), ("jit_exact_fa3", "oracle_v2_fa3"), ("ec_full_fa3", "jit_p50_fa3"),
          ("ec_full_fa3", "jit_exact_fa3"), ("ec_full_fa3", "ec_exact_fa3"), ("ec_exact_fa3", "jit_exact_fa3")]
for a, b in pairs:
    n, G, m, lo, hi, nlo, nhi = paired(a, b)
    print(f"{a:14s} -> {b:14s} n {n:5d} users {G:3d}: B-A {m:+7.2f} s, bootstrap [{lo:+.2f}, {hi:+.2f}], cluster-normal [{nlo:+.2f}, {nhi:+.2f}]")
