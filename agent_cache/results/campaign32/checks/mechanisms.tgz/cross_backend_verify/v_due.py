"""ntp_due by case (1 = before arrival, 2 = from queue position) in minutes [30, 70) and over the whole log; srs_park
waits (dispatch waited_ms) by 10 minutes (median s); pin durations (srs_pin -> srs_unpin, s) over the log; pin-budget
skips; plan expiries. usage: v_due.py"""
import sys, os, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v_lib import *
for be in ("tri", "fa3"):
    for arm in HINTED:
        lab = f"{arm}_{be}"
        d = load(lab); ev = d["ev"]
        due = ev["ntp_due"]
        w = [x for x in due if 1800 <= x[0] < 4200]
        c1 = sum(1 for x in w if x[2] == 1); c2 = sum(1 for x in w if x[2] == 2)
        a1 = sum(1 for x in due if x[2] == 1); a2 = sum(1 for x in due if x[2] == 2)
        disp = ev["srs_dispatch"]
        waits = []
        for m0 in range(30, 110, 10):
            ws = [x[3] / 1e3 for x in disp if m0 * 60 <= x[0] < (m0 + 10) * 60]
            waits.append(f"{med(ws):5.1f}" if ws else "  -  ")
        pins = {}
        dur = []
        for x in ev["srs_pin"]:
            pins[x[1]] = x[0]
        for x in ev["srs_unpin"]:
            if x[1] in pins:
                dur.append(x[0] - pins.pop(x[1]))
        print(f"{lab:14s} due [1800,4200): case1 {c1} case2 {c2} -> case1 share {100 * c1 / max(1, c1 + c2):.0f} % | whole log: case1 {a1} case2 {a2} -> case2 share {100 * a2 / max(1, a1 + a2):.0f} %"
              f" | dispatch wait p50 s by 10 min from 30: {' '.join(waits)} | pins {len(dur)} median {med(dur):.1f} s mean {mean(dur):.1f} s | pin skips {len(ev.get('srs_pin_skipped', []))} | expiries {len(ev['ntp_expire'])}"
              f" (timeout {sum(1 for x in ev['ntp_expire'] if x[3] == 'timeout')})")
        drop(lab)
